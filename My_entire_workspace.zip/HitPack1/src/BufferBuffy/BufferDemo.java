package BufferBuffy;

public class BufferDemo {
		public static void main(String[] args) {
			String s = "jack and jill&copy; went up the hill to fetch  
			
		}
}
