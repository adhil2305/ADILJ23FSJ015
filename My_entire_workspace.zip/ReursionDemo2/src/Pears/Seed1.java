package Pears;

public class Seed1 {
		public static void main(String[] args) {
			int result = met(1);
			Seed1.met(5);
			Seed1.met(0);
			System.out.println(result);
		}
			static int met(int i) {
				// Base function where the chain terminates
				if (i==0) {
					return 1;
				}
				// This is the dependant function 
				int result = i+ met(i-1);
				return result;
			}
}
