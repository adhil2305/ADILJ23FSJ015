package ORANGE;

import java.io.File;
import java.io.FileInputStream;

public class FileDemo3 {
		public static void main(String[] args) {
			File file = new File("abc.txt");
			//System.out.println(file.getAbsolutePath());
			//System.out.println(file.isDirectory());//false
			try ( FileInputStream fis = new FileInputStream(file);
			)
			//System.out.println(fis.available());

			{		int eof = -1;
			int i = 0;
			byte b[] = new byte[4];
			while((i=fis.read(b))!=eof) {
				System.out.println("The number of bytes read" +i);
				String s1 = new String(b,0,i);
				System.out.println(s1);
				
			}
			}catch(Exception e) {e.printStackTrace();}
			
		}
}
