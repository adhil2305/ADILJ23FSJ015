package Trial;

public class Demo {
	public static void main(String[] args) {
		IceCream ibaco = new Vanilla(new StrawBerry());
		System.out.println(ibaco.cost());
	}
}

abstract class IceCream{
	abstract int cost();
}

abstract class Cream extends IceCream{}
class Vanilla extends Cream{
	IceCream iceCream;
	public Vanilla(){}
	public Vanilla(IceCream iceCream) {
		this.iceCream =  iceCream;
	}
	public int cost() {
		if(iceCream ==null) {
			return 20;
		}
		else {
			return iceCream.cost() + 20;
		}
	}
}

class StrawBerry extends Cream{
	IceCream iceCream;
	public StrawBerry() {}
	public StrawBerry(IceCream iceCream) {
		this.iceCream = iceCream;
	}
	public int cost() {
		if(iceCream == null) {
			return 20;
		}
		else {
			return iceCream.cost() + 20;
		}
	}
}