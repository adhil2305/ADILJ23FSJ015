public class MyFor {
	public static void main(String argv[]) {
		
		int i = 12;
		int j = 12;
		
			
	
						System.out.println("The value for i="+i+ "The value for j = " +j  );
				
	}

}
