package Establish_basic_connection;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
public class JDBCDEMO1 {
public static void main(String[] args) throws Exception{
	
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection con=DriverManager.getConnection("jdbc:mysql://localhost/javabatch","root","root");
	
	String sql="update users set flag=0";
	
	//Statement stmt=con.createStatement();//be defualt single navigable
	
	Statement stmt=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);//multi navigable
	
	int n=stmt.executeUpdate(sql);//this returns the number of rows affected
			
	System.out.println(n);
	
	sql="select * from users";
	
	boolean boo=stmt.execute(sql);
	
	System.out.println(boo);//true
	
	ResultSet rs= stmt.executeQuery(sql);
	while(rs.next()) {
		System.out.println(rs.getInt("userid"));
		System.out.println(rs.getString("username"));
	}
	
	//rs= stmt.executeQuery(sql);
	while(rs.previous()) {
		System.out.println("............"+rs.getInt(1));
		System.out.println("............"+rs.getString(2));
	}
	
	
	
}
}
