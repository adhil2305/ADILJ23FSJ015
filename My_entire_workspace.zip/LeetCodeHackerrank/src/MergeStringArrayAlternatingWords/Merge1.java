package MergeStringArrayAlternatingWords;

public class Merge1 {
	static char arr[] = new char[100];
	static char brr[] = new char[100];
	
		public static void main(String[] args) {
			Merge1.Merger("abc", "pqrst");
		}
		public static String Merger(String word1, String word2) {
			
		        int i = 0;
		        StringBuilder result = new StringBuilder();
		        while(i< word1.length() || i < word2.length()) {
		            if(i<word1.length()){
		            result.append(word1.charAt(i));
		            }
		            if(i<word2.length()){
		                result.append(word2.charAt(i));
		            }   
		            i++;
		        }
		        System.out.println(result.toString());
		    return result.toString();
		}
			
			
		}

