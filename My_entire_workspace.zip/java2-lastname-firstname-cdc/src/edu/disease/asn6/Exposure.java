package edu.disease.asn6;
import java.io.Serializable;
import java.util.Objects;
import java.util.UUID;
public class Exposure implements Serializable{

	
	/**
	 * Tis is to differentiate other code spaces
	 */
	private static final long serialVersionUID = 145L;
	/**
	 * Read some Oracle document on java.util.UUID
	 * It is a unique variable it accepts
	 * alpha numeric values it is not an integer
	 */
	
	private java.util.UUID patientId; 
	private java.time.LocalDateTime dateTime;
	private String exposureType;

	
	public Exposure() {
		
	}
	

	
	public void setExposureType(String exposureType) {
		if (exposureType.equals("D") || exposureType =="I"){
			this.exposureType = exposureType;
		
		}
		else {
		throw new IllegalArgumentException("Please enter D for direct exposure or I for indirect exposure");

		}
		
	}
	
	public Exposure(UUID patientId) {
		this.patientId = patientId;
	}
	
	public String getExposureType() {
		return this.exposureType;
	}
	
	public java.util.UUID getPatientId() {
		return this.patientId;
	}
	public void setPatientId(java.util.UUID patientId) {
		this.patientId = patientId;
	}
	
	public void setDateTime(java.time.LocalDateTime dateTime) {
		this.dateTime = dateTime;
	}
	public java.time.LocalDateTime getDateTime() {
		return this.dateTime;
	}
	/**
	 * Implementing HashCode for patientId
	 * Converted the UUID in to hashCode 
	 * using the inbuilt hashCode mehtod in java
	 * that gives a integer value as a return type
	 */

	public int hashCode() {
		return Objects.hash(dateTime,patientId,exposureType);
	}
	
	/**
	 * Override Equals method
	 */
	
	public boolean equals(Object o) {
		Exposure e1 = (Exposure)o;
	if(dateTime!=null || patientId!=null || exposureType!=null){
		if(this.patientId.hashCode() == e1.patientId.hashCode()) {
			return true;
		}
		else {
			return false;
		}
		}
		else if(dateTime==null&&patientId==null&&exposureType==null){
			return true;
		}
		else if(this.dateTime.hashCode() == e1.dateTime.hashCode()) {
				return true;
		}
		else if(this.exposureType.hashCode()== e1.exposureType.hashCode()) {
			return true;
		}
	
	else {
			return false;
	    }
		 
	}
	/**
	 * The to string method acn be printed by every object that you can print
	 * by not overriding the to string method the return type is a memory address
	 */
	public String toString() {
		return "Patient ID" + patientId + "Date and Time" + dateTime + "Exposure Type" + exposureType;
	}

	
	


}