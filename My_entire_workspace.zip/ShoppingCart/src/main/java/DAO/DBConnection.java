package DAO;

public class DBConnection {
private DBConnection{){
	try {
		class.forname("com.cj.jdbc.Driver");
	}catch(Exception e) {
		e.printStackTrace();
	}

}
	
}
private static DBConnection dbCon;
public static DBconnection getDBConnection() {
	if (dbCon == null) {
		dbCon = new DBConnection();
	}
	return dbCon;
}
synchronized Connection.getConnection(){
	try {
		Connection con = DriverManager.getConnection(jdbc.mysql://localhost:1521/sakila,'root','root');
			return con;
	}catch(Exception e) {e.printStackTrace();
	}

}