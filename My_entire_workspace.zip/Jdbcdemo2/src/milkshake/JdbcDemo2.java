package milkshake;
import java.sql.Connection; 
import java.sql.DriverManager; 
import java.sql.DatabaseMetaData; 

public class JdbcDemo2 {
public static void main(String[] args) {
	
	//load the database
	
	Class.forName("com.mysql.cj.jdbc.Driver");//driver 4 ofmy sql 
	
	//Establish a connection
	
	Connection con = DriverManger.getConnection("jdbc:mysql://localhost/eve',"root","root");
		
			
			//step 3 process the connection"

	
}
}
