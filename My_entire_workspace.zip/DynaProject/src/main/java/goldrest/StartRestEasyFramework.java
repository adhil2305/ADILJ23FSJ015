package goldrest;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("rest")
public class StartRestEasyFramework  extends Application {
	public StartRestEasyFramework() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public Set<Object> getSingletons(){
		HashSet<Object> set = new HashSet<>();
		return set;
	}
}
