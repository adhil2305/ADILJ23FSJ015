package mod1.day10.lab;

public class Lab3 {
	public static void main(String[] args) {
		int n1=10;
		int n2=30;
		int n3=5;
		
		if(n1>=n2 && n1>=n3) {
			System.out.println("n1 is baapp of all....");
		}
		else if(n2>=n1 && n2>=n3) {
			System.out.println("n2 is baap of all.....");
		}
		else {
			System.out.println("n3 is baap of all....");
		}
	}
}
