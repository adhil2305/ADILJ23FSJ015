import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class ThreadTea {
public static void main(String[] args) {
	
	/*
	 * sleep method can be given anywhere 
wat can only be give inin a monitor  as in a synchronized thread lock 
wait notify notifyall all belongs to the objects class
sleep belongs to the thread class

thread is in sleep mode other thread cannot enter 
thread is ni wait mode another thread can enter 





	 */
	
	
	
	
	// The list class type safety only accepts idiots 
	List<Idiot> list1 = new ArrayList<>();
	list1.add(new Idiot("Salman", 4));
	list1.add(new Idiot("Natarajan",1));
	list1.stream().forEach(System.out::println);
	// A new Canon object called the bofors is created
	
	Canon bofors = new Canon();
	// A new Shoooting task object is created and bofors obj is passed
	ShootingTask st= new ShootingTask(bofors);
	
	Thread naina = new Thread(st,"naina");
	Thread shabeer = new Thread(st,"shabeer");
	
	naina.start();
	shabeer.start();
}
}
	class ShootingTask implements Runnable{
		// There's a canon gun in the shootin task
		Canon gun;
		public ShootingTask(Canon gun) {
//			this accepts a canon obj the obj is set here to get the obj of a canon but why
		this.gun= gun;
	}
	@Override
	public void run() {
		Thread t = Thread.currentThread();
		if(Thread.currentThread().getName().equals("naina")) {
		for(int i=0;i<5;i++) {
			gun.fill();
		}
	}
		// For using the object in multiple lines fo code you could use the object creation method 
		
	else if(t.getName().equals("shabeer")) {
		for(int i=0;i<5;i++) {
			gun.shoot();
		}
	}
}
}
class Canon{
public void fill() {
	Thread t=Thread.currentThread();
	String name=t.getName();
	//this could also be written as
	//Thread.currentThread().getName();
	// The above name could also get the name
	
	System.out.println(name+" fills the gun.......");
}

public void shoot() {
	Thread t=Thread.currentThread();
	String name=t.getName();
	System.out.println(name+" shoot the gun...........");
}
}
		
class Idiot {
	public Idiot(String name, int height) {
	System.out.println("The idiot "+ name+" is here");
	}
	}
	

