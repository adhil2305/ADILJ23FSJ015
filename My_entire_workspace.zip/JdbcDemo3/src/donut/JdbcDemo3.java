package donut;
import java.sql.DriverManager;
import java.sql.DriverManager;
import java.sql.Statement;

public class JdbcDemo3 {
public static void main(String[] args) {
	//
	
	class.forName("com.mysql.cj.jdbc.Driver");
	
	Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/eve","root","root");
	
	//step 3
	
	System.out.println(con);
	
	Statement stmt = con.createStatement();
	
	String sql =("create table users(uid int(5) uname varchar())"

//			sql="insert into users values (1,'rahim','secret',0)";
//			stmt.execute(sql);
			sql="insert into users values (3,'basha','secret',0)";
			
			boolean result=stmt.execute(sql);
			System.out.println("For queries which does not return resultset.."+result);
			
			result=stmt.execute("select * from users");//this will return a resultset
			System.out.println("For queries which returns a resultset..:"+result);
			



}
}
