package edu.disease.asn4;

import java.time.LocalDateTime;
import edu.disease.asn3.Patient;

public class PatientZero {
	private Patient patient;
	private LocalDateTime exposureDateTime;
	private boolean exposed;
	
	// This class will be used by the contract trace class to hold a patient in the line of exposures
	/*
	 * et Exposed boolean true or false
	 */
	public void setExposed(boolean exposed) {
		this.exposed = exposed;
	}
	/*
	 *  get Exposed returns the exposed 
	 */
	public boolean getExposed() {
		return exposed;
	}
	
	public void setExposureDateTime(LocalDateTime exposureDateTime) {
		this.exposureDateTime = exposureDateTime;
	}
	
	public LocalDateTime getExposureDateTime() {
		return exposureDateTime;
	}
	
	public Patient getPatient() {
		return this.patient ;
	}
	
	public void setPatient(Patient patient) {
		 this.patient = patient;
	}
	
}
