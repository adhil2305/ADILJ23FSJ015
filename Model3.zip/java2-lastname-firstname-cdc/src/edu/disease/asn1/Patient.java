package edu.disease.asn1;

import java.util.Arrays;

import java.util.Objects;
import java.util.UUID;


public class Patient {
	
	
	//public static void main(String[] args) {}
	
	java.util.UUID patientId;
	String firstName;
	String lastName;
	Exposure[] exposures;	
	UUID[] diseaseIds;
	public Patient() {
		
	}
	public Patient(int maxDiseases, int maxExposures) {
		if(maxDiseases <=0 ||  maxExposures <=0) {
			throw new IllegalArgumentException("Cannot Initialize give a number between 1 and 4");
		}
		if(maxDiseases >4 || maxExposures >4) {
			throw new IllegalArgumentException("Cannot Initialize give a number between 1 and 4");
		}
		else {
			exposures = new Exposure[maxExposures];
			diseaseIds = new UUID[maxDiseases];
		}
		
	}
	public Patient(String firstName,String lastName) {
		this.firstName = firstName;
		this.lastName = lastName;
		}
	public void addDisease(UUID diseaseId)  {
		for(int i=0;i<diseaseIds.length;i++) {
			if(diseaseIds[i]==null) {
			diseaseIds[i] =  diseaseId;
			break;
				}
			
			}
}

	
	public void addExposure(Exposure[] exposure)  {

		for(int i=0;i<exposures.length;i++) {
			if(exposures[i]==null) {
				exposures[i]=exposure[i];
				break;
			}
		}
		


	}
	/*
	 * Creating a custom Exception just in case when things head north
	 */
	/*
	 * class IndexOutOfBoundException extends Exception{ String msg; public
	 * IndexOutOfBoundException(String msg) { this.msg = msg; } public String
	 * toString() { return this.msg; }
	 * 
	 */
	/**
	 * PatientId getters and setters
	 * @param patientId
	 */
	public void setPatientId(java.util.UUID patientId) {
		this.patientId = patientId;
	}
	public java.util.UUID getPatientId(){
		return this.patientId;
	}
	public String getLastName(){
		return this.lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getfirstName(){
		return this.firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public Exposure[] getExposure() {
		return this.exposures;
	}
	public void setEposure(Exposure[] exposures) {
		this.exposures = exposures;
	}
	public UUID[] getDiseaseIds() {
		return this.diseaseIds;
	}
	public void setDiseaseIds(UUID[] diseaseIds) {
		this.diseaseIds = diseaseIds;
	}
	
	/**
	 * Implementing HashCode for patientId
	 * 
	 */
	public int hashCode() {
		return Objects.hash(firstName, lastName,patientId,exposures,diseaseIds);
	}
	
	/**
	 * Override Equals method
	 */
	
	public boolean equals(Object o) {
		Patient p = (Patient)o;
		if(firstName!=null && lastName!=null) {
			if(firstName.hashCode()==p.firstName.hashCode() && lastName.hashCode()==p.lastName.hashCode()) {
				return true;
			}
			else {
				return false;
			}
		}
		else if(firstName!=null && lastName==null) {
			if(firstName.hashCode()==p.firstName.hashCode()) {
				return true;
			}
			else {
				return false;
			}
		}
		else if(firstName==null && lastName!=null) {
			if(lastName.hashCode()==p.lastName.hashCode()) {
				return true;
			}
			else {
				return false;
			}
		}
		else if(firstName==null&& lastName==null) {
			return true;
		}
		else {
			return false;
			}
	}

	
	/**
	 * Creating a to string Method 
	 */

	public String toString() {
		return "Patient ID" + patientId + "First Name" + firstName + "Last Name"+ lastName +"Exposure"+ Arrays.toString(exposures) + "Disease Id " + Arrays.toString(diseaseIds);	
	}
	
}
/**
 * Default serial version Id added to the custom exception
 * @author Adhil
 *
 */
class IndexOutOfBoundException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public IndexOutOfBoundException(String msg) {
		super(msg);
	}
}
