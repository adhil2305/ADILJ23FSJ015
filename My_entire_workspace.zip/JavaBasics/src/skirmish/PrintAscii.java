package skirmish;

public class PrintAscii {
	public static void main(String[] args) {
		char ch = 'H';
		int ascii  = ch;
		//you can also cast har into integer
		int castascii = (int)ch;
		System.out.println("The value of " + ch + " is "+ ascii);
		System.out.println("The value of " + ch + " is "+ castascii);

		
	}

}
