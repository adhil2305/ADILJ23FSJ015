package edu.disease.asn2;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class DiseaseControlManagerTest {

	@Test
	void testAddDisease() {
		String name = "Common Cold";
		boolean infectious = true;
		DiseaseControlManagerImpl dcm = new DiseaseControlManagerImpl();
		Disease d = dcm.addDisease(name, infectious);
		System.out.println(d);
		assertEquals(dcm.addDisease(name, infectious),d);
}

}
