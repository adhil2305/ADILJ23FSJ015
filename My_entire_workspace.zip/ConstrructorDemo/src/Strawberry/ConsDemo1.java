package Strawberry;

public class ConsDemo1 {
	public static void main(String[] args) {
		Ball obj = new Ball(100,"dark blue");
		obj.dsplaySizeAndColor();
	}
}
class Ball{
	String color;
	int size;
	String packing;
	public Ball(int size, String color) {
		this.color = color;
		this.size = size;
	}
	public void dsplaySizeAndColor() {
		System.out.println("Size:"+size+"color:"+color);
		
	}
	public void setPacking(String Packing) {
		
	}
	
}