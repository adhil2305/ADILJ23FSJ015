package Jalapeno;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class FrenchLoaf {
		public static void main(String[] args) {
			Theatre shaitan1 = new Theatre();
			Theatre shaitan2 = new Theatre();
			ExecutorService es = Executors.newFixedThreadPool(2);
			
			es.execute(() -> {
				synchronized(Toilet.class){ //CLASS LOCK 
					Thread.currentThread().setName("dimbu");
					Theatre.toilet.useToilet();
					Theatre.toilet.useUrinal();
				}
			});
			es.execute(() -> {
				synchronized(Toilet.class) {
					Thread.currentThread().setName("Manush");
			Theatre.toilet.useToilet();
			Theatre.toilet.useUrinal();
				}
			});
			es.shutdown();
		}
}

class Theatre{
	static Toilet toilet = new Toilet();
}

 class Toilet{
	 public void useToilet() {
		String name = Thread.currentThread().getName();
		System.out.println(name+" is using he toilet");
		
		try {Thread.sleep(2000);}catch(Exception e) {e.printStackTrace();}
		System.out.println(name+"Coming out of the toilet");
		
	
}

 public void useUrinal() {
	String name = Thread.currentThread().getName();
	System.out.println(name+" is using the Urinal");
	try {Thread.sleep(2000);}catch(Exception e) {}
	System.out.println(name+" is coming out of the Urinal");
}
}