package Donuts;

public class Variable1 {
		public static void main(String[] args) {
			
			// - SINGLE LINE COMMENT
			/*
			 * MULTIPLE LINE
			 * COMMENT
			 * HAHA
			 * KAKA
			 * KKAAA
			 *
			 */
			/**
			 * DOCUMENT TYPE COMMENT...
			 * AUTHOR - M.H. SHOIAB
			 * YEAR - 2023 JUNE
			 */
			
			//NUMBER TYPE
			
			//BYTE , SHORT, INT, LONG
			
			byte b=20;//value 20 is assigned to variable by name b of type byte
			byte b2=10;
			System.out.println(b+b2);
			
			b=-128;// size of byte 8 BIT is 256 - SIGNED DATA TYPE (-128 TO 127)
			
			short s=32767; //size of short 16 BIT is 64535 - SIGNED DATA TYPE (-32768 TO 32767)
			
			int i=-2147483648;
			i=2147483647;//size of int is 32 BIT - SIGNED DATA TYPE
			
			long moondiameter=9223372036854775807L;
			//SIZE OF LONG IS 64 BIT - SIGNED DATA TYPE
			moondiameter=-9223372036854775808L;
			
			//DECIMAL NUMBERS - FLOAT AND DOUBLE
			
			float f=2147483647.32432423f;//by default it wont take it as float
			f=-2147483648.32432428f;//SIGNED DATATYPE
			f=3.14f;
			
			double d=9223372036854775807.23432423D;
			d=23421.34;
			//64 bit data type - SIGNED DATA TYPE
			
			//CHARACTER IS A 16 BIT DATA TYPE - UNSIGNED DATA TYPE
			//CAN ONLY ACCEPT POSITIVE VALUES
			char c=257;
			c=65535;
			c='a';
			c=36;
			System.out.println(c);
			
			boolean boo=true;
			boo=false;
			
		
			
			
			
		}
}
