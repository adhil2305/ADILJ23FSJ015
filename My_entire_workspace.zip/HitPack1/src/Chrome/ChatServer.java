package Chrome;

public class ChatServer {

	


import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
public class ChatServer {
	ServerSocket ss;Socket s;
	BufferedReader in,keyin;
	PrintWriter out;
	public ChatServer() {
		try {
		
			ss=new ServerSocket(2000);
			System.out.println("Server waiting......");
			while(true) {
			s=ss.accept();
			keyin=new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Please enter a Message for Client..:");
			String msg=keyin.readLine();
			
			out=new PrintWriter(s.getOutputStream(),true);
			out.println(msg);
			
			in=new BufferedReader(new InputStreamReader(s.getInputStream()));
			String msgFromClient=in.readLine();
			System.out.println("Message From Client...:"+msgFromClient);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		new ChatServer();
	}
}
package netpack;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.net.Socket;
public class ChatClient {
	Socket s;BufferedReader in,keyin;PrintWriter out;
	public ChatClient() {
		try {
			while(true) {
			s=new Socket("localhost",2000);
			in=new BufferedReader(new InputStreamReader(s.getInputStream()));
			String msgFromServer=in.readLine();
			System.out.println("Message From Server...:"+msgFromServer);
			
			
			keyin=new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Please enter a message for server..:");
			String msg=keyin.readLine();
			
			out=new PrintWriter(s.getOutputStream(),true);
			out.println(msg);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		new ChatClient();
	}
}




SHOIAB-GOLDEN TOUCH - HAARISINFOTECH
  8:37 PM
package netpack;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
public class ChatServer {
	ServerSocket ss;Socket s;
	BufferedReader in,keyin;
	PrintWriter out;
	public ChatServer() {
		try {
		
			ss=new ServerSocket(2000);
			System.out.println("Server waiting......");
			while(true) {
			s=ss.accept();
			keyin=new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Please enter a Message for Client..:");
			String msg=keyin.readLine();
			
			out=new PrintWriter(s.getOutputStream(),true);
			out.println(msg);
			
			in=new BufferedReader(new InputStreamReader(s.getInputStream()));
			String msgFromClient=in.readLine();
			System.out.println("Message From Client...:"+msgFromClient);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		new ChatServer();
	}
}
package netpack;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.net.Socket;
public class ChatClient {
	Socket s;BufferedReader in,keyin;PrintWriter out;
	public ChatClient() {
		try {
			while(true) {
			s=new Socket("localhost",2000);
			in=new BufferedReader(new InputStreamReader(s.getInputStream()));
			String msgFromServer=in.readLine();
			System.out.println("Message From Server...:"+msgFromServer);
			
			
			keyin=new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Please enter a message for server..:");
			String msg=keyin.readLine();
			
			out=new PrintWriter(s.getOutputStream(),true);
			out.println(msg);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		new ChatClient();
	}
}


SHOIAB-GOLDEN TOUCH - HAARISINFOTECH
  8:48 PM
package netpack;
import java.awt.*;
import java.awt.event.*;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
public class HtmlBrowser extends JFrame implements ActionListener
{
	JEditorPane ep;
	JTextArea ta;
	JButton btn;
	JScrollPane pane1,pane2;
public HtmlBrowser()
{
	Container c=getContentPane();
	c.setLayout(new FlowLayout());
	ep=new JEditorPane("text/html","<h1>HTMl Here</h1>");
	ta=new JTextArea("Enter HTML here",10,50);
	pane1=new JScrollPane(ta);
	pane2=new JScrollPane(ep);
	pane2.setPreferredSize(new Dimension(550,180));
	btn=new JButton("Click");
	c.add(pane1);
	c.add(btn);
	c.add(pane2);
	btn.addActionListener(this);
}