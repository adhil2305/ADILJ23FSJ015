package mod1.day16;

public class AyurvedMedicalCollege implements Doctor{
	@Override
	public void doCure() {
		System.out.println("ayurved cure is done.....");
	}
}
