package Daily;

import org.junit.Test;

public class WrapperDemo {
	public static void main(String[] args) {
		//int i=10;
				// Integer.parseInt changes the String to a Integer for the time only
				String a1 = "100";
				
				System.out.println(Integer.parseInt(a1) + 101);
				Integer i=new Integer(100);
				
				System.out.println(i.compareTo(new Integer(10)));
				
				System.out.println(i.intValue());
				
				System.out.println(Integer.MAX_VALUE);
				System.out.println(Integer.MIN_VALUE);
				
				System.out.println(Integer.max(100, 1000));
				
				int x=Integer.parseInt("2000");//converts a text to integer
				System.out.println(x+10);
				
				Float f=new Float(12.3f);
				
				//MANUALboxing and MANUALunboxing
				x=(int)i;// manual unboxing
				i=(Integer)x;//manual boxing
				
				//after jdk 5 java introduced auto boxing
				x=i;//AUTOUNBOXING
				
				i=x;//AUTOBOXING
				
				//WAYS OF CREATING INTEGER OBJECT OR WRAPPER OBJECT ARE
				
				Integer myint=Integer.valueOf(100);
				Integer myint2=1000;
				int myint3=1000;
				//both are same in terms of memory usage (only stack is used)
				
				
				
				
			}
		}
		
