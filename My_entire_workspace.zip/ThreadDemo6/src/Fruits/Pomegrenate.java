package Fruits;

	import java.util.concurrent.Callable;
	import java.util.concurrent.ExecutorService;
	import java.util.concurrent.Executors;
	import java.util.concurrent.Future;
	public class Pomegrenate {
		String returneddata;
		public Pomegrenate() {
			ExecutorService es=Executors.newFixedThreadPool(1);
			try {
//			Future<String> future= es.submit(new MyThreadJobWithReturn());		
//			this.returneddata=future.get();
//			System.out.println(returneddata);
					
			Future<String> f=es.submit(()->{return "job done..............";});
			System.out.println(f.get());
			}catch(Exception e) {
				e.printStackTrace();
			}
			es.shutdown();
		}
		public static void main(String[] args) {
			Pomegrenate d=new Pomegrenate();		
			for(int i=0;i<5;i++) {
				System.out.println(i);
				try {Thread.sleep(1000);}catch(Exception e) {}
			}
		}
	}
	class MyThreadJobWithReturn implements Callable<String>{
		@Override
		public String call() throws Exception {
			// TODO Auto-generated method stub
			return "job done....";
		}
	}
