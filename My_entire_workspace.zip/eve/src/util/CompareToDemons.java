package util;

public class CompareToDemons {
	public static void main(String[] args) {
		String s1="c";//99
		String s2="a";//97
		
		System.out.println(s1.compareTo(s2));
	}
}
