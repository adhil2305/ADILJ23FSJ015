package mod1.day16;

public class Human {
	
}
