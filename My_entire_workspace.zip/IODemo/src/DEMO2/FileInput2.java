package DEMO2;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileInput2 {
	public static void main(String[] args) throws Exception{
		
	try(
			FileReader fir=new FileReader("demo2loop.txt");
			
			FileWriter fiw=new FileWriter("copy2.txt");
			){
			//System.out.println((char)fir.read());
			
			int x=0;
			char c[]=new char[4];
			while((x=fir.read(c))!=-1) {
				System.out.println(x);
				String s=new String(c,0,x);
				System.out.println(s);
				fiw.write(c,0,x);
			}
			}catch(IOException e) {e.printStackTrace();}
			
		}
	}


	