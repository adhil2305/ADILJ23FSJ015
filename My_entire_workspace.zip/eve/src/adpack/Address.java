package adpack;

import java.io.Serializable;

public class Address implements Serializable{
	
}