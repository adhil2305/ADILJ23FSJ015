import java.util.Scanner;

public class Conditionals1 {
public static void main(String[] args) {
	

Scanner scan = new Scanner(System.in);

System.out.println("Enter a value...");
int i = scan.nextInt();
if(i==10) {
	System.out.println("The value entered is 10");
	
}
else if(i==20) {
	System.out.println("Twenty is printed");
}
else if(i==30) {
	System.out.println("Thirty is printed");
	
}
else {
	System.out.println("The condition is not satisfied..");
}

System.out.println("Please Enter another number");


}
}