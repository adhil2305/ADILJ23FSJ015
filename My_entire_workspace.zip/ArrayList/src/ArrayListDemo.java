import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;


public class ArrayListDemo {
public static void main(String[] args) {
	//Arrays
	String s[] = new String[4];
	s[0] = "Hello";
	//s[1] = new stone();
	//Arrays are homogeneous in nature - You can add only one type of data
	//Array size is fixed you cannot change the array size at run time
	//reading an array 
	
	for (int i=0;i<s.length;i++) {
	                             System.out.println(s[i]);}
	for (String str :s) { 
		System.out.println(str);
	}
	
	ArrayList<String> list = new ArrayList<String>();
	list.add("Hello World");
	list.add("Hai");
	list.add("120");
	System.out.println(list);
	System.out.println(list.contains("Hello World"));
	Collections.sort(list);
	System.out.println(list);
	
	
	
	
}
}
