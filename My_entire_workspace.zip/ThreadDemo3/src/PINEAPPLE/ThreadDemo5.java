package PINEAPPLE;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;

public class ThreadDemo5 {
	public ThreadDemo5() {
		ExecutorService es = Executors.newFixedThreadPool(3);
		es.execute(() -> System.out.println("Child Thread running.....1")); //lambdas
		try {Thread.sleep(10000);}catch(Exception en) {}
		es.execute(() -> System.out.println("Child Thread running.....2")); //lambdas
		es.execute(() -> System.out.println("Child Thread running.....3")); //lambdas
		es.shutdown();
		
		
		
	}
	
	public static void main(String[] args) {
		new ThreadDemo5();
		for(int i=0;i<5;i++) {
			System.out.println(i);
			try {
				Thread.sleep(10000);
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
	}
	
}
