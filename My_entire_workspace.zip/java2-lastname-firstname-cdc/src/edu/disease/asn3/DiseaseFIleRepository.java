package edu.disease.asn3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class DiseaseFIleRepository {
	Disease[] diseases;
	Patient[] patients;
	String folderpath;
	
	
	public void setFolderPath(String folderpath) {
		this.folderpath =  folderpath;
	}
	
	public String getFolderPath(String folderpath) {
		return this.folderpath;
	}
	
	public Disease[] getDiseases() {
		return this.diseases;
	}
	public void setDiseases(Disease[] diseases) {
		this.diseases = diseases;
	}
	public Patient[] getPatient() {
		return this.patients ;
	}
	public void setPatients(Patient[] patients) {
		this.patients =  patients;
	}
	public static void main(String[] args) {
		System.out.println("hello");
	}

	
	public void save(Disease[] diseases, Patient[] patients) {

	this.diseases = diseases;
	this.patients = patients;
	String  diseasesPath = folderpath + File.separator + "diseases.dat";
	String patientsPath = folderpath + File.separator + "patients.dat";
	try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(diseasesPath));) {
        // Serialize the object
        oos.writeObject(diseases);
        System.out.println("Serialization successful");
        oos.close();
	 } catch (IOException e) {
            e.printStackTrace();
        }
	
	
	try (ObjectOutputStream oos1 = new ObjectOutputStream(new FileOutputStream(patientsPath));) {
        // Serialize the object
        oos1.writeObject(patients);
        System.out.println("Serialization successful");
        oos1.close();
	 } catch (IOException e) {
            e.printStackTrace();
        }
	}// The cole method closes here
	
	
	public DiseaseAndPatient init(String folderpath){

	this.folderpath = folderpath;
	//Folder path string 
	
	  Disease[] deserializedDiseases1 = null;
	    Patient[] deserializedPatients1 = null;
	    	
		String  diseasesPath = folderpath + File.separator + "diseases.dat";
		String patientsPath = folderpath + File.separator + "patients.dat";
	
	Path path1 = Paths.get(folderpath);
	 if (Files.exists(path1) && Files.isDirectory(path1) && folderpath != null ) {
		
		 
		 try(
		            ObjectInputStream ois1 = new ObjectInputStream(new FileInputStream(diseasesPath));
			     ObjectInputStream ois = new ObjectInputStream(new FileInputStream(patientsPath));
				 ){
			 deserializedDiseases1 =  (Disease[])ois1.readObject();
		     deserializedPatients1 =  (Patient[])ois.readObject();
		          
		          
		        } catch (Exception ex) {
		        	
		            ex.printStackTrace();
		            
		        }
           DiseaseAndPatient dptester = new DiseaseAndPatient(deserializedDiseases1, deserializedPatients1);
            return dptester;
            		}else {
        	
        	throw new IllegalArgumentException("The specified folderpath doesnot exist");
        	
        }
}// The init method gets closed here


}
