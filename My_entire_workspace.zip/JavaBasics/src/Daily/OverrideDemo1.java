package Daily;

public class OverrideDemo1 {
	public static void main(String[] args) {
		OverrideDemo1 obj2 = new OverrideDemo1();
		
		obj2.help(new Girl()); // Runtime polymorphism or Virtual method
		//invocation
		
		// Method Overloading
		obj2.met(10f);
		
		MySuper2 obj=new MySub();
		obj.met();
		System.out.println(obj.sno);
	}
	
	public void help(Boy b) {
		System.out.println("Not everyone will help..");
	}
	public int help(Girl g) {
		System.out.println("Everyone will rush to help...");
		return 1;	}
	
public void met(int i) {
	System.out.println("Integer method called...");
}
public void met(float f) {
	System.out.println("Float method called...");
}
}
class MySuper1 {
	int sno=100;
	public void met() {
		System.out.println("mysuper1 met called....");
	}
}
class MySuper2 extends MySuper1{
	int sno=200;//overriding does not take place on variables
	public void met() {//overriding is only for methods not for variable
		System.out.println("mysuper2 met called...");
	}
}
class MySub extends MySuper2{
	int sno=300;
	public void met() {
		System.out.println("my sub met called...................");
	}
}



class Boy{
	
}
class Girl{
	
}
