import java.util.HashMap;
import java.util.Map;

public class Mailer {
	public static void main(String[] args) {
		// SMTP info & mailer Details (From Mail & Auth)
		String host = "smtp.gmail.com";
		String port = "587";
		String mailFrom = "adhil2305@gmail.com";
		String password = "laksjdhfg";

		// Subject & Main Message(in HTML)
		String subject = "Hurray!!! Grab the offer 8 % off on Godrej furniture !!!";
	
		StringBuffer body = new StringBuffer("<html><body style=\"border: 5px solid rgb(73, 67, 67) ;margin-left: 5%;margin-right: 5%;text-align: center;align-items: center;\">"
				+ "<h1 style=\"color:rgb(251, 250, 255);background-color:rgb(3, 3, 63);border-left:20px;\" >Welcome to <br>Godrej interio</h1><br>");
		body.append("<img src=\"cid:image1\" width=\"100%\" height=\"100%\" />");
		body.append("<h1 style=\"color:rgb(255, 21, 0);\" >Want to build your dream home </h1>"
						+ "<p style=\"margin-left: 10%;margin-right: 10%;text-align: center;\">Here we are, India's most exotic Furniture brand . Join us to build a home of your dreams. We will guide you to your dreams.India's one of the Top 10 fortune 500 brand, Godrej interio Chennai</p>"
						+ "<h1 style=\"color:rgb(255, 0, 221);\" >Furniture at it's best</h1><p style=\"margin-left: 10%;margin-right: 10%;text-align: center;\"> <strong>Seating, Desking and Home storage</strong><br>"
						+ "<table style=\"width:100%\"><tr><th>Sofa</th><th>Beds and mattress</th></tr><tr><td>Dinning Table</td> <td>Office Chairs</td></tr><tr><td>Study tables</td><td>TV unit</td></tr><tr><td>Home safes</td><td>Almirah</td></tr><tr><td>Kitchen</td><td></td></tr><tr><td>Coffee table</td><td>Door Locks</td></tr><tr><td>File Cabinets</td><td>Book shelf</td></tr></table></p>");
		body.append("<img src=\"cid:image2\" width=\"100%\" height=\"100%\" />");
		body.append("<p style=\"margin-left: 10%;margin-right: 10%;text-align: center;\"> <br><br><br>� 2021 Godrej Fabricon . All rights reserved. Fabricon is registered with the Godrej group login to set your preferences in Email Settings.<br><strong>Address:</strong> Fabricon, kanniammankoil street, B-30, 600096,Ambattur, Chennai, Tamil Nadu 600096</p>"
						+ "<p style=\"margin-left: 10%;margin-right: 10%;text-align: center;\"><table style=\"width:100%;\"><tr><th> <br><a href=\"http://godrejinterio.com/team-members/#service\">Visit Us</a><br><br></th><th><a href=\"http://godrejinterio.com/about-us/\">About Us</a><br><br> </th></tr><tr><th> <a href=\"http://godrejinterio.com/team-members/\">Meet our Team</a></th><th><a href=\"http://haarisinfotech.com/services-version-one/\">Our Services</a></th></tr></table></p></body>"
						+ "</html>");
			
		
		// Add in-line images
		Map<String, String> inlineImages = new HashMap<String, String>();
		inlineImages.put("image1", "ads1.gif");
		inlineImages.put("image2", "ads2.gif");

		try {
			SendEmail.send(host, port, mailFrom, password, subject, body.toString(), inlineImages);
		} catch (Exception ex) {
			System.out.println("Unable to Send email.");
			ex.printStackTrace();
		}
	}
}
