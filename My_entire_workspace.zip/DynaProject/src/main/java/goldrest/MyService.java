package goldrest;

import javax.websocket.server.PathParam;
import javax.ws.rs.GET;
import javax.ws.rs.Path;

//	@Path("/goglobal")//http://localhost:2020/goldrest/resteasy/goglobal

@Path("/goglobal")//https://localhost:2020/goldrest/resteasy/goglobal
public class MyService {
	@GET
	public void met() {
		
	}
	@Path("sayHello")
	@GET
	public void sayHello() {
		System.out.println("hello ");
	}
	@Path("/met3/{myparam}")
	@GET
	public void met3(@PathParam("myparam") String p) {
		System.out.println("met 3 called....:"+p);
	}
	
	@Path("/met3/{myparam}/{param2}")
	@GET
	public void met4(@PathParam("myparam") String p,@PathParam("param2")String p2) {
		System.out.println("met 3 called....:"+p+":"+p2);
	}
	
}
