package DOM;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
public class DomProcessor {
	public static void main(String[] args) throws Exception{
		DocumentBuilderFactory dbf=DocumentBuilderFactory.newInstance();
		DocumentBuilder db=DocumentBuilderFactory.newInstance().newDocumentBuilder();
		
		Document dom=db.parse("emp.xml"); 
		
		Element rootElement = dom.getDocumentElement();
		
		System.out.println(rootElement.getFirstChild().getFirstChild().getFirstChild().getNodeValue());
		
		System.out.println(rootElement.getChildNodes().getLength());
		
		for(int i=0;i<rootElement.getChildNodes().getLength();i++) {
			for(int j=0;j<rootElement.getChildNodes().item(i).getChildNodes().getLength();j++) {
				System.out.println(rootElement.getChildNodes().item(i)
						.getChildNodes().item((j)).getFirstChild().getNodeValue());
			}
		}
	}
}
