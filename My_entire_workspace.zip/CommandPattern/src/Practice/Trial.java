package Practice;

public class Trial {
	public static void main(String[] args) {
		NeoApp app1 = new NeoApp();
		Hall hall1 = new Hall();
		CateringGuy caterer1 = new CateringGuy();
		
		//Creating the command
		Command marriageCommand = new MarriageCommand(hall1, caterer1);
		Command birthdayCommand = new BirthdayCommand(hall1, caterer1);
		
		//Assigning the command to a object so that 
		// only a specific command could run at a time.
		app1.setCommand(1, birthdayCommand);
		app1.setCommand(2, marriageCommand);
		
		app1.executeCommand(1);
	}
}

class Hall{
	public void ping(String details) {
		System.out.println("Hall services are needed by" + details);
	}
	public void service() {
		System.out.println("awaiting orders to initiate services...");
	}
}

class CateringGuy{
	public void ping(String details) {
		System.out.println("Catering services are needed by" + details);
	}
	public void service() {
		System.out.println("awaiting orders to initiate services...");
	}
}

abstract class Command{
	Hall hall1;
	CateringGuy caterer1;
	public Command() {}
	public Command(Hall hall1, CateringGuy caterer1) {
		this.hall1 = hall1;
		this.caterer1 = caterer1;
	}
	public abstract void execute();
}

class MarriageCommand extends Command{
	public MarriageCommand(Hall hall1, CateringGuy caterer1) {
		super(hall1, caterer1);
	}
	
	@Override
	public void execute() {
	System.out.println("The Marriage command called ...");
	hall1.ping("so and so details");
	hall1.service();
	caterer1.ping("so and so details--");
	caterer1.service();
	
	System.out.println("All done ");
	
	}
}

class BirthdayCommand extends Command{
	public BirthdayCommand(Hall hall1, CateringGuy caterer1) {
		super(hall1, caterer1);
	}
	@Override
	public void execute() {
		System.out.println("Birthday command called now ");
		hall1.ping(" so and so person has birthday ");
		hall1.service();
		caterer1.ping("Do the catering service for birthday people");
		caterer1.service();
		
	}
}

class DummyCommand extends Command{
	@Override 
	public void execute() {
		System.out.println("I am yet to be operational");
	}
}

class NeoApp{
	Command[] command =  new Command[5];
	public NeoApp() {
		for(int i = 0;i<5;i++) {
			this.command[i] = new DummyCommand();
		}
		
	}
	
	public void executeCommand(int slot) {
		command[slot].execute();
	}
	
	public void setCommand(int slot,Command command) {
		this.command[slot] = command;
	}
}