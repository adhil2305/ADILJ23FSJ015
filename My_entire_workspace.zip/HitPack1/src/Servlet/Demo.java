package Servlet;

public class Demo {


	
	
	
	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.util.Scanner;
	public class TransactionDemo {
		public static void main(String[] args)throws Exception {
			Class.forName("com.mysql.cj.jdbc.Driver");		
			//STEP 2 - Establish the connection
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/javabatch","root","root");
			con.setAutoCommit(false);
			
			Scanner scan=new Scanner(System.in);
			System.out.println("Please enter CREDIT name..:");
			String uname=scan.next();
			System.out.println("Please enter amount..to credit.:");
			int amt=scan.nextInt();
			int currentamt=0;
			
			PreparedStatement ps=con.prepareStatement("select salary from users where username=?");
			ps.setString(1, uname);
			ResultSet rs=ps.executeQuery();
			
			if(rs.next()) {
				currentamt=rs.getInt(1);
			}
			
			ps=con.prepareStatement("update users set salary=? where username=?");
			ps.setInt(1, amt+currentamt);
			ps.setString(2, uname);
			ps.executeUpdate();
			
			System.out.println("Please enter DEBIT name..:");
			uname=scan.next();
			ps=con.prepareStatement("select salary from users where username=?");
			ps.setString(1, uname);
			rs=ps.executeQuery();
			if(rs.next()) {
				currentamt=rs.getInt(1);
			}
			else {
				con.rollback();
			}
			
			ps=con.prepareStatement("update users set salary=? where username=?");
			ps.setInt(1, currentamt-amt);
			ps.setString(2, uname);
			ps.executeUpdate();
			con.commit();
		}
	}





	8:45
	PDF
	 

	Servlet study material.pdf
	PDF











	"goodle










