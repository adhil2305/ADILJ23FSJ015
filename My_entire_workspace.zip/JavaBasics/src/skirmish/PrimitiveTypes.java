package skirmish;


public class PrimitiveTypes{
	
	static byte b;
	static short s;
	static long l;
	static int i ;
	static float f;
	static double d;
	static char c;
	static String str;
	static boolean bl = true;


	
	public static void main(String[] args) {
		
		System.out.println("Byte:"+b);
		System.out.println("Short:"+ s);
		System.out.println("Long"+l);
		
		System.out.println("Int"+i);
		
		System.out.println("Float:"+f);
		
		System.out.println("Double:"+d);
		
		System.out.println("Character:"+c);
		
		//String
		System.out.println("String"+str);
		
		//Boolean gives true or false
		System.out.println("Boolean :" + bl);
		
			
		
	}
}

