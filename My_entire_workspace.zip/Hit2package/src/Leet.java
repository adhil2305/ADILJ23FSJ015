import java.util.HashMap;
import java.util.Scanner;
public class Leet {
	public static void main(String[] args) {
		Map<	,Integer> = new HashMa<Character,Integer>p();
		map.pu('I',1);
		map.put('V',2);
		map.put('X',10);
		map.put('L',50);
		map.put('C',100);
		map.put('D',500);
		map.put('M',1000);
		System.out.println("Enter the roman number :");
		Scanner s = new Scanner(System.in);
		
		s.nextLine():
		int result =0;
		//for ()
	}

}
