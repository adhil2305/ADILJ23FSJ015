package edu.disease.asn2;
import java.util.UUID;
public interface DiseaseControlManager {

	Disease addDisease(String name, boolean infectious);
	
	public void addDiseaseInArray(Disease d);
	
	Disease getDisease(UUID diseaseId);

	Patient addPatient(String firstName, String lastName, int maxDiseases, int maxExposures);

	Patient getPatient(UUID patientId);

	void addDiseaseToPatient(UUID patientId, UUID diseaseId);

	void addExposureToPatient(UUID patientId, Exposure exposure);
}
