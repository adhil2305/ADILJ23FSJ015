package Utilities_Pack_One;

import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class ComparatorIterator {

	
		public static void main(String[] args) {
			List<Student> students=new LinkedList<>();
			
			students.add(new Student("ramu"));
			students.add(new Student("somu"));
			students.add(new Student("adhil"));
			
			System.out.println(students);
			
			System.out.println("The compared array is");
			Collections.sort(students,(o1,o2)->{return o2.compareTo(o1);});
			
			System.out.println(students);
			
			Iterator<Student> iter=students.iterator();
			while(iter.hasNext()) {
				System.out.println(iter.next());
			}
			
			
		}
	}
	class Student implements Comparable<Student>{//this should be always in natural order
		String name;
		public Student(String name) {
			this.name=name;
		}
		@Override
		public String toString() {
			return "The Student Name is..:"+name;
		}
		@Override
		public int compareTo(Student o) {
			return this.name.compareTo(o.name);
		}
	}
//	class MyComparator implements Comparator<Student>
//	{
//		@Override
//		public int compare(Student o1, Student o2) {
//			return o2.compareTo(o1);
//		}
//	}