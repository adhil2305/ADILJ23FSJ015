package edu.disease.asn1;
import java.util.Objects;

import java.util.UUID;
public class Disease{
	// Blueprint of Disease class remember classes hold no memory in java	
	
	/**
	 * UUID is a unique variable which accepts alpha numeric input
	 */
	java.util.UUID diseaseId;
	String name; 
	
	/**
	 * Deploying Getters and setters
	 * @return
	 */
	
	public java.util.UUID getDiseaseId(){
		return this.diseaseId;
	}
	public void setDiseaseId(java.util.UUID diseaseId){
		 this.diseaseId = diseaseId;
	}
	public String getName(){
		return this.name;
	}
	public void setName(String name){
		 this.name = name;
	}
	/**
	 * Getters and setters are dealt with
	 */
	@Override
public int hashCode() {
	return Objects.hash(diseaseId, name);
	}
	
	/**
	 * Override Equals method
	 */
	
	public boolean equals(Object o) {
		Disease d = (Disease)o;
		if(this.name!=d.name) {
			return false;
		}
		else {
			return true;
		}
	}
	public String toString() {
		return  "DiseaseId is "+diseaseId+"Name is "+name;
	}

}
	
