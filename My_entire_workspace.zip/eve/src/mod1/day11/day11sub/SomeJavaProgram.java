package mod1.day11.day11sub;//package should be first line


import java.util.Date;

import mod1.day11.JavaDemo1;
import mod1.day12.HelloWorld;
//import eve.HelloWorld;
/*
 * import creates a name space link....
 */

public class SomeJavaProgram {
	int i;//simple type
	JavaDemo1 obj;
	
	JavaDemo1 obj2;
	
	HelloWorld h;
	eve.HelloWorld h1;
	HelloWorld h2;
	
	Date d;
	java.sql.Date dd;
}
