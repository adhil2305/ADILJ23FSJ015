package Tacos;

public class InheritDemo2 {
		public static void main(String[] args) {
			Pizza meghanaDominos = new DominoPizza();
			meghanaDominos.doPizzaBusiness();
		}
}

abstract class Pizza{
	final private void wheat() {
		System.out.println("Wheat procured as per dominos ..");
	}
	final private void shape() {
		System.out.println("Pizaa shape followed as per dominos ..");
	}
	final private void capcicum() {
		System.out.println("Capcicum got as per Dominos .. ");
	}
	final private void saltAndPepper() {
		System.out.println("Salt and pepper got as per dominos ...");
		
	}
	final private void cheese() {
		System.out.println("MOZERELLLA cheese melted as per Dominos....");
	}
	final private void baking () {
		System.out.println("baked in a wooden charcoal oven ");
		
	}
	final private void packing () {
		System.out.println("packed in a square shaped box");
	}
	//template method 
		final public void cookPizza() {
			wheat();shape();
			capcicum();
			saltAndPepper();
			cheese();
			baking();
			packing ();
			
		}
		
		abstract void collectMoney();
		abstract void sellPizza();
		abstract void deliverPizza();
		//Template Method
		final public void doPizzaBusiness() {
			 sellPizza();collectMoney();deliverPizza();
		}
}

class DominoPizza extends Pizza{
	@Override
	void collectMoney() {
		System.out.println("Collect Money without any taxes...");
	}
	@Override
	void sellPizza() {
		System.out.println("Sell Pizza logic as per my country ...");
	}
	@Override
	void deliverPizza() {
		cookPizza();
		System.out.println("Deliver Pizza in chennai traffic...");
	}
}