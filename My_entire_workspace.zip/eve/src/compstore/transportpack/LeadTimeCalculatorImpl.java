package compstore.transportpack;

public class LeadTimeCalculatorImpl implements LeadTimeCalculator{
	public LeadTimeCalculatorImpl() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public void calculateLeadTime(String data) {
		System.out.println("lead time calculated....");
	}
}
