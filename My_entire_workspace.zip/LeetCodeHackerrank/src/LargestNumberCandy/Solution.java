package LargestNumberCandy;

import java.util.ArrayList;
import java.util.List;

public class Solution {
	public static void main(String[] args) {
		int candies[] = {5,3,1,3};
	System.out.println(Solution.kidsWithCandies( candies, 3));
	}
	
	   public static List<Boolean> kidsWithCandies(int[] candies, int extraCandies) {
	    	   int biggest = 0;
	       for(int i=0;i<candies.length;i++) {
	    	  if( biggest < candies[i]) { 
	    		  biggest=candies[i];
	    			  }
	       }

	       List<Boolean> newList= new ArrayList<>();
	       for(int j=0;j<=candies.length-1;j++) {
	    	   if(extraCandies + candies[j] > biggest) {
	    		   newList.add(true);
	    	   }
	    	   else {
	    		   newList.add(false);
	    	   }
	       }
	       
	       return newList;
	       
	    }
	
}
