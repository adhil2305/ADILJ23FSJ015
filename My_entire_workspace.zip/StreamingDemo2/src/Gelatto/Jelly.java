package Gelatto;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;


public class Jelly {
		public static void main(String[] args) {
			String s4[] = new String[5];
			s4[1] = "HELLO";
			
			List<String> listOfJelly1 = new ArrayList<String>();
			listOfJelly1.add("s"); listOfJelly1.add("x");
			listOfJelly1.add("x"); listOfJelly1.add("k");
			
			Iterator<String> iter = listOfJelly1.iterator();
			while(iter.hasNext()) {
				String s5 = iter.next();
				if(s5.equals("c")) {
					System.out.println("I found c...");
				}
			}
			
			
			if(s4[1] == null) {
				System.out.println("Empty array ...");
				
			}//closing if statement 
			else {
				System.out.println(s4[1].toLowerCase());
			}//closing the else statement 
		String result = Optional.ofNullable(s4[1]).orElse("Ha Ha");
		System.out.println(result.toLowerCase());
		//The below code over here would work only if it is not null
		//Optional.of(s4[1]).ifPresent(i -> System.out.println(i));
		// This code too does not work when the String is null we get a null pointer exveption 
		//Optional.of(s4[1]).ifPresentOrElse(System.out::println, () -> System.out.println("run run run"));
		
		Optional.ofNullable(s4[1]).ifPresentOrElse(Jelly::print, ()->{System.out.println("run run run");});
		
		listOfJelly1.stream().forEach(System.out::println);
	
		listOfJelly1.stream().findAny().of("s").ifPresent(i ->System.out.println("Hello"));
		
		listOfJelly1.stream().parallel().forEachOrdered(System.out::println);
		
		listOfJelly1.stream().forEachOrdered(d -> System.out.println(d+"\t"));
		
		System.out.println();
		listOfJelly1.stream().parallel().forEachOrdered(i->System.out.print(i+"\t"));
		
		}//Closing the main method 
		
		static void print(String s4) {
			System.out.println(s4);
		}
		
}// Closing the main class
