package chatni;

public class LambdaDemo1 {
	public static void main(String[] args) {
		//Mahatma Gandhi way - External/internal class implementation
		Inter in1=new InterImpl();
		in1.met();
		
		//IndraGandhi Way - Anonymous inner class
		new Inter() {			
			@Override
			public void met() {
				System.out.println("indhra gandhi way.....");
			}
		}.met();
		
		//RahulGandhi Way - Lambda
		
		Inter in2=()->System.out.println("rahul gandhi way....");
		in2.met();
		
		//PriyankaGandhi Way - Method Referencing
		Inter in3= new LambdaDemo1()::myOwnMetMethodCreatedByVadodra;
		in3.met();
		
	}
	public void myOwnMetMethodCreatedByVadodra() {
		System.out.println("my own met method implementation.....");
	}
}
interface Inter{
	public void met();
}
//Mahatma Gandhi way
class InterImpl implements Inter{
	@Override
	public void met() {
		System.out.println("mahatma gandhi way............");
	}
}
