package Natchos;

public class ConsDemonstration {
	public static void main(String[] args) {
		// While using the child class to create a constructor 
		// you must be using the constructor you have defined
		// as the empty constructor is unavailable when
		// you use a parameterized constructor.
		
		MySeniorSuper sup = new MySub("Blur");
		sup.met();
		System.out.println(sup.isuper);
		// s - solid responsibitliy 
		// o - open close principle
		
		// liscow substitution principle the child can replace the parent
		// code 
		// compostion 
		// object re usability
		
		
		//
		//dependency inversion priciple 
	
	}
}

class MySeniorSuper{
	int isuper = 100;
	public MySeniorSuper(int i) {
		//TODO auto generated constructor 
	}
	protected void met() {
		System.out.println("met of super senior called ...");
	}
}

class MySuper extends MySeniorSuper{
	int isuper= 200;// This does not override the variable... 
	public MySuper(String s) {
		super(100);
		System.out.println("Constructor of MySenior called ...");
		//ToDO auto generated constructor
		
	}
	public void met() {
		System.out.println(" Met of the sub senior called... ");
		super.met();
	}
}

class MySub extends MySuper{
	int isuper = 300;
	public MySub(String s) {
		super("blabla");
		System.out.println("sub... :"+s);
	}
	
	public void met() {
		System.out.println("met of sub.." + isuper);
		super.met();
	}
}

