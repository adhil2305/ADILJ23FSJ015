package StackDSAorLifo;

import java.util.Scanner;

public class Demo1 {
	public static void main(String[] args) {
		
		int arr[] = new  int[4];
		Scanner scan  = new Scanner(System.in);
		System.out.println("Enter a number");
		
		int top  = -1;
		
		for (int i=0;i<arr.length-1;i++) {
			top++;
			arr[top] = scan.nextInt();
			
		}
		System.out.println(arr[top]);
		scan.close();

		
	}
}
