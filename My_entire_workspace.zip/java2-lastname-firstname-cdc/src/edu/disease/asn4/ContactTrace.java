package edu.disease.asn4;

import edu.disease.asn3.DiseaseControlManager;

import edu.disease.asn3.DiseaseControlManagerImpl;
import edu.disease.asn3.Exposure;
import edu.disease.asn3.Patient;

import java.time.LocalDateTime;
import java.util.UUID;



public class ContactTrace {
	DiseaseControlManager obj;
	
	public ContactTrace(DiseaseControlManager obj) {
		this.obj=obj;
	}
	
	public static void main(String[] args) {
//		
//		// Constructing the patient hierarchy chain (refer diagram for visual representation).
//		DiseaseControlManager diseaseControlManager=new DiseaseControlManagerImpl();
//		
//		// Creating patient objects and setting their Unique random UUID
//		Patient p1=diseaseControlManager.addPatient("p", "1", 1, 3);
//		p1.setPatientId(UUID.randomUUID());
//		Patient pOne=diseaseControlManager.addPatient("p", "11", 1, 3);
//		pOne.setPatientId(UUID.randomUUID());
//		Patient p2=diseaseControlManager.addPatient("p", "2", 1, 4);
//		p2.setPatientId(UUID.randomUUID());
//		Patient p3=diseaseControlManager.addPatient("p", "3", 1, 2);
//		p3.setPatientId(UUID.randomUUID());
//		Patient p4=diseaseControlManager.addPatient("p", "4", 1, 2);
//		p4.setPatientId(UUID.randomUUID());
//		Patient p5=diseaseControlManager.addPatient("p", "5", 1, 1);
//		p5.setPatientId(UUID.randomUUID());
//		Patient p6=diseaseControlManager.addPatient("p", "6", 1, 1);
//		p6.setPatientId(UUID.randomUUID());
//		Patient p7=diseaseControlManager.addPatient("p", "7", 1, 4);
//		p7.setPatientId(UUID.randomUUID());
//		
//		diseaseControlManager.addPatientInArray(p1);
//		diseaseControlManager.addPatientInArray(p7);
//		diseaseControlManager.addPatientInArray(pOne);
//		diseaseControlManager.addPatientInArray(p2);
//		diseaseControlManager.addPatientInArray(p3);
//		diseaseControlManager.addPatientInArray(p4);
//		diseaseControlManager.addPatientInArray(p5);
//		diseaseControlManager.addPatientInArray(p6);
//		
//		// Creating exposures for p1 and adding them in p1's exposure array
//		
//		Exposure e1p1=new Exposure(p1.getPatientId());
//		e1p1.setExposureType("I");
//		Exposure e2p1=new Exposure(pOne.getPatientId());
//		e2p1.setExposureType("I");
//		Exposure e3p1=new Exposure(p2.getPatientId());
//		e3p1.setExposureType("D");
//		e3p1.setDateTime(LocalDateTime.of(2023,12,31,6,0));
//
//		diseaseControlManager.addExposureToPatient(p1.getPatientId(),e1p1);
//		diseaseControlManager.addExposureToPatient(p1.getPatientId(),e2p1);
//		diseaseControlManager.addExposureToPatient(p1.getPatientId(),e3p1);
//		
//		
//		// Creating exposures for p2 and adding them in p2's exposure array
//		Exposure e1p2=new Exposure(p3.getPatientId());
//		e1p2.setExposureType("D");
//		e1p2.setDateTime(LocalDateTime.of(2023,12,29,5,0));
//		Exposure e2p2=new Exposure(UUID.randomUUID());
//		e2p2.setExposureType("I");
//		Exposure e3p2=new Exposure(UUID.randomUUID());
//		e3p2.setExposureType("I");
//		Exposure e4p2=new Exposure(p4.getPatientId());
//		e4p2.setExposureType("D");
//		e4p2.setDateTime(LocalDateTime.of(2023,12,20,21,34));
//		
//		diseaseControlManager.addExposureToPatient(p2.getPatientId(),e1p2);
//		diseaseControlManager.addExposureToPatient(p2.getPatientId(),e2p2);
//		diseaseControlManager.addExposureToPatient(p2.getPatientId(),e3p2);
//		diseaseControlManager.addExposureToPatient(p2.getPatientId(),e4p2);
//		
//		
//		// Creating exposures for p3 and adding them in p3's exposure array
//		Exposure e1p3=new Exposure(UUID.randomUUID());
//		e1p3.setExposureType("I");
//		Exposure e2p3=new Exposure(UUID.randomUUID());
//		e2p3.setExposureType("I");
//		
//		diseaseControlManager.addExposureToPatient(p3.getPatientId(),e1p3);
//		diseaseControlManager.addExposureToPatient(p3.getPatientId(),e2p3);
//		
//		
//		// Creating exposures ford p4 and adding them in p4's exposure array
//		Exposure e1p4=new Exposure(p5.getPatientId());
//		e1p4.setExposureType("D");
//		e1p4.setDateTime(LocalDateTime.of(2023,12,19,15,12));
//		Exposure e2p4=new Exposure(p6.getPatientId());
//		e2p4.setExposureType("D");
//		e2p4.setDateTime(LocalDateTime.of(2023,12,19,13,17));
//
//		diseaseControlManager.addExposureToPatient(p4.getPatientId() ,e1p4);
//		diseaseControlManager.addExposureToPatient(p4.getPatientId(),e2p4);
//		
//		
//		// Creating exposures for p5 and adding them in p5's exposure array
//		Exposure e1p5=new Exposure(p7.getPatientId());
//		e1p5.setExposureType("D");
//		e1p5.setDateTime(LocalDateTime.of(2023,12,16,12,0));
//		diseaseControlManager.addExposureToPatient(p5.getPatientId(),e1p5);
//		
//		
//		// Creating exposures for p6 and adding them in p6's exposure array
//		Exposure e1p6=new Exposure(UUID.randomUUID());
//		e1p6.setExposureType("I");
//		diseaseControlManager.addExposureToPatient(p6.getPatientId(),e1p6);
//		
//		
//		// Creating exposures for p7 and adding them in p7's exposure array
//		Exposure e1p7=new Exposure(p3.getPatientId());
//		e1p7.setExposureType("I");
//		Exposure e2p7=new Exposure(UUID.randomUUID());
//		e2p7.setExposureType("I");
//		Exposure e3p7=new Exposure(UUID.randomUUID());
//		e3p7.setExposureType("I");
//		Exposure e4p7=new Exposure(p4.getPatientId());
//		e4p7.setExposureType("I");
//		diseaseControlManager.addExposureToPatient(p7.getPatientId(),e1p7);
//		diseaseControlManager.addExposureToPatient(p7.getPatientId(),e2p7);
//		diseaseControlManager.addExposureToPatient(p7.getPatientId(),e3p7);
//		diseaseControlManager.addExposureToPatient(p7.getPatientId(),e4p7);
//		
//		
//		// Creating the contact trace object.
//		ContactTrace ct=new ContactTrace(diseaseControlManager);
//		//invoke the findPatientZero method for other patients and test the answer.
//		PatientZero findPatientZero = ct.findPatientZero(p1);
//		
//		if(findPatientZero==null) {
//			// patient has no direct exposure
//		}else {
//			System.out.println(findPatientZero.getPatient().getFirstName()+
//					findPatientZero.getPatient().getLastName()+
//					" and Date & time is "+findPatientZero.getExposureDateTime());
//		}
	}
	
	/*
	 * findPatientZero method.
	 */
	public PatientZero findPatientZero(Patient p){
		PatientZero earliestPatient=null;
		
		Exposure[] exposures=p.getExposure();
		
		for(int i=0;i<exposures.length;i++) {
			Exposure exposure=exposures[i];
			
			//convert exposure into patient.
			UUID exposurePatientId=exposure.getPatientId();
			Patient exposedPatient=obj.getPatient(exposurePatientId);
			
			//get exposure Date & time
			LocalDateTime exposureDateTime = exposure.getDateTime();
			
			//get exposureType
			String exposureType=exposure.getExposureType();
			
			// check the exposure type and filter only the Direct exposures
			if(exposureType.equals("D")) {
				
				
				if(earliestPatient==null) {
					earliestPatient=new PatientZero();
					
					//the first direct exposure is the answer.
					earliestPatient.setPatient(exposedPatient);
					earliestPatient.setExposed(true);
					earliestPatient.setExposureDateTime(exposureDateTime);
				}
				else if(exposureDateTime.isBefore(earliestPatient.getExposureDateTime())) {
					
					earliestPatient.setPatient(exposedPatient);
					earliestPatient.setExposed(true);
					earliestPatient.setExposureDateTime(exposureDateTime);
				}
				
				PatientZero patientZeroInExposedPatient=findPatientZero(exposedPatient);
				
				if(patientZeroInExposedPatient==null) {
					// no direct exposure for Exposed Patient.
				}
				else if(patientZeroInExposedPatient.getExposureDateTime().isBefore(earliestPatient.getExposureDateTime())) {
					//get the patient from earliestPatientInExposedPatient
					Patient earliestPatientInExposedPatient = patientZeroInExposedPatient.getPatient();
					
					//get the exposure date and time from earliestPatientInExposedPatient
					LocalDateTime exposureDateTimeInExposedPatient = patientZeroInExposedPatient.getExposureDateTime();
					
					earliestPatient.setPatient(earliestPatientInExposedPatient);
					earliestPatient.setExposed(true);
					earliestPatient.setExposureDateTime(exposureDateTimeInExposedPatient);
				}
			}
		}
		return earliestPatient;
	}
}
