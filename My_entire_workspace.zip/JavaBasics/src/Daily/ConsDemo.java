package Daily;

public class ConsDemo {
	public static void main(String[] args) {
		Cons1 obj=new Cons1("aa",12,new Employee1());
		new Cons1();
		new Cons1();
		
	}
}
class Cons1{
	public Cons1() {
		System.out.println("cons1 empty cons called...");
	}

	public Cons1(String s) {
		System.out.println("cons1 String cons called.....");
	}
	public Cons1(String s,int i,Employee1 e) {
		System.out.println("cons1 string,int,employee cons called...");
	}
}
class Employee1{}
