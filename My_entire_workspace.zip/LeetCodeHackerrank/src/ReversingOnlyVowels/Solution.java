package ReversingOnlyVowels;

import java.util.HashSet;
import java.util.Stack;

public class Solution {
	public static void main(String[] args) {
		Solution s1 = new Solution();
		System.out.print(s1.VowelReverse("LeetCode"));
	}
	
	
	public String VowelReverse(String s) {
	  Stack<Character> vowelsInTheString = new Stack<>();
      HashSet<Character> vowels = new HashSet<Character>() {{
          add('a'); add('e'); add('o'); add('u'); add('i');
          add('A'); add('E'); add('O'); add('U'); add('I');
      }};
      HashSet<Integer> indexesOfVowels = new HashSet<>();
      
      //Pass the given String to the StringBuilder to perform operations 
      
      StringBuilder result = new StringBuilder(s);
     
      // System.out.println(result);
      for (int i = 0; i < s.length(); i++) {
          if(vowels.contains(s.charAt(i))) {
              vowelsInTheString.push(s.charAt(i));
              indexesOfVowels.add(i);
          }
      }
      for (int i = 0; i < s.length(); i++) {
          if (indexesOfVowels.contains(i)) {
        	  
              result.setCharAt(i, vowelsInTheString.pop());
          }
      }

      return result.toString();
  }
}
