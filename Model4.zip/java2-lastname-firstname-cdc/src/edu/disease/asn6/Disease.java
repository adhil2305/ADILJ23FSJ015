package edu.disease.asn6;

import java.io.Serializable;
import java.util.Objects;
import java.util.UUID;
public abstract class Disease implements Serializable{
	/*
	 * The serialized class must have the below property specified property 
	 * as a good Practice 
	 */
	private static final long serialVersionUID = 1L;

	
	private UUID diseaseId;
	private String name;
	
	public Disease(UUID diseaseId, String name) {
		this.diseaseId = diseaseId;
		this.name = name;
	}
	public Disease() {
		
	}
	public abstract String[] getExamples();
	
	public UUID getDiseaseId() {
		return diseaseId;
	}

	
	public void setDiseaseId(UUID diseaseId) {
		this.diseaseId = diseaseId;
	}

	
	public String getName() {
		return name;
	}

	
	public void setName(String name) {
		this.name = name;
	}

	
	@Override
	public int hashCode() {
		return Objects .hash(diseaseId);
	}

	
	@Override
	public boolean equals(Object obj) {
		Disease d = (Disease) obj;
		if (diseaseId != null && d.getDiseaseId() != null) {
			return this.hashCode() == d.hashCode();
		}
		return false;
	}

	@Override
	public String toString() {
		return "Disease [diseaseId=" + diseaseId + ", name=" + name + "]";
	}
	

}