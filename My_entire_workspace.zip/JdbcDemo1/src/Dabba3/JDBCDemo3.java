package Dabba3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class JDBCDemo3 {


		public static void main(String[] args) throws Exception{
			//STEP 1 - registering the driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//STEP 2 - Establish the connection
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/javabatch","root","root");
			String sql="select * from users where userid=?";//dynamic query
			PreparedStatement stmt=con.prepareStatement(sql);
			
			while(true) {
}