package BufferDemo1;

public class Demo1 {

	
	import java.io.BufferedReader;
	import java.io.FileOutputStream;
	import java.io.FileWriter;
	import java.io.InputStream;
	import java.io.InputStreamReader;
	import java.net.URL;
	import java.net.URLConnection;
	import java.nio.charset.Charset;
	public class UrlIODemo2 {
		public static void main(String[] args)throws Exception {
			URL url=new URL("https://www.google.com/index.html");
			
			URLConnection urlcon= url.openConnection();
			
			InputStream is=urlcon.getInputStream();
			BufferedReader bi=new BufferedReader(new InputStreamReader(is));
			//FileOutputStream fos=new FileOutputStream("google.html");
			FileWriter fow=new FileWriter("google2.html",Charset.forName("UTF-8"));
			
			int x=0;
			//byte b[]=new byte[256];
			char c[]=new char[256];
			while((x=bi.read(c))!=-1) {
				String s=new String(c,0,x);
				System.out.println(s);
				fow.write(s);
			}
		}
	}
	package netpack;
	import java.io.BufferedInputStream;
	import java.io.ByteArrayInputStream;
	import java.io.StringBufferInputStream;
	public class BufferDemo {
		public static void main(String[] args)throws Exception {
			String str="jack and jill &copy; went up the &copy hill to fetch water......";
			
			//StringBufferInputStream sbis=new StringBufferInputStream(str);
			
			ByteArrayInputStream bytearray=new ByteArrayInputStream(str.getBytes());
			
			BufferedInputStream bis = new BufferedInputStream(bytearray);
			
			int x=0;boolean marked=false;
			while((x=bis.read())!=-1) {
				char c=(char)x;
				
				switch(c){
				case '&':{
					bis.mark(50);
					marked=true;
					break;
				}
				case ';':{
					if(marked) {
						System.out.print((char)169);
						marked=false;
						System.out.print(" ");
					}
					else {
						System.out.print(c);
					}
					break;
				}
				case ' ':{
					if(marked) {
						bis.reset();
						System.out.print("&");
						marked=false;
					}else {
						System.out.print(c);
					}
					break;
				}
				default:{
					if(!marked) {
						System.out.print(c);
					}
				}
				}
			}
			
		}
	}
	google.comgoogle.com
	Seasonal Holidays 2023
	Happy Holidays! #GoogleDoodle (354 kB)
	Seasonal Holidays 2023




	haarisinfotech
	  8:07 PM
	package netpack;
	import java.io.FileInputStream;
	import java.io.FileOutputStream;
	import java.io.ObjectInputStream;
	import java.io.ObjectOutputStream;
	import java.io.Serializable;
	public class SerializationDemo {
		public static void main(String[] args) throws Exception{
			Laddu myladdu=new Laddu();
			System.out.println("Original size..:"+myladdu.size);
			FileOutputStream fos=new FileOutputStream("laddu.dat");
			ObjectOutputStream oos=new ObjectOutputStream(fos);
			oos.writeObject(myladdu);
			
			System.out.println("abraka dabra the laddu initial state is saved....");
			myladdu.size=5;//ate the laddu 50%...
			System.out.println("After eating...laddu size..:"+myladdu.size);
			
			System.out.println("abra ka dabra...get back the original laddu....");
			
			FileInputStream fis=new FileInputStream("laddu.dat");
			ObjectInputStream ois=new ObjectInputStream(fis);
			
			myladdu=(Laddu)ois.readObject();
			System.out.println("After restoring...laddu size...:"+myladdu.size);
			
		}
	}
	class Laddu implements Serializable{
		int size=10;
	}


	haarisinfotech
	  8:37 PM
	package netpack;
	import java.io.BufferedReader;
	import java.io.InputStreamReader;
	import java.io.PrintWriter;
	import java.net.ServerSocket;
	import java.net.Socket;
	public class ChatServer {
		ServerSocket ss;Socket s;
		BufferedReader in,keyin;
		PrintWriter out;
		public ChatServer() {
			try {
			
				ss=new ServerSocket(2000);
				System.out.println("Server waiting.
}