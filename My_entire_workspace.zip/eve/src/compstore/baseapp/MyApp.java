package compstore.baseapp;

public class MyApp {

}
