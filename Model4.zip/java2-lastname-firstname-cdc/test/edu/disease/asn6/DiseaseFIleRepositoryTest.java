package edu.disease.asn6;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.junit.Test;

public class DiseaseFIleRepositoryTest {

	@Test
	public void testTheSaveMet() {
	//	fail("Not yet implemented");
		
		

		Patient p1 = new Patient();
		p1.setFirstName("Drake");
		p1.setPatientId(UUID.randomUUID());
		Disease d1 = new InfectiousDisease();
		d1.setName("flu");
		List<Disease> diseases = new ArrayList<Disease>();
		List<Patient> patients = new ArrayList<>();
		patients.add(p1);
		diseases.add(d1);
		DiseaseFIleRepository dp = new DiseaseFIleRepository();
				
		dp.setFolderPath("F:/cat");
		dp.save(diseases, patients);
		dp.init("F:/cat");
				
		DiseaseAndPatient dpTester = dp.init("F:/cat");
		List<Patient> p2 = dpTester.getPatients();
		Patient p3 = p2.get(0);
		System.out.println("madrid");
		System.out.println(p3.getFirstName());
		System.out.println(p1.getFirstName());
		List<Disease> d2 = dpTester.getDiseases();
		Disease d3 = d2.get(0);
		d1.getName();
		
		assertEquals(p1.getFirstName(), p3.getFirstName());
		assertEquals(d3.getName(), d1.getName());

				
	}

}
