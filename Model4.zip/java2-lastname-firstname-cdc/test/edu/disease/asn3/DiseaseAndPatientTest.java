package edu.disease.asn3;

import static org.hamcrest.CoreMatchers.instanceOf;
import static org.junit.Assert.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.UUID;

import org.junit.Test;

import edu.disease.asn1.Exposure;

public class DiseaseAndPatientTest {

	//@Test
	// public void testConstructor() {}
	
	@Test
	public void testSetter() {
		Disease[] diseases = new Disease[1];
		Disease d = new InfectiousDisease();
		diseases[0] = d;
		DiseaseAndPatient dp = new DiseaseAndPatient();
		dp.setDiseases(diseases);
		
		Disease[] getdp = dp.getDiseases();
		assertEquals(getdp, diseases);
	}
	@Test
	public void testSaveMet1() {
		DiseaseAndPatient dp = new DiseaseAndPatient();
		dp.setFolderPath("F:/cat");
		Disease[] diseases = new Disease[1];
		Patient[] patients = new Patient[1];
		Disease d1 = new InfectiousDisease();
		Patient p1 = new Patient();
		patients[0] = p1;
		diseases[0] = d1;
		dp.save(diseases, patients);
		DiseaseAndPatient dp1 = dp.init("F:/cat");
		boolean b = true;
		if (dp1 instanceof DiseaseAndPatient) {
			b = true;
		}else {
		}
		assertEquals( b, true);
	}
	
	@Test
	public void testInvalidValue() {
		DiseaseAndPatient e = new DiseaseAndPatient();
		Disease[] diseases = new Disease[1];
		Patient[] patients = new Patient[1];
		Disease d1 = new InfectiousDisease();
		diseases[0] = d1;
		Patient p1 =new Patient();
		patients[0] = p1;
		assertThrows(IllegalArgumentException.class, ()->e.init("hello"));
		}
}