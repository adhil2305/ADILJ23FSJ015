package Hit;

public class Prototype {
	public static void main(String[] args) {
		 MyInter myinter = new MyInterImpl();
		 myinter.met();
		 
		 MyInter myinter2 = new MyInter(){
				
				@Override
				public void met() {
					System.out.println("anonymous way..............");
				}
			};
			 myinter2.met();
			 MyInter myInterLamdaWay = ()->{System.out.println("The stupid Lambda way ....");};
			 myInterLamdaWay.met(); 
			 
			 MyInter2 myInter4 = () -> {return 100;};
			 System.out.println(myInter4.met());
			 
			 MyInter3 myinter5 = (String s, int h) -> {System.out.println("hello this is a parameterised lambda expression " +h);
			 return s;
			 };
			System.out.println( myinter5.met("eve-aspire", 50));
	}
}

interface MyInter{
public void met();	
}


  class MyInterImpl implements MyInter{
  
  @Override public void met() { System.out.println("hello1"); } 
  }
 
  
  interface MyInter2 {
	  public int met();
  }
  interface MyInter3{
	  public String met(String s, int i);
  }