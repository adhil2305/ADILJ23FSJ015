package skirmish;

import java.util.Scanner;

public class Addition {
	public static void main(String[] args) {
		System.out.println("Enter two numbers...");
		int first = 100;
		int second = 200;
		System.out.println(first+" "+second);
		//add tow numbers 
		int sum1 = first + second;
		System.out.println("The sum is "+ sum1);
		
	  	   Scanner sc = new Scanner(System.in);
	  	   int n=sc.nextInt();
	  	  int sum=0;
	  	  sc.close();
		
		int i=0;
		while(i<=n){
		  if(i%3==0){
		  sum = sum + i;
		}	
		  i = i+2;
		}

		System.out.print(sum);
		
		
		
		
		
		
	}

}


