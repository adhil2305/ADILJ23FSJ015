package ORANGEJUICE;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class OjClass {
		public static void main(String[] args) {
			ExecutorService es = Executors.newFixedThreadPool(2);
			CounsellingHall hall = new CounsellingHall();
			
			es.execute(()-> {
				Thread.currentThread().setName("red");
				hall.table1(); hall.table2();hall.table3();
				
				
			});
			es.execute(()->{
				Thread.currentThread().setName("blue");
				hall.table1();hall.table2();hall.table3();
				
			});
			
			es.execute(() -> {
				Thread.currentThread().setName("yellow");
				hall.drinkWater();hall.table1();hall.table2();hall.table3();
			});
			es.shutdown();
		}
}

class CounsellingHall{
	synchronized public void table1() {
		String name = Thread.currentThread().getName();
		System.out.println(name+" is in the table1 now");
		try {Thread.sleep(9000);}catch(Exception e) {e.printStackTrace();}
		System.out.println(name+" is out of table1");
		}
	synchronized public void table2() {
		String name = Thread.currentThread().getName();
		System.out.println(name+" is in Table2 now ");
		try {Thread.sleep(9000);}catch(Exception e) {e.printStackTrace();}
		System.out.println(name+ " is now out of table2 ..");
	}
	synchronized public void table3(){
		String name = Thread.currentThread().getName();
		System.out.println(name+ " is now in table3 ");
		try {Thread.sleep(9000);}catch(Exception e) {e.printStackTrace();}
		System.out.println(name+ " is now out of table3");
	}
	protected void drinkWater() {
		String name = Thread.currentThread().getName();
		System.out.println(name+" is now drinking water");
		try {Thread.sleep(9000);}catch(Exception e) {e.printStackTrace();}
		System.out.println(name+" is now leaving the water drinking area");
	}
}
