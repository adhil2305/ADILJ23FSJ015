package edu.disease.asn2;

public class Exposure {

}
