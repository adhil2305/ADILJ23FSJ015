package Mayo;
import java.util.Properties;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.Iterator;
import java.io.FileInputStream;



public class PropertiesDemo {
public static void main(String[] args) {
	Properties props = new Properties();
	//HashMap props = new HashMap();
	//props.put(a1,"Hello" );
	//props.put(a2, "Hai")
	props.load(new FIleInputStream("config.properties"));
	System.out.println(props.get(a1));
	Set set = props.entrySet();
	Iterator iter = set.iterator();
	while(iter.hasNext()) {
		Map.Entry me  = (Map.Entry)iter.next();
		System.out.println(me.getkey()+":"+me.getvalue());
		
	}
}
}
