package VeryBasic;


import java.sql.Connection;
import java.sql.DriverManager;
public class JDBCDemo1 {
	public static void main(String[] args)throws Exception {
		//STEP 1 - registering the driver
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		//STEP 2 - Establish the connection
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost/javabatch","root","root");
		
		System.out.println(con);
		
	}
}
package jdbcproj;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
public class JDBCDemo2 {
	public static void main(String[] args) throws Exception{
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost/javabatch","root","root");
		
		String sql="update users set flag=0";
		
		Statement stmt=con.createStatement();
		
		int n=stmt.executeUpdate(sql);//this returns the number of rows affected
		
		
		System.out.println(n);
		
	}
}
