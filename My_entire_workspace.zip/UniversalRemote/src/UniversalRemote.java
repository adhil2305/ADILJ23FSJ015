
/**
 * @author Adhil
 *
 */
public class UniversalRemote {
public static void main(String[] args) {
	
	System.out.println("Demonstration of remote...");
	Tv tv = new Tv();
	SetTopBox settopbox = new SetTopBox();
	NetFlix netflix = new NetFlix();
	SoundSystem soundsystem = new SoundSystem;
	
	FatherNewsChannelCommand fncc = new FatheNewsChannelCommand();
	
	FatherNewsChannelCommand(tv,settopbox,netflix,soundsystem);
	
	Remote UniversalRemote = new Remote();
}
}
