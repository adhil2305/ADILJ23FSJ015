+package Doritos;

public class InnerDemo3 {
	public static void main(String[] args) {
		Outer3 obj=new Outer3();
		obj.Outer3Method();
		/*
		 * Rules
		 * 1. Outer3 class object cannot access inner class methods
		 * 2. But Inner classes can access Outer3 class methods.
		 * 3. Outer3 class can create object of inner class
		 *
		 */
		//below code create objects of inner class
		
		Outer3.Inner inn=new Outer3().new Inner();
		Outer3.Inner inn2=obj.new Inner();
		inn2.innerMethod();
		
		//below code create objects of static inner class
		
		Outer3.StaticInner sinn=new Outer3.StaticInner();
		sinn.staticInnerMethod();
		
	}
}

/*
Inner Class concept is used for better encapsulation..
Types of inner class
1. Inner class non staic and Inner class static
2. Local Inner Class
3. Anonymous Inner class
*/
class Outer3{
	public void Outer3Method() {
		//System.out.println(innerX);cannot access inner class variable or methods.
		
		//below code creates an object of inner class in Outer3 class method
		Inner obj = new Inner();
		obj.innerMethod();
		System.out.println(obj.innerX);
		
		//below code creates an object of static inner class in Outer3 class method
		Outer3.StaticInner obj2=new Outer3.StaticInner();
		obj2.staticInnerMethod();
		}
	public void staticOuter3Method() {}
	int x=100;
	static int staticX=100;
	class Inner{
		int innerX=1000;
		public void innerMethod() {
			Outer3Method();
			staticOuter3Method();
			System.out.println(x+":"+staticX);
		}
	}
	static class StaticInner{
		public void staticInnerMethod() {
			//can only access static methods of Outer3 class
			staticInnerMethod();
			System.out.println(staticX);//can only access static variables of Outer3 class
		}
	}
}

