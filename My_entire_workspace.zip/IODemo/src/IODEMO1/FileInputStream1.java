package IODEMO1;
import java.io.FileReader;
import java.io.FileWriter;
import java.nio.charset.Charset;

public class FileInputStream1 {
		public static void main(String[] args) {
			
			
			try(
					FileReader fir=new FileReader("nightwing.properties",Charset.forName("UTF-8"));
					FileWriter fiw=new FileWriter("copy2.html",Charset.forName("UTF-8"));
					){
					//System.out.println((char)fir.read());
					
					int x=0;
					char c[]=new char[4];
					fiw.write("<html><meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />");
					
					while((x=fir.read(c))!=-1) {
						String s=new String(c,0,x);
						System.out.println(s);
						fiw.write(c,0,x);
					}
					fiw.write("</html>");
					}catch(Exception e) {e.printStackTrace();}
					
		}
	}


	  