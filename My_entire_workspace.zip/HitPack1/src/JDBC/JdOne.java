package JDBC;

public class JdOne {

}



haarisinfotech
  8:22 PM
package junitproj;
import java.time.LocalDate;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
public class Calculator {
	public int add(int i,int j) {
		return i+j;
	}
	public int mul(int i,int j) {
		return i*j;
	}
	
	public int calculateDateDif(LocalDate sd, LocalDate ed) {
		return (int)sd.until(ed).getDays();
	}
	
	public int[] reverseArray(int a[]) {
		int length=a.length;
		int revarray[]=new int[length];
		for(int i=0;i<length;i++) {
			revarray[i]=a[length-1 -i];
		}
		return revarray;
	}
	
	public List<Employee> sortColBySal(List<Employee> emplist){
		Collections.sort(emplist,(e1,e2)->{return e1.compareTo(e2);});
		return emplist;
	}
}
class Employee implements Comparable<Employee>{
	String name;
	Integer salary;
	public Employee(String name,Integer salary) {
		this.name=name;
		this.salary=salary;
	}
	
	@Override
	public int compareTo(Employee o) {
		// TODO Auto-generated method stub
		return this.salary.compareTo(o.salary);
	}
}
package junitproj;
import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import org.junit.Test;
public class CalculatorTest {
	
	@Test
	public void testAdd() {
		Calculator calc=new Calculator();
		int result=calc.add(10,10);
		
		assertEquals(20, result);//the first param is expected and second is actual
	}
	@Test
	public void testMul() {
		Calculator calc=new Calculator();
		int result=calc.mul(4, 10);
		assertEquals(40, result);
	}
	@Test
	public void testDateDiffMethod() {
		Calculator calc=new Calculator();
		
		LocalDate date1=LocalDate.of(2023, 1, 20);
		LocalDate date2=LocalDate.of(2023, 1, 21);
		
		int result=calc.calculateDateDif(date1, date2);
		assertEquals(1, result);
	}
	
	@Test
	public void testRevArray() {
		int a[]= {1,2,3,4,5};
		int rv[]= {5,4,3,2,1};
		
		Calculator calc=new Calculator();
		int result[]=calc.reverseArray(a);
		assertArrayEquals(rv, result);//this method is capable of comparing two arrays
	}
	
	@Test
	public void testSortCol() {
		Employee e1=new Employee("rahim",40000);
		Employee e2=new Employee("ram",50000);
		Employee e3=new Employee("john",60000);
		
		List<Employee> mylist=Arrays.asList(e1,e2,e3);
		Calculator calc=new Calculator();
		List<Employee> result=calc.sortColBySal(mylist);
		
		assertEquals(mylist, result);
	}
}


haarisinfotech
  3:42 PM
Binary
 

mysql-installer-community-8.0.29.0.msi
Binary




haarisinfotech
  3:57 PM
Binary
 

mysql-connector-java-8.0.20.jar
Binary


3:58
PDF
 

JDBC study material.pdf
PDF




haarisinfotech
  9:03 PM
package jdbcproj;
import java.sql.Connection;
import java.sql.DriverManager;
public class JDBCDemo1 {
	public static void main(String[] args)throws Exception {
		//STEP 1 - registering the driver
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		//STEP 2 - Establish the connection
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost/javabatch","root","root");
		
		System.out.println(con);
		
	}
}
package jdbcproj;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
public class JDBCDemo2 {
	public static void main(String[] args) throws Exception{
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost/javabatch","root","root");
		
		String sql="update users set flag=0";
		
		Statement stmt=con.createStatement();
		
		int n=stmt.executeUpdate(sql);//this returns the number of rows affected
		
		
		System.out.println(n);
		
	}