package skirmish;

public class DoWhile {
	public static void main(String[] args) {
		int x=1;
		do {
			System.out.println("The value os x is "+x);
			x++;
			System.out.println();
		}while(x<11);
	}

}
