package BroastAlFarooj;

public class Gcd {
		public static void main(String[] args) {
			System.out.println(Gcd.hello(40, 60));
			System.out.println("This is" + 7%60);
		}
		public static int hello(int n1, int n2) {
			if(n1==0 && n2==0) {
				return 1;
			}
			else if (n2==0){
				return n1;
			}
			else {
				return hello(n2, n1%n2);
			}
		}
}
