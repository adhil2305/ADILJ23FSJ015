package Chrome;

public class Demo1 {

}


import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
public class SerializationDemo {
	public static void main(String[] args) throws Exception{
		Laddu myladdu=new Laddu();
		System.out.println("Original size..:"+myladdu.size);
		FileOutputStream fos=new FileOutputStream("laddu.dat");
		ObjectOutputStream oos=new ObjectOutputStream(fos);
		oos.writeObject(myladdu);
		
		System.out.println("abraka dabra the laddu initial state is saved....");
		myladdu.size=5;//ate the laddu 50%...
		System.out.println("After eating...laddu size..:"+myladdu.size);
		
		System.out.println("abra ka dabra...get back the original laddu....");
		
		FileInputStream fis=new FileInputStream("laddu.dat");
		ObjectInputStream ois=new ObjectInputStream(fis);
		
		myladdu=(Laddu)ois.readObject();
		System.out.println("After restoring...laddu size...:"+myladdu.size);
		
	}
}
class Laddu implements Serializable{
	int size=10;
}







haarisinfotech
  8:37 PM
package netpack;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
public class ChatServer {
	ServerSocket ss;Socket s;
	BufferedReader in,keyin;
	PrintWriter out;
	public ChatServer() {
		try {
		
			ss=new ServerSocket(2000);
			System.out.println("Server waiting......");
			while(true) {
			s=ss.accept();
			keyin=new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Please enter a Message for Client..:");
			String msg=keyin.readLine();
			
			out=new PrintWriter(s.getOutputStream(),true);
			out.println(msg);
			
			in=new BufferedReader(new InputStreamReader(s.getInputStream()));
			String msgFromClient=in.readLine();
			System.out.println("Message From Client...:"+msgFromClient);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		new ChatServer();
	}
}
package netpack;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.net.Socket;
//public class ChatClient {
	Socket s;BufferedReader in,keyin;PrintWriter out;
	public ChatClient() {
		try {
			while(true) {
			s=new Socket("localhost",2000);
			in=new BufferedReader(new InputStreamReader(s.getInputStream()));
			String msgFromServer=in.readLine();
			System.out.println("Message From Server...:"+msgFromServer);
			
			
			keyin=new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Please enter a message for server..:");
			String msg=keyin.readLine();
			
			out=new PrintWriter(s.getOutputStream(),true);
			out.println(msg);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		new ChatClient();
	}
}