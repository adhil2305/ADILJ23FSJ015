package edu.disease.asn2;

import static org.junit.Assert.*;

import java.util.UUID;

import org.junit.Test;

public class DiseaseControlManagerImplTest {

	@Test
	public void addDiseaseInArrayTest() {
		// if i dont give the below statmet i get diseases
		//cannnot 
		//be resolved to a type
		Disease[] diseases = new Disease[4];
		UUID hella = UUID.randomUUID();
		UUID thor = UUID.randomUUID();
		UUID loki = UUID.randomUUID();
		
		Disease d1 = new InfectiousDisease();
		d1.setDiseaseId(hella);
		d1.setName("Hella");
		Disease d2 = new NonInfectiousDisease();
		d2.setDiseaseId(thor);
		d2.setName("Thor");
		Disease d3 = new InfectiousDisease();
		d3.setDiseaseId(loki);
		d3.setName("loki");
		DiseaseControlManager impl1 = new DiseaseControlManagerImpl();
		
		impl1.addDiseaseInArray(d1);
		System.out.println(d1);
		impl1.addDiseaseInArray(d2);
		System.out.println(d2);
		impl1.addDiseaseInArray(d3);
		assertEquals(d1, diseases[0]);
		assertEquals(d2, diseases[1]);
		
	}

}
