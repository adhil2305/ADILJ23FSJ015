package MuttonChop;
import java.io.*;

public class Test{
	
	
	static {
		//All thr code inthe static block would be called regardless whether call  the static block or not 
		// However if it is a non static block it would not be called... that is the non staic block is a block closed by two curly braces 
		
	System.out.println(40%60);	 
		
		System.out.println("does it print ");
		int y = 0;
		++y;
	System.out.println(y);
	}
	
	
	public static void main(String[] args) {
		//This is a file IO as in file reader demo
		try (
		FileReader in = new FileReader ("myFile.txt");
		FileWriter out = new FileWriter("newfile2.txt")
		)
		{
			int n = 0;
			char c[] = new char[8];
			while((n = in.read(c))!= -1) {
				String s = new String(c,0,n);
				System.out.println("Check out the IO operation here...");
				System.out.println(s);
				out.write(c,0,n);
				
			}
			
		}catch(Exception ex) {
			
		}
			
		
				
				Muslim m = new Muslim();
		m.doGcd(40, 60);
		int n = 5;
		int i,j,k;
		for(i=1;i<n;i++) {
			for (j=n;j>i;j--) {
				System.out.print("  ");
			}
			for (k=1;k<=(2*i)-1;k++){
				System.out.print("* ");
			}
			System.out.println();
		}
		
		
	
		for(i=n;i>=1;i--) {
		for (j=n;j>i;j--) {
			System.out.print("  ");
		}
		for (k=1;k<=(2*i-1);k++){
			System.out.print("* ");
		}
		System.out.println();
		}
		
		//this is an io demo form here
		try {
			InputStreamReader r = new InputStreamReader(System.in);
			BufferedReader br =  new BufferedReader(r);
			String number = br.readLine();
			int x = Integer.parseInt(number);
			System.out.println(number);
			System.out.println(x*x);
		}catch(Exception e) {
			System.out.println("Please enter a valid number...");
		}
		
		}
	}

// An interface can implement multiple interfaces

// The above statement is proved in an clinical trial 
// Please be calm adhil it's  just another day 



class SlaveOfAllah{
	public void disp() {
		System.out.println("hello");
	}
}

class Human extends SlaveOfAllah{
	public void disp() {
		System.out.println("Really good ");
	}
}
class Muslim extends Human {
	public void disp() {
		//super.super.disp();
		// This kind of implementation is not possible 
  
		System.out.println("Muslim is called ");
	}
	public int doGcd(int n1, int n2) {
				if(n1==0&& n2==0) {
					return -1;
				}
				else if(n2 == 0){
					return n1;
				}
				
				else {
					return doGcd(n2, n1%n2);
				}
		        }
	}
