package mod1.day16;

public class JetAcademy implements Pilot{
@Override
public void doFly() {
	System.out.println("I am flying..............");
}
}
