package edu.disease.asn3;

public class NonInfectiousDisease extends Disease{

	@Override
	public String[] getExamples() {
		return new String[] { "Muscle Crampx", "Hypertension", "Alzheimer's Disease", "Osteoarthritis" };
	}



}
