package ONE_PINEAPPLE;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class Demo1 {
		public static void main(String[] args) throws Exception {
			Laddu laddu = new Laddu();
			laddu.size = 5;
			
			MarriageFood food1 = new MarriageFood();
			System.out.println("Original Marriage food");
			System.out.println(food1.jelabi +" "+ food1.samosa + " " + food1.jangri);
			// Some magic is done below seriablizable magic 
			// and all the objects pervious nature are saved in a place 
			// and then they could be brought back 
			
			FileOutputStream fos1 = new FileOutputStream("kali.dat");
			ObjectOutputStream oos1 = new ObjectOutputStream(fos1);
			
			//The above objects are frozen in time they could be brought back later whenever you want 
			oos1.writeObject(food1);
			
			food1.jangri = 1;
			food1.samosa = 0;
			food1.jelabi = 0;
			
			System.out.println("Original Marriage food After eating");
			System.out.println(food1.jelabi +" "+ food1.samosa + " " + food1.jangri);
			
			FileInputStream fis1 = new FileInputStream("kali.dat");
			ObjectInputStream ois1 = new ObjectInputStream(fis1);
			
			MarriageFood food2 = (MarriageFood)ois1.readObject();
			
			System.out.println("all the food that vanished are brought back by magic ");
			
			// Here  a deep copy of class has been created due to serialization 
			System.out.println(food2.jelabi +" "+ food2.samosa + " " + food2.jangri);
			
			
			/*
			 * This type of pattern is also called as the momento pattern 
			 * 
			 */
			
			// This creates a serializable obect which can be passed thrught the https protocol
			//The IO throws a IOException so it is mandatory to handle the exception
			
			
			FileOutputStream fos = new FileOutputStream("laddu.dat");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
		
			oos.writeObject(laddu);
			
			FileInputStream fis = new FileInputStream("laddu.dat");
			ObjectInputStream ois = new ObjectInputStream(fis);
			Laddu laddu2 = (Laddu)ois.readObject();
			
			System.out.println("Old Laddu..."+laddu.size);
			System.out.println("New Laddu2..."+laddu2.size);

			
			
		}
}
class Laddu implements Serializable {
	int size = 200;
}

class MarriageFood implements Serializable{
	int jangri = 10;
	int samosa =  10;
	int jelabi =10;
	
}