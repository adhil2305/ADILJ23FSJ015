package skirmish;

import static org.junit.Assert.*;


import org.junit.Test;
import org.junit.experimental.theories.suppliers.TestedOn;

public class CalculatorTest {

	@Test
	public void testAdd() {
		Calculator calc = new Calculator();
		int result = calc.add(10, 20);
		assertEquals(30,result);
	}
	@Test
	public void testAdd2() {
		Calculator calc =  new Calculator();
		int result = calc.add(-10, 20);
		assertEquals(20,result);
	}
	@Test
	public void testAdd3() {
		Calculator calc = new Calculator();
		int result = calc.add(10, -20);
		assertEquals(20,result);
	}
	@Test
	public void testAdd4() {
		Calculator calc = new Calculator();
		int result = calc.add(-10, -20);
		assertEquals(10,result);
	}
	@Test
	public void addTest5() {
		Calculator calc = new Calculator();
		int result = calc.add(-10, 0);
		assertEquals(1, result);
	}
	
	}

@Test
public void testDivide() {
	Calculator calc = new Calculator();
	assertThrows(ArithmeticException.class, () -> calc.divide(1,0),"Divide by Zero should throw");
	
}
