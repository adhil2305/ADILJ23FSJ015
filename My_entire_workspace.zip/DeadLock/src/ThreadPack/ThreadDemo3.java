package ThreadPack;
	
	import java.util.concurrent.ExecutorService;
	import java.util.concurrent.Executors;
	public class ThreadDemo3 {
		public static void main(String[] args) {
			Frog gaza=new Frog();
			Crane israel=new Crane();
			
			ExecutorService es=Executors.newFixedThreadPool(2);
			es.execute(()->{
				israel.eat(gaza);
			});
			es.execute(()->{
				gaza.escape(israel);
			});
			es.shutdown();
		}
	}
	class Crane{
		synchronized public void eat(Frog f) {
			System.out.println();
			f.leaveNeck();
			System.out.println("swaha....");
		}
		synchronized public void spitMeOut() {
			System.out.println("frog is out");
		}
	}
	class Frog{
		synchronized public void escape(Crane c) {
			System.out.println("freedom struggle started ");
			c.spitMeOut();
		}
		synchronized public void leaveNeck() {
			System.out.println("crane is free");
		}
	}
	