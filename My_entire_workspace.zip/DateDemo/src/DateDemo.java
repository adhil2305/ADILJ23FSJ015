import java.time.LocalDate;
import java.time.Clock;
import java.time.MonthDay;
import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;


public class DateDemo {
public static void main(String[] args) {
	LocalDate lDate = LocalDate.now();
System.out.println(lDate);
System.out.println(lDate.getDayOfMonth());

System.out.println(lDate.getDayOfWeek);
System.out.println(lDate.getDayOfYear);

}
}
