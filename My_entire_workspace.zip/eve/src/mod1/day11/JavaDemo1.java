package mod1.day11;
/*
 * Package - A way to give a unique identity or a identifier for your class names
 * internally it generates directories
 * The qualified name of a class is always associated with package name
 */
public class JavaDemo1 {
	public static void main(String[] args) {
		System.out.println("Hello World to Java....");
	}
}
