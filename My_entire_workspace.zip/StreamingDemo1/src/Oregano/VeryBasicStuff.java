package Oregano;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Collectors;
public class VeryBasicStuff {
		public static void main(String[] args) {
			List<Item> myList1 = new ArrayList<Item>();
			myList1.add(new Item("Liquorice",90));
			myList1.add(new Item("Maize",10));
			myList1.add(new Item("Corn",40));
			myList1.add(new Item("Saffron",1000));
			myList1.add(new Item("Pista",500));
			myList1.add(new Item("Cashew", 100));
			myList1.add(new Item("Caramel",100));
			
			myList1.stream().forEach((t)-> System.out.println("#### ... "+t) );
			myList1.stream().forEach(System.out::println);
			Long count = myList1.stream().filter(t->t.price<100).count();
			
			System.out.println(count);
			
			List myList2 = myList1.stream().filter(t->t.price>100).collect(Collectors.toList());
			
			System.out.println(myList2);
			
			List myList3 = myList1.stream().filter(t->t.price>100).map(i-> i.name).collect(Collectors.toList());
			System.out.println(myList3);
			
		}
}

class Item{
	String name;
	int price;
	public Item(String name,int price) {
		this.name = name;
		this.price = price;
		
	}
	@Override
	public String toString() {
		return this.name + ":" + price;
	}
}