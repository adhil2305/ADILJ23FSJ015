package eve;

public class TypeCastingDemo {
	public static void main(String[] args) {
		int i=127;//32 bit
		byte b=(byte)i;//8 bit - type casting
		System.out.println(b);
		
	}
	
}
