package Popcorn;

import java.util.StringTokenizer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Demo1 {
		public static void main(String[] args) {
			// Method Referencing way 
			// This works with both staic and non staic mehtods of doCure()new Doctor() {
		
			Ninja naruto =  Demo1::myCure;
			naruto.shadowClone(100);			
			Doctor d1 = () -> { System.out.println("do cure in the lambda way");};
			d1.doCure();
			 Doctor doctor1 = ()-> {System.out.println("Another way of lambda");};
			 doctor1.doCure();
			Mgr n1 = new Mgr();
			n1.service();
			new Mgr().service();
			
			//String is non MUTABLE
			/* Side Notes
			 * Buffer is  not faster and but synchronous has good performance but no data onsistency 
			 * where as the StringBUilder has data consistency but no perfromance 
			 *  
			 */
			 String s = "HEllo";
			 String temp = s;
			
			s = s+ " world";
			
			System.out.println(s);
			System.out.println(temp);
			
			StringBuilder sb = new StringBuilder("Hello");
			StringBuilder sbtemp = sb;
			
			sb.append(" World");
			System.out.println(sb);
			System.out.println(sbtemp);
			
			timeTest();
			concurrencyTest();
			
			
			
		}
		public static void timeTest() {
			StringBuffer sb1 = new StringBuffer("Buffer1..");
			StringBuilder sbff1 = new StringBuilder("Buffer1..");
			StringTokenizer st1 = new StringTokenizer("Hello");
			
			long l1 = System.currentTimeMillis();
			for(int i=0;i<2000;i++) {
				//sb1.append("java:.." +i);
				sbff1.append("java:.." +i);
				
				
			}
			long l2 = System.currentTimeMillis();
			System.out.println("builder time non Synchronised ..."+(l2-l1)+" MS Builder fast ");
			
		}
		public static void concurrencyTest() {
			StringBuilder sbd1 = new StringBuilder("Builder...");
			//buffer  is synchronised
			
			StringBuffer sb2 = new StringBuffer ("Buffer..2");
			ExecutorService es = Executors.newFixedThreadPool(2);
			
			es.execute(()-> {
				try {Thread.sleep(1000);}catch(Exception e) {}
				for(int i =0;i<8;i++) {
					//sbd1.append("sbd1 Builder is appended"+i);
					sb2.append("sbd1 Builder is appended"+i);

				}
				System.out.print(sb2);
				//System.out.println(sbd1);
			});
			es.shutdown();
			System.gc();
		}
		public static int myCure(int j) {
			j = 200;
			System.out.println("Method Referencing .... " +j);
			return j;
		}
}

interface Doctor{
	public void doCure();
}
class Mgr{
public void service() {
	
	System.out.println("can outer method be called seperate ...");
	class LocalMedical implements Doctor{
		@Override
		public void doCure() {
			System.out.println("Overriden method ");
		}
	}

new LocalMedical().doCure();

new Doctor() {
	@Override
	public void doCure() {
		System.out.println("The Anonymous inner class way");
	}
}.doCure();


}
}

interface Ninja{
	
	public int shadowClone(int j);
}