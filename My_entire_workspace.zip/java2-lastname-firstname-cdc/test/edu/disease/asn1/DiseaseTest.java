package edu.disease.asn1;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.UUID;

import org.junit.Test;

public class DiseaseTest {
		@Test
		public void test1() {
			Disease d = new Disease();
			java.util.UUID id = java.util.UUID.randomUUID();
			d.setDiseaseId(id);
			java.util.UUID dna = d.getDiseaseId();
			assertEquals(dna,id);
		}
		
		    @Test
		    public void seDiseaseIdTest() {
		    	Disease d = new Disease();
		    	java.util.UUID sentId = java.util.UUID.randomUUID();
		   		        // Asserts
		    	d.setDiseaseId(sentId);
		    	java.util.UUID retrieved = d.getDiseaseId();
		        assertEquals(sentId, retrieved);
		    }
		    
		    @Test
		    public void setNameTest() {
		    	Disease d = new Disease();
		    	String sentId = "Nouman";
		    			d.setName(sentId);
		    			String retrieved = d.getName();
		   		        // Assert
		        assertEquals(sentId, retrieved);
		    }
		    
			@Test
			public void getNameTest() {
				Disease d = new Disease();
				String id = "Alejandro";
				d.setName(id);
				String dna = d.getName();
				assertEquals(dna,id);
			}
			
			@Test
			public void testSameName() {
				Disease p1=new Disease();
				Disease p2=new Disease();
				
			//	System.out.println(p1.hashCode());
			//	System.out.println(p2.hashCode());
				boolean result=p1.equals(p2);
				assertTrue(result);		
			}
			@Test
			public void testingStringMet() {

				UUID diseaseId=UUID.randomUUID();

				String name = "charlie";
				String toStringMsg= "DiseaseId is "+diseaseId+"Name is "+name;
				
				Disease d=new Disease();
				d.setDiseaseId(diseaseId);
				d.setName(name);
				
				
				assertEquals(toStringMsg,d.toString());
			
			}
						
			
		    
}
