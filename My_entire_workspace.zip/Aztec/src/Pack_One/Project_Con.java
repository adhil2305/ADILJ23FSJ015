package Pack_One;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Project_Con {

    public static void main(String[] args) throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307/javabatch", "root", "root");
        con.setAutoCommit(false);

        try {
            String username = "Somu";
            String drname = "Mohan";
            int amount = 500;
            int amt = 610;
            
            PreparedStatement stmt = con.prepareStatement("select amt from users where drname = ?");
            stmt.setString(1, drname);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                amt = rs.getInt("amt");
                System.out.println("hello");
                if (amt > amount) {
                    amt = amt - amount;
                    System.out.println(amt);
                    stmt = con.prepareStatement("UPDATE users SET amt = ? where drname = ?");
                    stmt.setInt(1, amt);
                    stmt.setString(2, drname);
                    stmt.executeUpdate();
                } else {
                    throw new LowBalanceException("Insufficient balance");
                }
            } else {
                throw new InvalidUserException("Invalid user");
            }
            
            stmt = con.prepareStatement("update users set amt = ? where drname = ?");
            stmt.setInt(1, amt + amount);
            stmt.setString(2, drname);
            stmt.executeUpdate();

            con.commit();
        } catch (Exception e) {
            e.printStackTrace();
           con.rollback();
        } finally {
            if (con != null) {
                con.close();
            }
        }
    }
}

class LowBalanceException extends Exception {
	String message;
    public LowBalanceException(String message) {
        super(message);
        this.message  =  message;
    }
}

class InvalidUserException extends Exception {
    public InvalidUserException(String message) {
        super(message);
    }
}

