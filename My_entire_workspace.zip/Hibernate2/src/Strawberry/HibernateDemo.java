package Strawberry;
import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Entity;
import javax.persistence.GenerationType;
@Entity(name="EVES")
@Table(name="users")
		public class User{
	@Id@GeneratedValue(strategy=GenerationType.AUTO	)
private int uid;
	@Column(name="username", length=40, nullable=false)
	private String uname;
	@Column(name="password" length=10, nullable=false)
private String upass;
	
}

public class HibernateDemo {
public static void main(String[] args) {
	
}
}
