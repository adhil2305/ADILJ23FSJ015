package Oregano;

import java.util.List;
import java.util.ArrayList;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Collectors;


public class PredicateDefined {
		public static void main(String[] args) {
			List<String> myListP = new ArrayList<String>();
			myListP.add("Baba");
			myListP.add("c");
			myListP.add("d");
			myListP.add("Born");
			myListP.add("Brave"); myListP.add("Baji");
		
			
			myListP.stream().forEach(new  MyConsumer());
			
			myListP.stream().forEach(PredicateDefined::myPrint);
			
			 myListP.stream().forEach ((t)-> System.out.print("### ..."+t));
			
			 myListP.stream().forEach(System.out::println);
			
			 // myList.stream().filter(new MyPredicate()).limit(3).forEach(System.out::println);
			 
			 List templist = myListP.stream().filter(new MyPredicate()).limit(3).collect(Collectors.toList());
			 System.out.println(templist);
			 
		}
		static void myPrint(String s) {
			System.out.println("$$$$$  ... :" +s);
		}
}

class MyPredicate implements Predicate<String >{
	@Override 
	public boolean test(String t) {
		//To Do auto generated
		return t.contains("a");
	}
}

class MyConsumer implements Consumer<String>{
	
	@Override
	public void accept (String t) {
		System.out.println("^^^^^" +t);
	}
}