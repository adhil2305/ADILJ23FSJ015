package UiawtPackage;

public class Demo1 {

}


import java.awt.*;
import java.awt.event.*;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
public class HtmlBrowser extends JFrame implements ActionListener
{
	JEditorPane ep;
	JTextArea ta;
	JButton btn;
	JScrollPane pane1,pane2;
public HtmlBrowser()
{
	Container c=getContentPane();
	c.setLayout(new FlowLayout());
	ep=new JEditorPane("text/html","<h1>HTMl Here</h1>");
	ta=new JTextArea("Enter HTML here",10,50);
	pane1=new JScrollPane(ta);
	pane2=new JScrollPane(ep);
	pane2.setPreferredSize(new Dimension(550,180));
	btn=new JButton("Click");
	c.add(pane1);
	c.add(btn);
	c.add(pane2);
	btn.addActionListener(this);
}
public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==btn)
		{
			ep.setText(ta.getText());
		}
	}
public static void main(String[] args) {
	HtmlBrowser browser=new HtmlBrowser();
	browser.setTitle("browser Example");
	browser.pack();
	browser.setVisible(true);
}
}


haarisinfotech
  7:41 PM
package junitproj;
public class Calculator {
	public int add(int i,int j) {
		return i+j;
	}
	public int mul(int i,int j) {
		return i*j;
	}
}
package junitproj;
import static org.junit.Assert.assertEquals;
import org.junit.Test;
public class CalculatorTest {
	
	@Test
	public void testAdd() {
		Calculator calc=new Calculator();
		int result=calc.add(10,10);
		
		assertEquals(20, result);//the first param is expected and second is actual
	}
	@Test
	public void testMul() {
		Calculator calc=new Calculator();
		int result=calc.mul(4, 10);
		assertEquals(40, result);
	}
}







haarisinfotech
  8:22 PM
package junitproj;
import java.time.LocalDate;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
public class Calculator {
	public int add(int i,int j) {
		return i+j;
	}
	public int mul(int i,int j) {
		return i*j;
	}
	
	public int calculateDateDif(LocalDate sd, LocalDate ed) {
		return (int)sd.until(ed).getDays();
	}
	
	public int[] reverseArray(int a[]) {
		int length=a.length;
		int revarray[]=new int[length];
		for(int i=0;i<length;i++) {
			revarray[i]=a[length-1 -i];
		}
		return revarray;
	}
	
	public List<Employee> sortColBySal(List<Employee> emplist){
		Collections.sort(emplist,(e1,e2)->{return e1.compareTo(e2);});
		return emplist;
	}
}
class Employee implements Comparable<Employee>{
	String name;
	Integer salary;
	public Employee(String name,Integer salary) {
		this.name=name;
		this.salary=salary;
	}
	
	@Override
	public int compareTo(Employee o) {
		// TODO Auto-generated method stub
		return this.salary.compareTo(o.salary);
	}
}
package junitproj;