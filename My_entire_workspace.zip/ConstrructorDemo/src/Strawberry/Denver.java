package Strawberry;

public class Denver {
public static void main(String[] args) {
	Shoe shoe = new LeatherShoe(100);
	
}
}
class Shoe{
	int i ;
	public Shoe() {
		System.out.println("Constructor of shoe called"
				+ "ha ha");
		}
		public Shoe(int i) {
			System.out.println("Parametric  constructor of shoe is called ..");
		
		}
		public void met() {
			System.out.println("Parent class method is called..");
		}
}
class LeatherShoe extends Shoe{
	//THere is no  concept of overriding in constructor
public LeatherShoe(int i) {
	
	super(343);//super class constructor should be the first line of the constructor..
	Shoe shoe;
	System.out.println(i);
	super.i = 100;
	super.met();
	System.out.println("Super class of the met is called..");
	
}
}