package CARROT;

public class GarDemo1 {
	/*
	 * system.gc() is a static method 
	 * runtime.gc is a non static method
	 */

}

