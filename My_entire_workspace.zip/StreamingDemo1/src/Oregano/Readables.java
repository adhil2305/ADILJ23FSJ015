package Oregano;

import java.util.Optional;
import java.util.ArrayList;
import java.util.OptionalDouble;
import java.util.function.Predicate;
import java.util.function.Consumer;	
import java.util.Arrays;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import java.util.List;


public class Readables {
		public static void main(String[] args) {
			List<Integer> numbers = Arrays.asList(1,2,3,4,5);
				System.out.println(Integer.parseInt("100"));	
			Stream<Integer > stream3 = numbers.stream();
			
			// Streams can read from an array also
			int[] intArray =  {1,5,10,15};
			IntStream intStream = Arrays.stream(intArray);
			
			
			//You could also Stream from a range of values
			IntStream range1 = IntStream.range(1,6);// Generate a series from one to six 
			
			//Intermediate and terminal Operations 
			/*
			 * Intermediate opeeration can chcange a Stream into  another stream
			 * Common operations include map() filter() distinct() and sorted() .
			 * 
			 * Terminal operations ::
			 * On the other hand these operations cause a side effect or a result 
			 * like the methods of the stream like for each collet reduce() or even count() terminal operation trigger the processing of a stream 
			 * 
			 */
			
			//Example 
			//zList <Integer>  = numbers.stream().filter(n->n$2==0).mapToList(Integer::intValue).sum();
			
			// The processes in the above line of code are
			//filter()  filters  the even numbers
			// map to INt method maps to the primitive values 
			// sum obviously does the sum
			
	//		System.out.println("Sum of even numbers "+sum);
			
			//Stream Operation overview 
			
			//filter(Predicate<T> predicate )filters elements based on the provided predicate
			
			//map(Function<T> , R> mapper) Transforms elements with the give logic
			// distinct() removes the duplicate elements 
			
			//sorted() sorts the elements 
			//forEach(Consumer<T> action) performs an action for each elements based o on the given logic
			
			//collect (Collector<T,A,R> collector) Gathers elemts from a collecion 
			
			//reduce(T identity , BinaryOperator<T>, accumulator) // Aggregates elements 
			
			//ount() counts the numebr of elemets in a stream 
			
			//Parallel Streams 
			
			// you can easily use the benefits fo the paralle streams the 
			//Usage of multi core processors using the iparallel method 
			
			//This code will use parallel processing when appropriate
			List<Integer> numbers2 = Arrays.asList(1,2,3,4,5,6,3);
			int sum = numbers2.parallelStream ().filter(n -> n%2==0).mapToInt(Integer::intValue).sum();
			System.out.println("Some Integer Values based on the mapping examples ..."+ sum);
			
			
			//
			List<LiuKang> sword1 = new ArrayList<LiuKang>();
			sword1.add(new LiuKang("daal",30));
			sword1.add(new LiuKang("Groundnut",120));
			sword1.add(new LiuKang("Oil", 160));
			
			// Display all the items using lambda
			
			sword1.stream().forEach((t)-> System.out.println("### .... :"+t));
			
			// Display all the items using foreach and method referencing 
			
			sword1.stream().forEach(System.out::println);
			
			//Displaying a count price having less than hundred
			
			Long count =  sword1.stream().filter(t -> t.price<100).count();
			
			System.out.println(count);
			
			List<LiuKang> sortedNames2 = sword1.stream().sorted().collect(Collectors.toList());
			System.out.println(sortedNames2);
			
			List<LiuKang> revSortedNames = sword1.stream().sorted((o1,o2) -> o2.compareTo(o1)).collect(Collectors.toList());
			System.out.println(revSortedNames);
			
			// Pick up the pickup objects whose price is grater than hundred and create another list
			List myList5 = sword1.stream().filter(t->t.price>100).collect(Collectors.toList());
			
			System.out.println(myList5);
			
			// Pick up the new kid of 
			
			List<String> myList6 = sword1.stream().filter(t -> t.price > 100).map(i -> i.name).collect(Collectors.toList());
			System.out.println(myList6);
			
			// Class myList7
			
			// Get the objects and the double objects are here 
			double d2 = sword1.stream().mapToDouble((t)->t.price).average().orElse(.0);
			System.out.println(d2);
			
			// Read a collection and and return a collection with the square of each number with t
			
			List<Integer> squareNumbers = numbers.stream().map(n -> n*n).collect(Collectors.toList());
			System.out.println(squareNumbers);
			
			// List the items using parallel stream without ordering
			new Thread(() ->sword1.parallelStream().forEach(System.out::println));
			// list the items using parallel stream with ordering 
			new Thread (() -> sword1.parallelStream().forEachOrdered(System.out::println)).start();
			
			String[] s1 = new String[5];
			
			if(s1[1] == null) {
				System.out.println("Empty Array");
			}
			else {
				System.out.println(s1[1].toLowerCase());
			}
			
			
			String result = Optional.ofNullable(s1[1]).orElse("DEFAULT");
			System.out.println(result.toLowerCase());
			//This would work only if the value is null
			
			String nor = Optional.of(s[1]).ifPresent(i -> System.out.println(i));
			
			// Optional.of(s[1]).ifPresentOrElse(System.out::println, () -> {System.out.println("rum run run");});
			
			// OptionalNullable(s[1]).ifPresentOrElse(System.out::println, () -> {System.out.println("run run run");});
			
			s[1] = "Hellooo";
			
			Optional.ofNullable(s1[1]).ifPresentorElse(Readables::print, () -> System.out.println("run over here");});
			
			
			static void print(String s1) {
				System.out.println(s1);
			
			
			
			
		}
}

class LiuKang implements Comparable<LiuKang>{
	String name;
	int price;
	
	public LiuKang (String name , int price ) {
		this.name =  name;
		this.price = price;
		}
		@Override
		public String toString() {
			return this.name + ":" + price;
		}
		@Override 
		public int compareTo(LiuKang o) {
			return this.name.compareTo(o.name);
		}
}