package Doritos;

public class InnerClassDemo {
	public static void main(String[] args) {
		//How to create an object of inner classes
		
				//non static inner class object creation uses the new keyword to instantiate the object
				Outer.Inner inn=new Outer().new Inner();
				inn.innerMet();
				inn.getClass();
				//static inner class object creation
				Outer.StaticInner innstatic=new Outer.StaticInner();
				innstatic.innerMet();
				/*
				 * Rules of inner class
				 * 1.  Inner classes has access to all the properties and methods of outer class
				 * 2.  The reverse is not possible
				 * 3.  Static inner class cannot have access to non static properties and methods of outer class
				 * 4.  But it can access static properties and methods of the outer classes
				 */
				
			}
		}
		/*
		 * Inner classes are of two types 1. Non Static Inner Class 2. Static Inner class
		 */
		class Outer{
			static private int x=1000;
			static public void met() {
				System.out.println("static method of outer called...");
				//innerMet();
			}
			class Inner{
				public void innerMet() {
					met();
					
					System.out.println("x value...:"+x);
				}
			}
			static class StaticInner{
				public void innerMet() {
					met();
					System.out.println("x value...:"+x);
				}
			}
		}