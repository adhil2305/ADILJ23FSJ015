package edu.disease.asn2;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class NonInfectiousDiseaseTest {

	@Test
	void test() {
		String[] nonInfectiousDisease = { "Diabetes", "Hypertension", "Alzheimer's Disease", "Osteoarthritis" };
		assertArrayEquals(nonInfectiousDisease,new NonInfectiousDisease().getExamples());
	}

}
