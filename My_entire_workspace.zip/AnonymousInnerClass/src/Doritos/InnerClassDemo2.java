package Doritos;

public class InnerClassDemo2 {
	public static void main(String[] args) {
		
	
	Pepsi pepsico = new Pepsi();
	//pepsico.makeCola();
	
	KaliMark kali = new KaliMark();
	kali.makeCola();
}
}

abstract class Cola{
		public abstract void makeCola();
	
}

class Pepsi{
	public void makeCola(){
	Cola cola = new KaliMark().new CampaCola();
	cola.makeCola();
	System.out.println("fills campa cola in the bottle and sells Pepsi...");
	class CampaCola extends Cola{
	
		@Override
		public void makeCola() {
			// TODO Auto-generated method stub
		System.out.println("hey i can also make cola");	
		}
	}
	
	}
}
class KaliMark{
	public void makeCola(){
		//Merging Mahatma Gandhi way - the old way
		//ANONYMOUS INNER CLASS
		new Cola(){
			@Override
			public void makeCola() {
				System.out.println("Cola created as per CampaCola formula the cola not done by the gandhi way old way");
			}
		}.makeCola();
		System.out.println("fills campa cola in kalimark bottle and sells as bovoonto..");
		}
		/*
		 * class CampaCola extends Cola{
		 * 
		 * @Override public void makeCola() {
		 * System.out.println("Campacola make cola..."); }
		 */
	}