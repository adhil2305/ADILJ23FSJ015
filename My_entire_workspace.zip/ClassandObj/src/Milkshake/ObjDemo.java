package Milkshake;

public class ObjDemo {
public static void main(String[] args) {
Business obj = new Business();
obj.met();
int n = obj.met1();
System.out.println(n);
obj.met2("Golden Batch",10);
         n = obj.met3(2020);
         System.out.println(n);
         
         obj.met4(new String[]{"hello",  "hai","bai"});
      
	Emp emp = new Emp("rahim");
	System.out.println(emp.name);
	
	
}
}
class Emp{
	String name;

	public Emp(String name) {
		this.name=name;
	}
}
class Business {
	void met(){
		System.out.println("method one called");
	}
	int met1() {
		System.out.println("Method 1 called...");
		return 100;
	}
	void met2(String s, int i) {
		System.out.println("method 2 is called...");
		
	}
	int met3(int i) {
		return i+10;
	}
	void met4(String s[]) {
		for(String str:s) {
			System.out.println(str +"/t");
		}
	}
}
