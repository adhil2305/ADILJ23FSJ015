package mod1.day9;

public enum MyEnum {
	apple,bat,cat;
}
