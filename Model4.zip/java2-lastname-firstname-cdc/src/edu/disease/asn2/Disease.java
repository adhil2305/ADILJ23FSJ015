package edu.disease.asn2;

import java.util.UUID;
import java.util.Objects;
public abstract class Disease {
	private UUID diseaseId;
	private String name;
	public Disease(){
		
	}
	public Disease(UUID diseaseId, String name) {
		this.diseaseId = diseaseId;
		this.name = name;
	}
	public abstract String[] getExamples();
	
	public UUID getDiseaseId() {
		return diseaseId;
	}

	
	public void setDiseaseId(UUID diseaseId) {
		this.diseaseId = diseaseId;
	}

	
	public String getName() {
		return name;
	}

	
	public void setName(String name) {
		this.name = name;
	}

	
	@Override
	public int hashCode() {
		return Objects.hash(diseaseId);
	}

	
	@Override
	public boolean equals(Object obj) {
		Disease d = (Disease) obj;
		if (diseaseId != null && d.getDiseaseId() != null) {
			return this.hashCode() == d.hashCode();
		}
		return false;
	}

	@Override
	public String toString() {
		return "Disease [diseaseId=" + diseaseId + ", name=" + name + "]";
	}
	

}