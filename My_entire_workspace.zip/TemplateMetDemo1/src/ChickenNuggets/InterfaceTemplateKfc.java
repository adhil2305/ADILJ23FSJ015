package ChickenNuggets;

public class InterfaceTemplateKfc {
		public static void main(String[] args) {
			FriedChicken chicken = new KFC();
			chicken.doKFCBusiness();
		}
}

interface FriedChicken{
	private void secretKFCSpices() {
		//Keep in mind this is a template method can only be accessed inside the class the scope is inside the class
		
	}
	private void engineeredChicken() {
		System.out.println("secret KFC engineered machinery to cook chicken is deployed");
	}
	private void secretKFCcookingmet() {
		System.out.println("Secret way fo cooking temperature and time needed is done peoperly by my hibernate employee");
		
	}
	private void makingProcess() {// Put all these secret methodology in a secret place which can only be accessed by some top level people the employees can only access the coo
		secretKFCSpices();
		secretKFCcookingmet();
		engineeredChicken();
		
	}
	private void shopDesign() {
		System.out.println("The secret shop design of KFC...");
	}
	private void sellStrategy() {
		System.out.println("secret selling strategy...");
	}
	default void doKFCBusiness() {
		shopDesign();
		makingProcess();
		sellStrategy();
		deliverItems();
		collectMoney();
		
	}
	public void collectMoney();
	public void deliverItems();
}

class KFC implements FriedChicken {
	@Override
	public void collectMoney() {
		System.out.println("Money collected");
	}
	public void deliverItems() {
		System.out.println("Delivering Chicken ");
	}
}