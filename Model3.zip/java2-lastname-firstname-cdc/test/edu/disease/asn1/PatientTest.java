package edu.disease.asn1;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.UUID;

import org.junit.Test;

public class PatientTest {
	@Test
	public void test2() {
	Patient p1=new Patient("abdul","kalam");
	Patient p2=new Patient("Bruce","Wayne");
	
	//System.out.println(p1.hashCode());
	//System.out.println(p2.hashCode());
	boolean result=p1.equals(p2);
	assertFalse(result);
	}
	@Test
	public void test2met4() {
		Patient p1=new Patient("Bruce","Wayne");
		Patient p2=new Patient("Bruce","Wayne");
		
		//System.out.println(p1.hashCode());
		//System.out.println(p2.hashCode());
		boolean result=p1.equals(p2);
		assertTrue(result);
		
	}
	
	@Test
	public void test2met3() {
		Patient p1=new Patient();
		Patient p2=new Patient();
		
		//System.out.println(p1.hashCode());
		//System.out.println(p2.hashCode());
		boolean result=p1.equals(p2);
		assertTrue(result);
		
	}
	@Test
	public void test2met5() {
		Patient p1=new Patient("Tony",null);
		Patient p2=new Patient("Tony",null);
		
		//System.out.println(p1.hashCode());
		//System.out.println(p2.hashCode());
		boolean result=p1.equals(p2);
		assertTrue(result);
		
	}
	@Test
	public void test2met6() {
		Patient p1=new Patient(null,"jelly");
		Patient p2=new Patient(null,"jelly");
		
		//System.out.println(p1.hashCode());
		//System.out.println(p2.hashCode());
		boolean result=p1.equals(p2);
		assertTrue(result);
		
	}
	@Test
	public void setPatientExposure1() {
		assertThrows(IllegalArgumentException.class, ()-> new Patient(2,5));
		
	
	}
	
	
	
	@Test
	public void testingSetPatientId() {
		Patient p = new Patient();
		java.util.UUID actual = java.util.UUID.randomUUID();
		p.setPatientId(actual);
		java.util.UUID retrieved = p.getPatientId();
		assertEquals(actual,retrieved);
	}
	@Test
	public void testToString() {
		UUID patientId=UUID.randomUUID(),diseaseIds[] = new UUID[1];
		String firstName="Christiano",lastName="Ronaldo";
		Exposure[] exposures = new Exposure[1];
	
		String toStringMsg="Patient ID" + patientId + "First Name" + firstName + "Last Name"+ lastName +"Exposure"+ Arrays.toString(exposures) + "Disease Id " + Arrays.toString(diseaseIds);
		
		Patient patient=new Patient(1,1);
		patient.setFirstName(firstName);
		patient.setLastName(lastName);
		patient.setPatientId(patientId);
		
		
		assertEquals(toStringMsg,patient.toString());
	}
	
	
	
	
}

