package Mozeralla;

import java.util.List;
import java.util.ListIterator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;


public class ComparingTheNumberOfInteger {
		public static void main(String[] args) {
			List <Employee> nums = new ArrayList<>();
			nums.add(new Employee("Sarah"));
			nums.add(new Employee("Hardy"));
			nums.add(new Employee("Carl"));
			nums.add(new Employee("Kate"));
			nums.add(new Employee("Si"));
			nums.add(new Employee("Tom"));
			nums.add(new Employee("Jimmy"));
			 	
			List<String> myList2 = new ArrayList<String>();
			myList2.add("x");
			myList2.add("d");
			myList2.add("a");
			myList2.add("b");
			
			Iterator<String> iter= myList2.iterator();
			while(iter.hasNext()) {
				System.out.println(iter.next());
			}
			
			ListIterator<String> liter = myList2.listIterator();
			while(liter.hasNext()) {
				System.out.println(liter.next());
			}
			
			myList2.stream().forEach(System.out::println);
			
			Collections.sort(nums, (o1,o2)->{return o2.compareTo(o1);});
		System.out.println(nums);
		
		}
}
/*
 * class MyComparator implements Comparator <Employee>{ public int
 * compare(Employee o1, Employee o2) { return o2.compareTo(o1); } }
 */



class Employee implements Comparable<Employee>{
	String name;
	public Employee(String name) {
		this.name  = name;
		
	}
	public String toString() {
		return this.name;
	}
	public int compareTo(Employee o) {
		return this.name.compareTo(o.name);
	}
}