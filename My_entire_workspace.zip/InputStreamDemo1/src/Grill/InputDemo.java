package Grill;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileOutputStream;

public class InputDemo {
public static void main(String[] args) {
try(	
	
	FileInputStream fis = new FileInputStream("temp.txt");
	FileOutputStream fos = new FileOutputStream("copy.txt",true);
	){
	int i =0;
	
	while((i = fis.read())!= -1) {
		System.out.println(i);
		//fos.write(i);
	
	}
	
		}catch(Exception e) {
	e.printStackTrace();
}

}
}
