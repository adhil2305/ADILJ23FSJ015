package Daily;


public class StaticDemo1 {
	public static void main(String[] args) {
		CinemaScreen s1=new CinemaScreen();
		CinemaScreen s2=new CinemaScreen();
		
		System.out.println(CinemaScreen.toilet);
		System.out.println(s1.chair);
		
		System.out.println(CinemaScreen.toilet);
		System.out.println(s2.chair);
	}
}
class CinemaScreen{
	static Toilet toilet=new Toilet();
	Chair chair=new Chair();
}
class Toilet{
	
}
class Chair{
	
}
