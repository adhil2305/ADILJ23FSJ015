package edu.disease.asn6;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class DiseaseControlManagerImpl implements DiseaseControlManager {
	//private Disease[] diseases = new Disease[10];
	//private Patient[] patients = new Patient[10];
	
	List<Patient> patients = new ArrayList<Patient>();
	List<Disease> diseases = new ArrayList<Disease>();
	
	
//	public static void main(String[] args) { UUID pOne = UUID.randomUUID(); UUID
//	 pTwo = UUID.randomUUID(); DiseaseControlManagerImpl i1 = new
//	 DiseaseControlManagerImpl(); Patient p1= new Patient();
//	 p1.setPatientId(pOne); i1.addPatientInArray(p1); i1.getPatient(pOne); }
	 
	
	/*
	 * public static void main(String[] args) { UUID id = UUID.randomUUID(); Disease
	 * d1 = new Disease(); }
	 */

	public void addDiseaseInArray(Disease d) {
		for (int i = 0; i < diseases.size() ; i++) {
			if (diseases.get(i) == null) {
				diseases.add(d) ;
				break;
			}
		}
	}
	@Override
	public void addPatientInArray(Patient p) {
		for (int i = 0; i < patients.size(); i++) {
			if (patients.get(i) == null) {
				patients.add(p);
				break;
			}
		}
	}

	@Override
	public Disease addDisease(String name, boolean infectious) {
		Disease obj;
		if (infectious) {
			obj = new InfectiousDisease();
		} else {
			obj = new NonInfectiousDisease();
		}
		obj.setName(name);
		return obj;
	}

	@Override
	public void addDiseaseToPatient(UUID patientId, UUID diseaseId) {
		Patient patient = getPatient(patientId);
		if (patient == null) {
			throw new IllegalArgumentException();
		}
		Disease disease = getDisease(diseaseId);
		if (disease == null) {
			throw new IllegalArgumentException();
		}
		patient.addDiseaseId(diseaseId);
	}

	@Override
	public void addExposureToPatient(UUID patientId, Exposure exposure) {
		Patient patient =  getPatient(patientId);
		if (patient == null) {
			throw new IllegalArgumentException();
		}
		patient.addExposure(exposure);
	}

	@Override
	public Patient addPatient(String firstName, String lastName, int maxDiseases, int maxExposures) {
		Patient patient = new Patient(maxDiseases, maxExposures);
		patient.setFirstName(firstName);
		patient.setLastName(lastName);
		return patient;
	}

	@Override
	public Disease getDisease(UUID diseaseId) {
		Disease disease = null;
		for (Disease d : diseases) {
			if (d == null || d.getDiseaseId().equals(diseaseId)) {
				disease = d;
				break;
			}
		}
		return disease;
	}

	@Override
	public Patient getPatient(UUID patientId) {
		Patient patient = null;
		for (Patient p : patients) {
			if (p == null || p.getPatientId().equals(patientId)) {
				patient = p;
				break;
			}
		}
		return patient;
	}
	@Override
	public List<Patient> getPatients() {
		return this.patients;
	}


	@Override
	public List<Disease> getDiseases(UUID diseaseId) {
		// TODO Auto-generated method stub
		return this.diseases;
	}
}
