
public class Prototype {
	public static void main(String[] args) {
	GoodPaintBrush1<Water> waterPaintBrush = new GoodPaintBrush1<>();
	waterPaintBrush.setObj(new Water());
	waterPaintBrush.getObj();
	}

}
class Paint1{

}

class BluePaint1 extends Paint {
	
}

class GreenPaint1 extends Paint1{
	
}
class RedPaint1 extends Paint1{
	
}
class GoodPaintBrush1<T>{
	T obj;
public void setObj(T obj) {
	this.obj = obj;
}
public T getObj() {
	return this.obj;
}
}