package edu.disease.asn3;

public class InfectiousDisease extends Disease{

	public InfectiousDisease() {
		
	}
	public int InfectiousDisease() {
		return 1;
	}
	@Override
	public String[] getExamples() {
		return new String[]{ "Flu", "TB", "Malaria", "COVID-19 " };
	}
}
