package DAO;
public class User{
	private String uid,flag;
	private String uname, upass;
	
	public User(String uid, String flag, String uname, String upass) {
		this.uid = uid;
		this.flag = flag;
		this.uname = uname;
		this.upass = upass;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getUpass() {
		return upass;
	}
	public void setUpass(String upass) {
		this.upass = upass;
	}
	
	
}