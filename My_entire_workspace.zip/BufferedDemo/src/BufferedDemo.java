
public class BufferedDemo {
public static void main(String[] args) {
	String str = "jack and &copy; jill went up the &copy hill  to fetch ";
	System.out.println(str);
	System.out.println("jack and jill"+(char)169+"went up the &copy hill to fetch ...");
	
}
}
