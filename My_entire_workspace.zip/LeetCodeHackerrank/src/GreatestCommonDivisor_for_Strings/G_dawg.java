package GreatestCommonDivisor_for_Strings;

public class G_dawg {
	public static void main(String[] args) {
		Divide d = new Divide();
		d.doThis("ABCABCABC","ABC");
	}
}

class Divide{
	public String doThis(String str1, String str2) {
		
		System.out.println(3%9);
		
		if(str1+str2 == str1+ str2) {
			return "";
		}
		
		int gcd = gcd(str1.length(), str2.length());
		
		System.out.println( str1.substring(0, gcd));
		return str1.substring(0, gcd);
		
	}
	private int gcd(int a, int b) {
		return b==0 ? a : gcd(b, a%b);
	}
	
}