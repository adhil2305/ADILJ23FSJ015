import java.sql.Connection;
import java.sql.Driver;

public class Jdbc {
public static void main(String[] args) {
	public void doOperation1Insert(int eid,String ename,String epass, int esalary, String ecity, int flag) {
	Connection con = nul ;Statement stmt = null;
	try {
		con = DriverManager.getConnection("jdbc.mysql://localhost : 3306/ aspire","root","root");
		con.setAutoCommit(false);
		stmt=con.createStatement();
		//Connection String sql = "insert into employee values (200,"ram",site,10000,delhi,0)");
		)catch(Exception e) {
			
			try(con.rollback();)catch (Exception ee) (ee.printStackTrace();}
		e.printStack`Trace();
	}
	finally {
		try {
			con.commit();con.close();stmt.close();;)catch(Exception e) {e.printStackTrace();}
		}
	}
		}
	
				