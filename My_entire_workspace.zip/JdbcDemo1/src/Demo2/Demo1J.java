package Demo2;

	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.Statement;
	import java.util.Scanner;
	public class Demo1J {
		
		public static void main(String[] args) throws Exception{
			//STEP 1 - registering the driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//STEP 2 - Establish the connection
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/javabatch","root","root");
			String sql="select * from users where userid=?";//dynamic query
			PreparedStatement stmt=con.prepareStatement(sql);
			
			while(true) {
				Scanner scan=new Scanner(System.in);
				System.out.println("\nPlease enter userid..:");
				int uid=scan.nextInt();
				
				//String sql="select * from users where userid="+userid;//this concatenation is bad
				//this will create sql injection problem - not recommended...its a security problem
				
				//Statement stmt=con.createStatement();
				stmt.setInt(1, uid);
				ResultSet rs=stmt.executeQuery();
				while(rs.next()) {
					System.out.printf("The salary of %s is %d",rs.getString("username"),rs.getInt("salary"));
				}
			}
			
		}
	}


	