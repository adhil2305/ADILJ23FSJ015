package skirmish;

import java.util.Scanner;

public class LargestNumberQ21 {
	public static void main(String[] args) {
		int[][] arr = {{12,54},
					   {45,65},
					   {56,54}};
		
			for(int i[] : arr) {
	
				for(int j : i) {
				//	System.out.print(arr[i][j] + " ");
				}
				System.out.println();
			}
		
			
			 Scanner sc = new Scanner(System.in);
			   int n=sc.nextInt();
			  int sum=0;
			  int i=0;
			  while(i>n){
			    if(i%3==0 && i%2==0){
			    sum = sum+i;
			  }	
			    i++;
			  }

			  System.out.print(sum);
			
			
			
			
		
	}
}
