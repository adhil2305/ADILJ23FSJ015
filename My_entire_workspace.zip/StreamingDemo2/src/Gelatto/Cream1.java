package Gelatto;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

public class Cream1 {
		public static void main(String[] args) {
			List<String> list = new ArrayList<String>();
			list.add("z"); list.add("x"); list.add("i"); list.add("p"); list.add("a"); list.add("a");
			list.add("a"); list.add("a");
			
			Iterator<String> iter = list.iterator();
			while(iter.hasNext()) {
				String s = iter.next();
				if(s.equals("c")) {
					System.out.println("I found c ...");
				}
			}
			
			list.stream().findAny().of("c").ifPresent(i -> System.out.println("I found c in a new way YO YO !"));
			
			list.stream().forEach(System.out::println);
			
			list.stream().parallel().forEachOrdered(System.out::println);
			
			System.out.println("The equals method in the stream with the limit of two ");
			List myArList = list.stream().filter(s ->s.equals("a")).limit(3).collect(Collectors.toList());
			System.out.println(myArList);
			
			list.stream().parallel().forEach(i -> System.out.println(i+"\t"));
			
			
		
		
		}
}

