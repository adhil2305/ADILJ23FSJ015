package Daily;

public class PassPassDemo3 {
	public static void main(String[] args) {
	//primitive types - byte,short,long,int,double,Integer,String,Float,Byte...
	//complex type - user defined classes	
		String i="hello";
		System.out.println("Before Passing..:"+i);
		met(i);
		System.out.println("After Passing..:"+i);
		
		System.out.println();
		
		Integer myint = Integer.valueOf(100);
		System.out.println(myint);
		// Both are same in terms of memory usage 
		// both use stack memory
		// After jdk 5 auto unboxing feature is unlocked 
		
		//int y = (double)i;// auto boxing and auto unboxing is used here
		
	}
	
	static void met(String i) {
		i="Shut up";
	}
	
}
class A{ //complex type
	String s1 = "norway";
	public void setString(String s1) {
	this.s1 = s1;
	}
}

class B {
	String s2;
	public void set(A a) {
		a.s1 = "Changed here";
	}
}