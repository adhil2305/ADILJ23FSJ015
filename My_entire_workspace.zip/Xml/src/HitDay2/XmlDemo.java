package HitDay2;

import java.io.File;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
public class XmlDemo {
	public static void main(String[] args) throws Exception{
		JAXBContext jaxbctx=JAXBContext.newInstance(Employee.class);
		
		File file=new File("emp.xml");
		
		Unmarshaller jaxbunmarshaller=jaxbctx.createUnmarshaller();
		
		Employee emp=(Employee)jaxbunmarshaller.unmarshal(file);
		
		System.out.println(emp);
	}
}