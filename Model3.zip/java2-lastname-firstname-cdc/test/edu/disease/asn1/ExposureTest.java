package edu.disease.asn1;

import static org.junit.Assert.*;
import org.junit.Test;

import java.util.Arrays;
import java.util.UUID;
public class ExposureTest {

	@Test
	public void test() {
		Exposure e2 = new Exposure();
		e2.setExposureType("D");
		String result = e2.getExposureType();
		assertEquals("D", result);
	}
	@Test
	public void testInvalidValue() {
		Exposure e = new Exposure();
		e.setExposureType("j");
		assertThrows(IllegalArgumentException.class, ()->e.setExposureType("j"));
		}
	


	
	@Test
	public void testGetDateTime() {
		Exposure e = new Exposure(java.util.UUID.randomUUID());
		java.time.LocalDateTime in = java.time.LocalDateTime.now();
		e.setDateTime(in);
		java.time.LocalDateTime out = e.getDateTime();
		assertEquals(in,out);	
		}
		@Test
		public void setMethod() {
			Exposure e = new Exposure();
			java.util.UUID in = java.util.UUID.randomUUID();
			e.setPatientId(in);
			java.util.UUID out = e.getPatientId();
			assertEquals(in,out);
			
		}
		@Test
		public void testExposure() {

			Exposure p1=new Exposure(null);
			Exposure p2 = new Exposure(null);
		//	System.out.println(p1.hashCode());
		//	System.out.println(p2.hashCode());
			boolean result=p1.equals(p2);
			assertTrue(result);		
		
		}
		@Test
		public void testExposure1() {
			UUID u1 = UUID.randomUUID();
			UUID u2 = UUID.randomUUID();
			Exposure e4=new Exposure(u1);
			Exposure e5 = new Exposure(u2);
			boolean result=e4.equals(e5);
			assertFalse(result);	
		}
		@Test
		public void testStringMet() {

			UUID patientId=UUID.randomUUID();
			String exposureType="D";
			java.time.LocalDateTime dateTime = java.time.LocalDateTime.MIN;
		
			String toStringMsg=  "Patient ID" + patientId + "Date and Time" + dateTime + "Exposure Type" + exposureType;
;
			
			Exposure e8=new Exposure();
			e8.setExposureType(exposureType);
			e8.setPatientId(patientId);
			e8.setDateTime(dateTime);

			
			assertEquals(toStringMsg,e8.toString());
		
		}
		
	 
    }
