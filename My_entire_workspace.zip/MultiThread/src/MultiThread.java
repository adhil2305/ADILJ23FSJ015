
public class MultiThread {
public static void main(String[] args) {
	Drama melody = new Drama();
	new Thread(()->{
		for(int i=0;i<5;i++) {
			melody.emotions();
		}
	}).start();
		new Thread(()->{
			for(int i=0;i<5;i++) {
				melody.comedy();
			}
	}).start();
		
}
}
class Drama{
	boolean signal;
	synchronized public void emotions() {
		if(signal) {
			try {
				wait();
			}catch(Exception ex) {ex.printStackTrace();}
			System.out.println("emotional scene..");
			signal = true ;
			notify();
		}
		synchronized public void comedy() {
			try {
				wait();
			}catch(Exception e) {}
			System.out.println("Comedy scene...");
		notify();
		}
}
