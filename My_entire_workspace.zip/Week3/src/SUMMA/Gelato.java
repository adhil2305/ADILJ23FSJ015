package SUMMA;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


public class Gelato {
	public static void main(String[] args) {
		System.out.println("pass by reference");
		Chatni one = new Chatni();
		N1 twitter = new N1();
		one.met1(twitter);
	}
}

class N1{
	int samsosa = 2;
	public void metOfN1() {
		System.out.println("this is the n1 class n1");
	}
}

class Chatni{
	
	public void met1(N1 laddu) {
		laddu.samsosa = 2;
		System.out.println(laddu.samosa);
	}
}