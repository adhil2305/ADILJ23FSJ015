package Daily;

public class PassByValueRef {
	public static void main(String[] args) {
		Laddu laddu = new Laddu();
		System.out.println(laddu.getSize());
		
		laddu.setSize(10);
		System.out.println(laddu.getSize());
		
		Passing obj = new Passing();
		//This is Passing by reference 
		//before passing
		System.out.println(laddu.getSize());//10
		obj.pbr(laddu);
		//After Passing
		System.out.println("After passing..."+laddu.getSize());
		
		System.out.println(laddu.getSize());//10

		
	}
}

class Laddu{
	 int size; //Here size is a instance variable 
	

void setSize(int size) {
	this.size = size;
}
int getSize() {
	return size;
}
}
class Passing{
	void pbr(Laddu laddu) {
		laddu.size = 5;
		
	}
	}
	

