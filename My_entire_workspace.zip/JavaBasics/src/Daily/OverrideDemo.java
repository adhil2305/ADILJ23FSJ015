package Daily;

public class OverrideDemo {
	public static void main(String[] args) {
		
						Employee12 emp=new EngineerEmployee12();
				emp.work();
				System.out.println(emp.i);//100
			}
		}
		class Employee12{
			int i=100;
			void work() {
				System.out.println("Work method called...");
			}
		}
		//PUBLIC-PROTECTED-NOMODIFIER-PRIVATE
		class EngineerEmployee12 extends Employee12{
			static int i=200;
			//sub class cannot throw an exception which the super class has not thrown
			public void work() {
				//VISIBILITY CAN BE INCREASED BUT CANNOT BE DECREASED
				//super.work();
				System.out.println("sub class work method called...");
			}
		}