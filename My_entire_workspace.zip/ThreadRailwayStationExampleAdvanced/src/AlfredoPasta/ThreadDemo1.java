package AlfredoPasta;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ThreadDemo1 {
		public static void main(String[] args) {
			ExecutorService es = Executors.newFixedThreadPool(2);
			ReservationCounter central = new ReservationCounter();
			es.execute(()->{
				Thread.currentThread().setName("Abdul");
				synchronized(central) { //Object Lock
				central.bookTicket(1000);
				try {
					Thread.sleep(1000);
				}catch(Exception e) {e.printStackTrace();}
			central.giveChange();
				}
			});
		
			es.execute(() ->{
				Thread.currentThread().setName("hakeem");
				synchronized(central) {
					//cnetral.drinkWater();
					central.bookTicket(500);
					central.giveChange();
					
				}
			});
			es.shutdown(); // NO more threads are accepted
}
}
class ReservationCounter{
	int amt;
		public void bookTicket(int amt) {
			this.amt = amt;
			String name = Thread.currentThread().getName();
			System.out.println(name + " is BOoking the ticket");
		//try { Thread.sleep(1000); }catch(Exception e) {e.printStackTrace();}
		System.out.println("Brought the amount " +amt);
		
		}
		public void giveChange() {
			String name = Thread.currentThread().getName();
			System.out.println(name+" has given the ticket along with the change.....");
			System.out.println(name+"give the change amount"+(amt-100));
		}
		public void drinkWater() {
			String name = Thread.currentThread().getName();
			System.out.println(name+" is drinking water");
		}
}
