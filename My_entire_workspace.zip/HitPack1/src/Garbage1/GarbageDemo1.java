package Garbage1;

public class GarbageDemo1 {

}



haarisinfotech
  7:46 PM
package basics;
public class GarbageDemo {
	public static void main(String[] args) {
		Runtime runtime=Runtime.getRuntime();
		
		System.out.println("Before Tathas birth..:"+runtime.freeMemory());
		GrandFather tatha=new GrandFather();
		System.out.println("After tathas birth....:"+runtime.freeMemory());
		
		tatha=null;
		
		System.out.println("After tathas death.....:"+runtime.freeMemory());
		
		runtime.gc();
		
		System.out.println("After tathas death ceremony...:"+runtime.freeMemory());
		
	}
}
class GrandFather{
	String life="";
	private String gold="under the tree....";
	public GrandFather() {
		for(int i=0;i<10000;i++) {
			life=new String("life is beautifull....:"+i);
		}
	}	
	
	@Override
	protected void finalize() throws Throwable {
		System.out.println("finalize method called....");
		System.out.println("The gold is...:"+gold);
	}
}


haarisinfotech
  8:04 PM
package basics;
import java.lang.ref.SoftReference;
import java.lang.ref.WeakReference;
public class GarbageDemo {
	public static void main(String[] args) {
		Runtime runtime=Runtime.getRuntime();
		
		System.out.println("Before Tathas birth..:"+runtime.freeMemory());
		GrandFather tatha=new GrandFather();
		System.out.println("After tathas birth....:"+runtime.freeMemory());
		
		//SoftReference<GrandFather> soft=new SoftReference<GrandFather>(tatha);
		WeakReference<GrandFather> weak=new WeakReference<GrandFather>(tatha);
		
		System.out.println("now tatha goes for pilgrimage.....");
		tatha=null;
		
		System.out.println("After tathas death.....:"+runtime.freeMemory());
		
		runtime.gc();
		
		System.out.println("After tathas death ceremony...:"+runtime.freeMemory());
		
		tatha=weak.get();
		System.out.println(tatha.getGold());
		
	}
}
class GrandFather{
	String life="";
	private String gold="under the tree....";
	public GrandFather() {
		for(int i=0;i<10000;i++) {
			life=new String("life is beautifull....:"+i);
		}
	}	
	protected String getGold() {
		return gold;
	}
	@Override
	protected void finalize() throws Throwable {
		System.out.println("finalize method called....");
		System.out.println("The gold is...:"+gold);
	}
}


haarisinfotech
  8:14 PM
package utilpack;
import java.util.HashMap;
import java.util.WeakHashMap;
public class UtilDemo7 {
	public static void main(String[] args) {
		//HashMap<String, String> hm=new HashMap<String, String>();
		WeakHashMap<String, String> hm=new WeakHashMap<String, String>();
		
		String key1=new String("a1");
		String key2=new String("a2");
		
		hm.put(key1, "abdul");
		hm.put(key2, "ram");
		
		System.out.println(hm);
		
		key1=null;
		
		System.out.println(hm);
		
		System.gc();
		
		System.out.println(hm);
		
	}
}



package iopack;
import java.io.FileInputStream;
import java.io.FileOutputStream;
public class FileOperations {
	public static void main(String[] args) throws Exception{
		FileInputStream fis=new FileInputStream("abc.properties");
		FileOutputStream fos=new FileOutputStream("copy.txt");
		System.out.println(fis.available());
		//Syst