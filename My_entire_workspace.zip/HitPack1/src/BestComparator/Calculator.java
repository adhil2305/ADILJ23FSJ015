package BestComparator;

import java.time.LocalDate;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
public class Calculator {
	public int add(int i,int j) {
		return i+j;
	}
	public int mul(int i,int j) {
		return i*j;
	}
	
	public int calculateDateDif(LocalDate sd, LocalDate ed) {
		return (int)sd.until(ed).getDays();
	}
	
	public int[] reverseArray(int a[]) {
		int length=a.length;
		int revarray[]=new int[length];
		for(int i=0;i<length;i++) {
			revarray[i]=a[length-1 -i];
		}
		return revarray;
	}
	
	public List<Employee> sortColBySal(List<Employee> emplist){
		Collections.sort(emplist,(e1,e2)->{return e1.compareTo(e2);});
		
		return emplist;
	}
}
class Employee implements Comparable<Employee>{
	String name;
	Integer salary;
	public Employee(String name,Integer salary) {
		this.name=name;
		this.salary=salary;
	}
	
	
	public int compareTo(Employee o) {
		// TODO Auto-generated method stub
		return this.salary.compareTo(o.salary);
	}
}
