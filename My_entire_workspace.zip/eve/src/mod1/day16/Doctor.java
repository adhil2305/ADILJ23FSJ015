package mod1.day16;

public interface Doctor {
	public void doCure();
}
