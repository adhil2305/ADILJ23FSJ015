package edu.disease.asn5;

import static org.junit.Assert.*;

import org.junit.Test;

public class ContainerTest {

	@Test
	public void testConstructor() {
		Container c = new Container("hello", 12);
		Object index1= c.values[0]; 		
		Object index2 = c.values[1];
		assertEquals("hello", index1);
		assertEquals(12, index2);
	}
	
	@Test
	public void CheckException() {
		
		assertThrows(IllegalArgumentException.class, () -> new Container(null));
	}
	@Test
	public void testSize() {
		Container c = new Container(12, "Andy");
		int num = c.size();
		
		assertEquals(2, num);
	}
	
	@Test
	public void testGetInvalidArgument() {
		Container c = new Container(12, "jazz");
		assertThrows(IllegalArgumentException.class, () -> c.get(3));
	}	
	
	@Test
	public void testGetMethod() {
		String s = "hello";
		int i =12;
		Container c = new Container(s, i);
		Object o1 = c.get(0);
		Object o2 = c.get(1);
		assertEquals(s, o1);
	}
	
}
