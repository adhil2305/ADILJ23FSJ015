package Demo1;

public class DemoOne {
		private void name() {
			
				//HashMap<String, String> hm=new HashMap<String, String>();
				WeakHashMap<String, String> hm=new WeakHashMap<String, String>();
				
				String key1=new String("a1");
				String key2=new String("a2");
				
				hm.put(key1, "abdul");
				hm.put(key2, "ram");
				
				System.out.println(hm);
				
				key1=null;
				
				System.out.println(hm);
				
				System.gc();
				
				System.out.println(hm);
				
			}
		}







		haarisinfotech
		  8:26 PM
		package iopack;
		import java.io.FileInputStream;
		import java.io.FileOutputStream;
		public class FileOperations {
			public static void main(String[] args) throws Exception{
				FileInputStream fis=new FileInputStream("abc.properties");
				FileOutputStream fos=new FileOutputStream("copy.txt");
				System.out.println(fis.available());
				//System.out.println((char)fis.read());
				int x=0;
				byte b[]=new byte[4];
				while((x=fis.read(b))!=-1) {
					//System.out.print((char)x);
					System.out.println("Number of bytes read..:"+x);
					String s=new String(b,0,x);
					System.out.println(s);
					fos.write(b, 0, x);
				}
			}
		}

