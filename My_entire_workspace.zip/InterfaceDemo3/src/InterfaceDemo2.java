
public class InterfaceDemo2 {
	
}
interface MyInter1 {
// public MyInter (){
// 
	//}
	public void met();
	//from jdk8 and above 
	private void mymet() {
		System.out.println("Business Methods...");
	}
	public void myMet2() {
		System.out.println("Default Business Method Called ... ");
	}
	public static void met3() {
		
	}
}
	/*
	 * Interfaces cannot have constructors on the other hand abstract classes can have constructors 
	 * Interface methods are by default abstract - AC by default you need to declare abstract 
	 * Interfaces by default can have private methods - AC can also have priate methods 
	 * Interfaces cannot have public body methods - AC can have public body methods
	 * single abstract method interfaces are called - functional interfaces 
	 * No method interfaces are called as  - marker interfaces 
	 * One class can implement many Interfaces 
	 * An Interface can extend another interface
	 * Abstract Classes can also extend other abstract classes
	 * For Both  Interface and Abstract Classes you cannot create Objects 
	 * But Abstract class Object is Created when the child Object is created 
	 * Interfaces cannot have final methods but Interfaces can have static methods 
	 * Abstract classes can have both static and final methods ..
	 */

abstract class MyAbs{
	public MyAbs(){
		
	}
	public static void 	meeet() {
		
	}
	final public void maaaa() {
		
	}
	public abstract void met();
	final private void myMet() {
		System.out.println("Business Method ...");
		
	}
	public void myMet2() {System.out.println("Business MEthod");}
}