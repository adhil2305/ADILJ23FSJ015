package mod1.day12;
//command line arguments
public class ClassesAndObjects7 {
	public static void main(String[] args) {
		System.out.println(args[3]);
		for(String s:args) {
			System.out.println(s);
		}
	}
}
