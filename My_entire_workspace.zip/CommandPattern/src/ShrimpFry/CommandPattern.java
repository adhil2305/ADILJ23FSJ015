package ShrimpFry;

public class CommandPattern {
public static void main(String[] args) {
	
			GoldenTouchMidasApp midas=new GoldenTouchMidasApp();
			MarriageHall hall1=new MarriageHall();
			Caterers caterers1=new Caterers();
			FlowerWala flowerWala1=new FlowerWala();
			ChairWala chairWala=new ChairWala();
			
			Command marriageCommand=new MarriageCommand(hall1, caterers1, flowerWala1, chairWala);
			midas.setCommand(1, marriageCommand);
			
			Command birthDayCommand=new BirthdayCommand(hall1, caterers1, flowerWala1, chairWala);
			midas.setCommand(2, birthDayCommand);
			
			midas.executeCommand(2);
		}
	}
	class MarriageHall{
		public void ping(String details) {
			System.out.println("Got the details of marriage for hall..."+details);
		}
		public void hallService() {
			System.out.println("hall service initiated...for the customer.....");
		}
	}
	class Caterers{
		public void ping(String details) {
			System.out.println("Got the details of marriage for catering..."+details);
		}
		public void cateringService() {
			System.out.println("catering service initiated...for the customer.....");
		}
	}
	class FlowerWala{
		public void ping(String details) {
			System.out.println("Got the details of marriage.for flowers..:"+details);
		}
		public void flowerService() {
			System.out.println("flower service initiated...for the customer.....");
		}
	}
	class ChairWala{
		public void ping(String details) {
			System.out.println("Got the details of marriage.for chairs..:"+details);
		}
		public void chairService() {
			System.out.println("chair service initiated...for the customer.....");
		}
	}
	abstract class Command{
		MarriageHall marriageHall;Caterers caterers;
		FlowerWala flowerWala;ChairWala chairWala;
		public Command() {}
		public Command(MarriageHall marriageHall, Caterers caterers, FlowerWala flowerWala, ChairWala chairWala) {		
			this.marriageHall = marriageHall;
			this.caterers = caterers;
			this.flowerWala = flowerWala;
			this.chairWala = chairWala;
		}
		public abstract void execute();
	}
	class MarriageCommand extends Command{
		public MarriageCommand(MarriageHall marriageHall, Caterers caterers, FlowerWala flowerWala, ChairWala chairWala) {
			super(marriageHall,caterers,flowerWala,chairWala);
		}
		@Override
		public void execute() {
			System.out.println("Congrats...your marriage job initiated...Thankyou for approaching us...");
			marriageHall.ping("so and so getting married..");
			marriageHall.hallService();
			caterers.ping("catering job initiated...");
			caterers.cateringService();
			chairWala.ping("chair wala service initiated...");
			chairWala.chairService();
			System.out.println("all the marriage related services are going to call u ,,ur details are shared.. ");
		}
	}
	class BirthdayCommand extends Command{
		public BirthdayCommand(MarriageHall marriageHall, Caterers caterers, FlowerWala flowerWala, ChairWala chairWala) {
			super(marriageHall,caterers,flowerWala,chairWala);
		}
		@Override
		public void execute() {
			System.out.println("Congrats...your birthday job initiated...Thankyou for approaching us...");
			marriageHall.ping("so and so getting birthday party celeberated..");
			marriageHall.hallService();
			caterers.ping("catering job initiated...");
			caterers.cateringService();
			chairWala.ping("chair wala service initiated...");
			chairWala.chairService();
			flowerWala.ping("flower service initiated...");
			flowerWala.flowerService();
			System.out.println("all the birthday related services are going to call u ,,ur details are shared.. ");
		}
	}
	class DummyCommand extends Command{
		@Override
		public void execute() {
			System.out.println("I am dummy yet to be operational....");
		}
	}
	class GoldenTouchMidasApp{
		Command command[]=new Command[5];
		public GoldenTouchMidasApp() {
			for(int i=0;i<5;i++) {
				command[i]=new DummyCommand();
			}
		}
		public void executeCommand(int slot) {
			command[slot].execute();
		}
		public void setCommand(int slot,Command command) {
			this.command[slot]=command;
		}
	}
	
