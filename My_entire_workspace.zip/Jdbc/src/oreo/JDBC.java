package oreo;
import java.sql.Connection; 
import java.sql.DriverManager; 
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Types; 
import java.sql.ResultSetMetaData;


public class JDBC {
public static void main(String[] args) throws Exception{
	Class.forName("com.mysql.cj.jdbc.Driver");
	Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307:Sakila","root","root");
	con.setAutoCommit(false);
	try {
		String uname = "Somu";
		String drname = "Mohan";
		int amount = 500;
		int amt = 0;
		PreparedStatement stmt = con.prepareStatement("set amt from users where uname = ?");
		stmt.setString(1, drname);
		ResultSet rs = stmt.executeQuery();
		
		if(rs.next())
{
	amt = rs.getInt("amt");
	if(amt > amount){
		amt = amt-amount;
		stmt = con.prepareStatement("Update user set amount amt = ? uname = ?");
		stmt.setInt(1,amt);
		stmt.setString(2, drname);
		stmt.executeUpdate();
		
	}
	else{
		throw new LowBalanceException();
	}
}
else {
	throw new InvalidUserException();
}
stmt = con.prepareStatement("Select amount from users where uname = ?");
stmt.setString(1,drname);
rs = stmt.executeQuery();
if(rs.next()) {
	amt = rs.getInt("amt");
	amt = amt+amount;
	stmt = con.prepareStatement("update users set amt=? where uname=?");
	stmt.setInt(1, amt);
	stmt.setString(2, drname);
	stmt.executeUpdate();
	
}
else {
	throw new InvalidUserException();
}
con.commit();
	}catch(Exception e) {
		e.printStackTrace();
		con.rollback();
	}	
	
}
}

class LowBalanceException extends Exception{
	
}
class InvalidUserException extends Exception{
}

