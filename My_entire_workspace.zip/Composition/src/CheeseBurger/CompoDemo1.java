package CheeseBurger;

public class CompoDemo1 {
	public static void main(String[] args) {
		IceCream ibaco = new VanillaCream(new ChocolateCream(new NutsTopping(new FruitsTopping())));
		System.out.println(ibaco.cost());
	}
}

abstract class IceCream{
	public abstract int cost();
}
abstract class Toppings extends IceCream{
	
}
abstract class Creams extends IceCream{
	
}
class VanillaCream extends Creams{
	IceCream iceCream;
	public VanillaCream() {}
	public VanillaCream(IceCream iceCream) {
		this.iceCream = iceCream;
	}
	@Override
	public int cost() {
		if(iceCream==null) {
			return 10;
		}
		else {
			return 10+iceCream.cost();
		}
	}
}
class ChocolateCream extends Creams{
	IceCream iceCream;
	public ChocolateCream() {}
	public ChocolateCream(IceCream iceCream) {
		this.iceCream = iceCream;
	}
	@Override
	public int cost() {
		if(iceCream==null) {
			return 20;
		}
		else {
			return 20+iceCream.cost();
		}
	}
}
class NutsTopping extends Toppings{
	IceCream iceCream;	
	public NutsTopping() {
			
		}
		public NutsTopping(IceCream iceCream) {
			this.iceCream = iceCream;
		}
		public int cost() {
			if(iceCream==null) {
				return 30;
			}
			else {
				return 30+iceCream.cost();
			}
		}
}
class FruitsTopping extends Toppings{
	IceCream iceCream;
	public FruitsTopping() {
		
	}
	public FruitsTopping(IceCream iceCream) {
		this.iceCream=iceCream;
	}
	public int cost() {
		if(iceCream==null) {
			return 15;
		}
		else {
			return 15+iceCream.cost();
		}
	}
}