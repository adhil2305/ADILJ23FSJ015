package skirmish;

public class QuotientReminder {
	public static void main(String[] args) {
		int dividend = 25;
		int divisor = 4;
		int quotient = dividend/divisor ;
		int remainder = dividend % divisor;
		System.out.println("Quotient = "+quotient);
		System.out.println("remainder = "+remainder);
		
		
	}

}
