package edu.disease.asn2;

import java.util.UUID;

public class DiseaseControlManagerImpl implements DiseaseControlManager {
	private Disease[] diseases = new Disease[10];
	private Patient[] patients = new Patient[5];

	public void addDiseaseInArray(Disease d) {
		for(int i=0;i<diseases.length;i++) {
			if(diseases[i]==null) {
				diseases[i]=d;
				break;
			}
		}
	}

	public void addPatientInArray(Patient p) {
		for(int i=0;i<patients.length;i++) {
			if(patients[i]==null) {
				patients[i]=p;
				break;
			}
		}
	}

	@Override
	public Disease addDisease(String name, boolean infectious) {
		Disease obj;
		if (infectious) {
			obj = new InfectiousDisease();
		}
		else {
			obj = new NonInfectiousDisease();
		}
		obj.setName(name);
		return obj;
	}

	@Override
	public void addDiseaseToPatient(UUID patientId, UUID diseaseId) {
		Patient patient = getPatient(patientId);
		if (patient == null) {
			throw new IllegalArgumentException();
		}
		Disease disease = getDisease(diseaseId);
		if (disease == null) {
			throw new IllegalArgumentException();
		}
		patient.addDiseaseId(diseaseId);
	}

	@Override
	public void addExposureToPatient(UUID patientId, Exposure exposure) {
		Patient patient = getPatient(patientId);
		if (patient == null) {
			throw new IllegalArgumentException();
		}
		patient.addExposure(exposure);
	}

	@Override
	public Patient addPatient(String firstName, String lastName, int maxDiseases, int maxExposures) {
		Patient patient = new Patient(maxDiseases, maxExposures);
		patient.setFirstName(firstName);
		patient.setLastName(lastName);
		return patient;
	}

	@Override
	public Disease getDisease(UUID diseaseId) {
		Disease disease = null;
		for (Disease d : diseases) {
			if (d == null || d.getDiseaseId().equals(diseaseId)) {
				disease = d;
				break;
			}
		}
		return disease;
	}

	@Override
	public Patient getPatient(UUID patientId) {
		Patient patient = null;
		for (Patient p : patients) {
			if (p == null || p.getPatientId().equals(patientId)) {
				patient = p;
				break;
			}
		}
		return patient;
	}
}
