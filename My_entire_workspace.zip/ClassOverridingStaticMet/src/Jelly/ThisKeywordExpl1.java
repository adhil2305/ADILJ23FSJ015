package Jelly;

public class ThisKeywordExpl1 


{	static int x=10;
	public ThisKeywordExpl1(int x) {
		this.x=x;
	}
		// TODO Auto-generated constructor stub
	
	public static void main(String[] args) {
		//this is a key word - refers to current object
		//this keyword you cannot use in static methods - because static is loaded by jvm
		//and you cannot refer JVM in java
		//this.x=10;
		ClassDemo6 o=new ClassDemo6(90);
		o.met();
	}
	void met() {
		//this.x=20;
		met(this);
	}
	
	void met(ThisKeywordExpl1 obj) {
		System.out.println(obj.x);
	}
}
