package Java1;
import java.util.*;
// Page number175 in Headfirst Book

public class DotComBust {
	
	private Gamehelper helper = new GameHelper();
	private ArrayList<DotCom> dotComsList = new ArrayList<DotCom>();
	private int numOfGuesses = 0;
	
	private void setUpGame() {
		//First make some dot coms and give some locations
		DotCom one = new DotCom();
		one.SetName("Pets.com");
		DotCom two = new DotCom();
		two.setName("eToys.com");
		DotCom three = new DotCom();
		three.setName("Go2.com");
		DotComsList.add(one);
		DotComsList.add(two);
		DotcomsList.add(three);
		
		System.out.println("Your Goal is to sink three dot coms");
		System.out.println("Pets.com,eToys.com,Go2.com");
		System.out.println("Try to sink all of them in the least number of turns");
		
		for(DotCom dotComToSet : dotComsList) {
			ArrayList<String> newLocation = new helper.placeDotCom(3);
			dotComToSet.SetLocation(Cells(newLocation));
		}//close for loop

		
		
	}//close setUpGame method
	
	private void startPlaying() {
		while(!DotComsList.isEmpty) {
			String userGuess = helper.getUserInput("Enter a Guesss");
			checkUserGuess(UserGuess);
			
		}//close while loop here
		finishGame();
	}//close Stop playing game method
	private checkUserGuess(String UserGuess) {
		numOfGuesses++;
		String result = "miss";
		
		for(DotCom dotComToTest : dotComsList) {
			result = dotComToTest.checkYourself(UserGuess);
			if(result.equals("hit")) {
			break;
			}
			if(result.equals("kill")) {
				dotComsList.remove(dotComToTest);
				break;
			}
		}//close for
	System.out.println(result);
	}// lose method
private void finishGame() {
	System.out.println("All Dot coms are dead your stocks are worthless");
	if(numberOfGuesses<=10) {
		System.out.println("You only took "+numberOfGuesses+"guesses");
		
	}//close of if 
	else {
		System.out.println("Took you long enough Number of Guesses "+numberOfGuesses+"guesses");
		
	}
	
}//close the method



public static void main(String[] args) {
	DotComBust game = new DotComBust();
	game.setUpGame();
	game.startPlaying();
}//closing main method
}//End of the DotComBust classs