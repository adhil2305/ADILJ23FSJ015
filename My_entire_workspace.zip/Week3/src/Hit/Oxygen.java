package Hit;
import java.util.*;
public class Oxygen {
	public static void main(String[] args) {
		Diamond d = new Diamond();
		d.jark();
		
	int l =10;
	System.out.println(l/2);
			MySeniorSuper sup = new MySub("hello");
			sup.met();
			System.out.println(sup.isuper);
			// s - solid responsibitliy 
			// o - open close principle 
			//liscow substitution principle the child can replace the parent
			//code 
			//compostion 
			//object re usability
			
			
			//
			//dependency inversion priciple 
		
		}
	}

	class MySeniorSuper{
		int isuper = 100;
		public MySeniorSuper(int i) {
			System.out.println("Constructor of the Super Senior is called...");
			//TODO auto generated constructor 
		}
		protected void met() {
			System.out.println("met of super senior called ...");
		}
	}

	class MySuper extends MySeniorSuper{
		int isuper= 200;
		public MySuper(String s) {
			super(100);
			System.out.println("Constructor of MySenior called ..."+s);
			//ToDO auto generated constructor
			
		}
		public void met1(int sus) {
			
			System.out.println(sus);
		}
		public void met() {
			System.out.println(" Met of the sub senior called... ");
			//super.met();
		}
	}

	class MySub extends MySuper{
		MySeniorSuper soSuper;
		public MySub(String s) {
			super("blabla");
			System.out.println("sub .. :"+s);
		}
		int isuper = 300;
		public void met() {
			System.out.println("met of sub.."+isuper);
			super.met();
			int kindOfSus = 900;
			super.met1(kindOfSus);
		}
	}
	
	class Diamond{
		public int jark() {
			double mark_avg = 0;
			Scanner sc = new Scanner(System.in);
			int arr[] = new int[6];
			for(int i=0;i<arr.length;i++) {
				arr[i] = sc.nextInt();
			}
			int sum = arr[0];
			int max = arr[0];
			for( int i=1;i<arr.length;i++) {
				sum = sum+arr[i];
				if(arr[i]>max) {
					max = arr[i];
				}
			}
			int result = max;
			mark_avg = sum/arr.length;
			System.out.println(mark_avg);

			return result;
			
		}
	}