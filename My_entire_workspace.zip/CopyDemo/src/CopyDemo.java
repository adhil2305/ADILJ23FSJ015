import java.io.FileReader;
import java.io.FileWriter;
public class CopyDemo {
	public static void main(String[] args) {
		try(				
				FileReader in=new FileReader("temp.txt");
				FileWriter out=new FileWriter("copy.txt");
				){
			
			int i=0;
			char buffer[]=new char[6];//buffer in which data is stored
			while((i=in.read(buffer))!=-1) {
				//int i will contain the number of characters read - i.e how many characters read
				//System.out.println((char)i);
				//out.write(i);
				System.out.println("No of Character read..:"+i);
				String s=new String(buffer,0,i);
				System.out.println(s);
				out.write(buffer,0,i);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
}