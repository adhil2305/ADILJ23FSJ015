
public class InterfaceDemo4 {
	public static void main(String[] args) {
		Child c = new Child();
		c.met(); c.met2();
	}
}
interface GrandParent {
	default public void met() {
		System.out.println("GrandParent Method called..");
	}
}
interface Parent {
	default public void met2() {
		System.out.println("Parent MethOd Called..");
		
	}
}
class Child implements Parent, GrandParent{
	
}