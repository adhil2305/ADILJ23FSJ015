import java.io.*;
import java.util.Scanner;

import com.sun.source.tree.CatchTree;

	public class Demo {
		public static void main(String[] args) {
			/*
			 * Array size is fixed 
			 * ArrayList size is not fixed 
			 * Array is homogeneous arrayList is heterogeneous
			 * 
			 * <Employee> that we declare in an arrya list is where we could be able to access the homogeneous objects 
			 */// Tim index and merge algorithm is used for sorting in the collections framework
			
			 */
		}		
		}