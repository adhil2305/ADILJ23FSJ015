package Biriyani;

public class InherDemo1 {
	public static void main(String[] args) {
		// THe world thinks interfaces are the replacement for abstract classess
		/*Abstract classes doesnot exist
		 * What is the correct approach 
		 */
		
	}

}
