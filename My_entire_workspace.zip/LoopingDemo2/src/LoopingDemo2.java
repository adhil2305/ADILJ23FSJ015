
public class LoopingDemo2 {
public static void main(String[] args) {
	for(int i = 1;i<10;i++) {
		if (i%2 == 0) {
			System.out.println(i);
			}
		
			System.out.println(i);
		}
	
	boolean b = true;
	a:{
		System.out.println("ablock");
	
	b:{
		
		System.out.println("b block");
	
	c:{if (b) {break a;}
		System.out.println("c block");
	
	d:{
		System.out.println("d block");
	}
	}
}
	}}}


