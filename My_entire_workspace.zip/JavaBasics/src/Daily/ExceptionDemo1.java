package Daily;

import java.util.Scanner;
public class ExceptionDemo1 {
	public static void main(String[] args) {
		System.out.println("Before division...");
		try {
			Scanner scan=new Scanner(System.in);
			System.out.println("Please enter a number..:");
			int n=scan.nextInt();
			if(n==0) {
				throw new ZeroDivisionIllegal("are you mad, I am not asking your marks.....");
			}
			int i=1/n;
		}catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println("after division...");
	}
}
class ZeroDivisionIllegal extends Exception{
	String msg;
	public ZeroDivisionIllegal(String msg) {
		this.msg=msg;
	}
	@Override
	public String toString() {
		return this.msg;
	}
}
