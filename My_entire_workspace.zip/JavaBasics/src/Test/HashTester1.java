package Test;

import static org.junit.Assert.*;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import org.junit.Test;

import Daily.HashCodeEqualsMethod;


import org.junit.Test;

public class HashTester1 {
	
		
		@Test
		public void testSameName() {
			Patient p1=new Patient("abdul");
			Patient p2=new Patient("abdul");
			
			System.out.println(p1.hashCode());
			System.out.println(p2.hashCode());
			boolean result=p1.equals(p2);
			assertTrue(result);		
		}
		@Test
		public void testDifferentName() {
			Patient p1=new Patient("abdul");
			Patient p2=new Patient("rahim");
			
			System.out.println(p1.hashCode());
			System.out.println(p2.hashCode());
			boolean result=p1.equals(p2);
			assertFalse(result);
		}
		@Test
		public void testForEmptyCons() {
			Patient p1=new Patient();
			Patient p2=new Patient();
			
			System.out.println(p1.hashCode());
			System.out.println(p2.hashCode());
			boolean result=p1.equals(p2);
			assertTrue(result);
		}
		
		@Test
		public void testForSameNameAndCity() {
			Patient p1=new Patient("abdul","chennai");
			Patient p2=new Patient("abdul","chennai");
			
			System.out.println(p1.hashCode());
			System.out.println(p2.hashCode());
			boolean result=p1.equals(p2);
			assertTrue(result);
		}
		
		@Test
		public void testForSameNameAndDifCity() {
			Patient p1=new Patient("abdul","chennai");
			Patient p2=new Patient("abdul","banglore");
			
			System.out.println(p1.hashCode());
			System.out.println(p2.hashCode());
			boolean result=p1.equals(p2);
			assertFalse(result);
		}
	}
	
	
	
	
	
	


}
