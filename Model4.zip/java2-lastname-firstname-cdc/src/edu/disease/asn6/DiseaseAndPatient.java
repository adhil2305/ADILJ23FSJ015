package edu.disease.asn6;

import java.util.ArrayList;
import java.util.List;

public class DiseaseAndPatient {
private String folderpath;
	
	private List<Disease> diseases = new ArrayList<>();
	private List<Patient> patients = new ArrayList<>();
	
	
	public DiseaseAndPatient(List<Disease> diseases, List<Patient> patients) {
		this.patients = patients;
		this.diseases = diseases;
		
	}
	
//	public static void main(String[] args) {
//		Patient p1 = new Patient();
//		Disease d1 = new InfectiousDisease();
//		Disease[] diseases = new Disease[1];
//		Patient [] patients = new  Patient[1];
//		patients[0] = p1;
//		diseases[0] = d1;
//		DiseaseAndPatient dp = new DiseaseAndPatient(diseases, patients);
//		dp.setFolderPath("F:/cat");
//		dp.save(diseases, patients);
//		dp.init("F:/cat");
//		
//	
	
//}
	//private Disease[] diseases;
	//private Patient[] patients;
	
	/*
	 * This method sets the folder to the current object
	 */
	public void setFolderPath(String folderpath) {
		this.folderpath = folderpath;
	}
	public String getFolderPath() {
		return this.folderpath;
	}
	
	/*
	 * Constructor
	 */

	
	public DiseaseAndPatient() {
		
	}
	
	/*
	 * This sets the diseasesto the current diseases you just entered 
	 */
	public List<Disease> getDiseases() {
		return this.diseases;
	}
	/*
	 * This 		 the diseases you just entered
	 */
	public void setDiseases(List<Disease> diseases) {
		this.diseases = diseases;
	}
	/*
	 * This sets the patient you enter into the current object
	 */
	public void setPatient(List<Patient> patients) {
		this.patients=  patients;
	}
	/*
	 * This returns a patient
	 */
	public List<Patient> getPatients() {
		return patients;
	}
	/*
	 * save method that has two parameters diseases and patients it accepts diseasaes and patients 
	 */
	
	
	
	
	
	
	
}
