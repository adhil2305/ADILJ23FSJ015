
public class GenericsDemo {
	public static void main (String[] args) {
		GoodPaintBrush brush = new GoodPaintBrush();
		
		brush.p = new RedPaint();
		brush.p = new BluePaint();
		brush.p.doPaint();
		
		GoodGoodPaintBrush<Water> brushgood = new GoodGoodPaintBrush<>(); 
		brushgood.setObj(new Water());
		brushgood.getObj();
		
		GoodGoodPaintBrush<Paint> brushgood2 = new GoodGoodPaintBrush<>();
		brushgood2.setObj(new Paint());
		brushgood2.getObj();
		GoodGoodPaintBrush<Water> waterBrush = new GoodGoodPaintBrush<>();
		waterBrush.setObj(new Water());
		waterBrush.getObj();
	}
}
class GoodGoodPaintBrush <T>{
	T obj;
	public void setObj(T obj) {
		this.obj = obj;
	}
	public T getObj() {
		//return this.obj ;
	return obj;
	}
}
class Paint{
	public void doPaint() {
		
	}
}
class Water {
	
}

class GoodPaintBrush {
	Paint p;
	public void doPaint() {
		System.out.println("Brush called ...");
	}
}


class RedPaint extends Paint{
	public void doPaint() {
		System.out.println("Red do paint...");
	}
}
class BluePaint extends Paint{
	public void doPaint() {
		System.out.println("Blue");
	}
}

class GreenPaint extends Paint {
	public void doPaint() {
		System.out.println("Green do paint...");
	}
}