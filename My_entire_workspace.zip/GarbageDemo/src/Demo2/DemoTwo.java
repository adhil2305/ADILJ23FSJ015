package Demo2;

public class DemoTwo {

	
	public class GarbageDemo {
		public static void main(String[] args) {
			Runtime runtime=Runtime.getRuntime();
			
			System.out.println("Before Tathas birth..:"+runtime.freeMemory());
			GrandFather tatha=new GrandFather();
			System.out.println("After tathas birth....:"+runtime.freeMemory());
			
			tatha=null;
			
			System.out.println("After tathas death.....:"+runtime.freeMemory());
			
			runtime.gc();
			
			System.out.println("After tathas death ceremony...:"+runtime.freeMemory());
			
		}
	}
	class GrandFather{
		String life="";
		private String gold="under the tree....";
		public GrandFather() {
			for(int i=0;i<10000;i++) {
				life=new String("life is beautifull....:"+i);
			}
		}	
		
		@Override
		protected void finalize() throws Throwable {
			System.out.println("finalize method called....");
			System.out.println("The gold is...:"+gold);
		}
	}







	haarisinfot
}