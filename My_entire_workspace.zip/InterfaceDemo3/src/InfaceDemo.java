
public class InfaceDemo {
	public static void main(String[] args) {
		DominoPizza domino = new MateenPizza();
		domino.doPizzaBusiness();
	}
}

interface Pizza{
	public default void shape() {
		System.out.println("Should be Round...");
	}
	public default void madeOf() {
		System.out.println("Should be made of Wheat ... ");
	}
}

interface DominoPizza extends Pizza{
	private void addIngredients() {
		System.out.println("Dominos Secret Ingredients added...");
	}
	private void bakePizza() {
		System.out.println("Dominos special bakig method implemented..");
	}
	private void packPizza() {
		System.out.println("Domio's secret propreitary packing deployed..");
	}
	public void deliverPizza();
		public void collectMoney();
		
	
	public default void doPizzaBusiness() {//Template Business
		collectMoney();
		shape();
		madeOf();
		addIngredients();
		bakePizza();
		packPizza();
		deliverPizza();
	}
}

class MateenPizza implements DominoPizza{
	@Override
	public void collectMoney() {
		System.out.println("Collect Money in Rupees...");
	}
	@Override
	public void deliverPizza() {
		System.out.println("Mateen delivers pizza in two wheeler........");
	}
}