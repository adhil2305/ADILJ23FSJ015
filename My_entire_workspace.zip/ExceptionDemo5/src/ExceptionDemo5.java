
public class ExceptionDemo5 {
	//main driver method
	public static void main(String[] args) {
		//Note how inner class Object is created inside the main() method
		Outer.Inner inn1 = new Outer().new Inner("Wisaam");
		Outer.Inner inn2 = new Outer().new Inner("Irfan");
		Outer.Inner inn3 = new Outer().new Inner("Rehan");
		System.out.println(inn1.getClass().getName());
		
		System.out.println(inn1);
		System.out.println(inn2);
		System.out.println(inn3);
		System.out.println("______");

		
		
		Outer out = new Outer();
		Outer.Inner in1 = out.new Inner("kaja");
		Outer.Inner in2 = out.new Inner("karthic");
		Outer.Inner in3 = out.new Inner("moideen");
		
		System.out.println(in1.getClass().getName());
		System.out.println(in1);
		System.out.println(in2);
		System.out.println(in3);

		
		
	}

}

class Outer{
	private String name;
	static class Inner{
		public static Inner (String name) {
			Outer.this.name = name;
		}
		public void show() {
			System.out.println("In a nested class method...");
		}
		@Override
		public String toString() {
			// TODO Auto-generated method stub
			return "name : " + Outer.this.name;
		}	
	}
	
}