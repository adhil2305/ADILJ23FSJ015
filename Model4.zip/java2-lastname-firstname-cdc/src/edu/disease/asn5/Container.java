package edu.disease.asn5;


public class Container<T> {
	T obj;
	Object[] values;
	/*
	 * The T obj is for the generic type good practices
	 * 
	 */
	public static void main(String[] args) {
		Container c = new Container("hello",3.14);
		System.out.println(c.length);
		
		Object obj1 = c.get(0);
		System.out.println(obj1);
	}
	
	private int length;
	/*
	 * The constructor can hold any number of variables 
	 * of different types --
	 */
		public Container(Object... values) {
			// TODO Auto-generated constructor stub
			this.values = values;
			if(values == null) {
				throw new IllegalArgumentException("You cannot leave this container empty ");
			}
			int length = 0;
			for (Object value: values) {
				length++;
			}
			this.length = length;
		}
		public int size() {
			return this.length;
			}
		public T get(int index) {
			if(index >=0 && index < values.length) {
				T obj1 = (T)values[index];
				return obj1;
			}else {
				throw new IllegalArgumentException("Please enter a valid index");

			
			}
		}
}
