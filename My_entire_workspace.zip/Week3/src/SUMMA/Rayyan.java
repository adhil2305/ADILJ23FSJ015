package SUMMA;

public class Rayyan {
		public static void main(String[] args) {
			AsianPaints a1 =new AsianPaints();
			a1.services(new America());
			Nerolac n1= new Nerolac();
			n1.services(new America());
			X x1 = new X();
			X x2 = new Y();
			Y y1 = new Y();
			//(Y)x2.do2();
			
			Painter ramu = ()->System.out.println("Ramu is painting shut up");
			System.out.println(ramu);
			System.out.println(x2);
		}
}

class X{ void do1() {}}
class Y extends X{void do2(){}}


//Functional Interface 
interface Painter{
	public void paint();
}

class America implements Painter{
	public void paint() {
		System.out.println("Hey i'm the monopoly here");
	}
}

class AsianPaints{
	
	public void services(America am) {
		am.paint();
		System.out.println("AsianPaints is here ...");
	}
}

class Nerolac{
	
	public void services(America am) {
		am.paint();
		System.out.println("nerolac paint is here ");
	}
}
