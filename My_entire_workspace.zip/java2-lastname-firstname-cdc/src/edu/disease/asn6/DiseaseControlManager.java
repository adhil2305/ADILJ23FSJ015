package edu.disease.asn6;

import java.util.List;
import java.util.UUID;
public interface DiseaseControlManager {

	Disease addDisease(String name, boolean infectious);

	List<Disease> getDiseases(UUID diseaseId);

	Patient addPatient(String firstName, String lastName, int maxDiseases, int maxExposures);

	Patient getPatient(UUID patientId);
	
	Disease getDisease(UUID diseaseId);
	
	void addPatientInArray(Patient patient);
	
	List<Patient> getPatients();
	
	void addDiseaseToPatient(UUID patientId, UUID diseaseId);

	void addExposureToPatient(UUID patientId, Exposure exposure);
}
