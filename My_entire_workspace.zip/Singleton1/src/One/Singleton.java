package One;
import java.util.concurrent.ExecutorService;
import java.util.concurrnet.Executors;

public class Singleton {
public static void main(String[] args) {
	ExecutorService es  = executor(new FixedThreadPool(2));
	
	es.execute(newRunnable()){
		public void run() {
			MySingleTon obj2 = MySingleTon.createinstance();
		}
	});
	es.shutdown();
}}
class MySingleTon{
	private MySingleTon(){
		System.out.println("Mysigleon cons called");
		
	}
	private static My Sigleton obj;
	
	synchronised public static MySingleTon createinstance() {
		if(obj==null) {
			try {Thread.sleep(100);}catch(Exception e) {
				
			}
			obj = new MySingleTon();}
		return obj;``
		              ]
	}
}
		}
	}
}
}
