package Daily;

public class HashCodeEqualsMethod{	
	public static void main(String[] args) {
		Patient p1 = new Patient(null);
		Patient p2 = new Patient(null);
		System.out.println(p1.equals(p2));

	}	
}

class Patient {

	
	String name,city;
	public Patient(String name) {
		this.name=name;
	}
	public Patient(String name,String city) {
		this.name=name;
		this.city=city;
	}
	
	@Override
	public int hashCode() {
		if(city==null) {
			return name.hashCode();
		}
		else {
			return name.hashCode()+city.hashCode();
		}
	}
	@Override
	public boolean equals(Object obj) {
		Patient p = (Patient)obj;
		if(name!=null && city!=null) {
			if(name.hashCode()==p.name.hashCode() && city.hashCode()==p.city.hashCode()) {
				return true;
			}
			else {
				return false;
			}
		}
		else if(name!=null && city==null) {
			if(name.hashCode()==p.name.hashCode()) {
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return true;
			}
		
	}
}
