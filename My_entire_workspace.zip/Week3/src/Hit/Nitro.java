package Hit;

public class Nitro {
		public static void main(String[] args) {
			MyPass my1= ()->{System.out.println("hide the code");};
			my1.met();
			MyPass my2 =  new Nitro()::myMethod23;
		my2.met();
		}
		public void myMethod23(){
			System.out.println("Recoupment...");
		}
		}

interface MyPass {
	public void met();
	
}

/*
 * class MyInterImplementation implements MyPass{
 * 
 * @Override public void met() { System.out.println("version..- update..f"); } }
 */