 import java.lang.StringBuilder;
import java.util.StringTokenizer;
import java.lang.StringBuffer;
public class StringBufferDemo {
	public static void main(String[] args) {
		long startTime = System.currentTimeMillis();
		StringBuffer sb = new StringBuffer("Md.");
		for(int i= 0;i<10000;i++) {
			sb.append("thaqi");
				}
		System.out.println("Time taken by String buffer:" +(System.currentTimeMillis()-startTime)+"ms");
		System.currentTimeMillis();
		StringBuilder sb2 = new StringBuilder("Md.");
		for(int i = 0; i<10000; i++) {
			sb2.append("Adhil");
		}
			System.out.println("Time taken by StringBuilder is :"+(System.currentTimeMillis()-startTime)+"ms");
			StringTokenizer st = new StringTokenizer("Md.");
			for(i=0;i<10000;i++) {
				//st.("Rayyan");				
			}
			}
	
}
