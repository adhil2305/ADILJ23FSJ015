package mod1.day16;

public interface Pilot {
	public void doFly();
}
