package mod1.day12;

public class Hello2 {
	 HelloWorld h;//complex type
}
