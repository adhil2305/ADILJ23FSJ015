
public class LoopingDemo {
	public static void main(String[] args) {
		boolean b = false;
		while b{ 
			System.out.println ("While loop called ...");
		}
	}

}
