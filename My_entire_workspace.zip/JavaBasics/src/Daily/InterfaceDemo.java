package Daily;

public class InterfaceDemo {
	public static void main(String[] args) {
		
			PaintCompany pc = new PaintCompany();
			pc.p = new HousePainter();
			
			pc.p.paint();
			Painter.hello();
			
	}
}
 /**
  * Why do need Interface ?
  * Paint is a classification noun but painter is a 
  * abstract noun
  * 
  * Paint is a classifier but painter is a role 
  * Red Paint is a kind of paint but WallPainter is a 
  * person who plays the role of a Painter Interface
  * 
  * We use Implements Keyword
  * 
  * @author Adhil
  *
  */

class PaintCompany{
	Painter p;
}
interface Artist{
	
}

interface Painter{
	public static void hello() {//It is mandatory that 
		// you must not or should not override the
		// Method of the interface.
		System.out.println("Painter");
	}
	public abstract void paint();
	
}

class HousePainter implements Painter,Artist{
	public void paint(){
		System.out.println("House Painting");
	}
	/*
	 * public void hello() { System.out.println("House painter says hello"); }
	 */
}
class WallPainter implements Painter{
	@Override
	public void paint() {
		System.out.println("Wall painter is working");
	}
	
}