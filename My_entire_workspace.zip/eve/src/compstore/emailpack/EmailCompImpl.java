package compstore.emailpack;

import java.io.Serializable;

public class EmailCompImpl implements EmailComponent{
	public EmailCompImpl() {
		// TODO Auto-generated constructor stub
	}
	public void sendEmail(String data) {
		System.out.println("email logic written......");
	}
}
