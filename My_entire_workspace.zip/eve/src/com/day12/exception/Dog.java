package com.day12.exception;

public class Dog {
	public void play(Item item)throws DogExceptions {
		item.execute();
	}
}
