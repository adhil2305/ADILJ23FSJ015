package edu.disease.asn2;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Objects;
import java.util.UUID;


public class Patient {
	private UUID patientId, diseaseIds[];
	private String firstName, lastName;
	private Exposure[] exposures;
	
	public Patient(String firstName,String lastName) {
		this.firstName = firstName;
		this.lastName = lastName;
	}
	
	public Patient() {
		
	}
	
	
	public Patient(int maxDiseases, int maxExposures) {
		if (maxDiseases <= 0 || maxExposures <= 0) {
			throw new IllegalArgumentException();
		}
		diseaseIds = new UUID[maxDiseases];
		exposures = new Exposure[maxExposures];
	}

	public void addDiseaseId(UUID diseaseId) {
		for(int i=0;i<diseaseIds.length;i++) {
			if(diseaseIds[i]==null) {
				diseaseIds[i]=diseaseId;
				break;
			}
		}
	}

	public void addExposure(Exposure exposure) {
		for(int i=0;i<exposures.length;i++) {
			if(exposures[i]==null) {
				exposures[i]=exposure;
				break;
			}
		}
	}

	
	public UUID getPatientId() {
		return patientId;
	}

	
	public void setPatientId(UUID patientId) {
		this.patientId = patientId;
	}

	
	public String getFirstName() {
		return firstName;
	}

	
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	
	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	@Override
	public int hashCode() {
		return Objects.hash(patientId);
	}

	@Override
	public boolean equals(Object obj) {
		Patient p=(Patient)obj;
		if(patientId!=null && p.patientId!=null) {
			return this.hashCode() == obj.hashCode();
		}
		return false;
	}

	
	public String toString() {
		return "patientId " + patientId + "diseaseIds" + Arrays.toString(diseaseIds) + ", firstName="+ firstName + "lastName" + lastName + "exposures" + Arrays.toString(exposures);

	}
	public static Patient[] sort(Patient[] patients) {  
		Comparator<Patient> customComparator = Comparator.comparing(Patient::getLastName, String.CASE_INSENSITIVE_ORDER)
				.thenComparing(Patient::getFirstName, String.CASE_INSENSITIVE_ORDER);
		Arrays.sort(patients, customComparator);
		return patients;
	}
	


}



	

