package DAO;

import java.util.List;

public class UserDAOimpl implements UserDao {
DBConnection dbCon;
	public UserDAOimpl() {
	dbCon = DBConnection.getDBCon();
}
	private Connection con;
	private PreparedStatement ps;
	private ResultSet rs;
	@Override
	public boolean checkUser(String uname, String upass) {
		// TODO Auto-generated method stub
		try {
		con = dbCon.getConnection();
		ps = con.prepareStatement("Select * fROM USER where uname = ? and upass = ?")
	} catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
	}
		return false;
	}

	@Override
	public void insertUser(String uname, String upass, int flag) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateUser(int uid) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteUser(User user) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteUser(int uid) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public User getUser(int uid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<User> getAllUser() {
		// TODO Auto-generated method stub
		return null;
	}

	
}
