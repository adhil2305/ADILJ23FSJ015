package Cheesecake;

public class PaintBrush {
public static void main(String[] args) {
	
	GoodPaintBrush brush = new GoodPaintBrush();
	RedPaint rp = new RedPaint();
	//BluePaint bp = new BluePaint();
	GreenPaint gp = new GreenPaint();
	brush.p=gp;
	brush.doPaint();
	}
}
 class GoodPaintBrush{
	 public GoodPaintBrush() {
		 System.out.println("Constructor of the paint brush was called ...");
	 }
	  Paint p;
	 public void doPaint() {
		 System.out.println(p);
	 }
 }
abstract class Paint{
	Paint p;
	public Paint() {
		System.out.println("Constructor of the Paint class was called ....");
	}
	public abstract void stroke();
	
	}
  class RedPaint extends Paint{
	  public void stroke() {
		  System.out.println("Red Nerolac Paint..."+p);
	  }
}
  class GreenPaint extends Paint{
	public void stroke() {
		System.out.println("Green paint....");
	}
}
 class BluePaint extends Paint{
	 public void stroke() {
		 System.out.println("Blue paint...");
	 }
 }