package Tacos;

public class Inher1 {
		public static void main(String[] args) {
			/*
			 * Association - knowledge of
Aggregation - Part of
Composition - Whole of
Generalization - Kind of
Inheritance usage
Code Reusability 2. Object reusability 3. part whole hierarchy 4. composition 5. removal of if-else-if 6. polymorphic query
super - refers super class property, super class method and super class constructor
properties are not overriden in java
without calling the super class constructor the object of sub class cannot be created
visibility cannot be reduced
			 */
		}
}
