package InputSTREAM3;

import java.io.FileInputStream;
import java.io.FileOutputStream;

public class File3 {
		public static void main(String[] args) {
			FileInputStream fis = new FileInputStream(zxc.properties);
			FileOutputStream fos = new FileOutputStream(copy.txt);
			
			System.out.println(fis.available());
			System.out.println((char)fis.read());
			int x =0;
			
			byte b[] = new byte[4];
			while((x=fis.read(b))!== -1) {
			//System.out.println((char)x);
			System.out.println("The numbeer of bytes read is "+x);
			String s = new String(b,0,x);
			System.out.println(s);
			fos.write(b,0,x);
			}
			
		}
}
