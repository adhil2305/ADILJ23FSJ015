package Samosa;

public class Kishmish {
		public static void main(String[] args) {
			String str = "Hello...Hello...Hello...";
			str.charAt(0);
			System.out.println(str.charAt(0));
			
			//byte short int long are compatible type 
			//byte has eight bit 
			//short is 16 bit
			
			Integer i = 1000;
			System.out.println(i.intValue());
		
			int x = Integer.parseInt("2000");
			System.out.println(x+10);
			
			//String objects are immutable
			String s1 = "Dhanish";
			String temp = s1;
			System.out.println(temp);
			s1 = "sun microsystems "+s1;
			System.out.println(s1);
			
			Integer n = 10000;
			Integer tempn = n;
			n= 1000+n;
			System.out.println(n);
			System.out.println(tempn);
			
			
		
		
		}
}
