package mod1.day16;
//an interface can extend another interface
public interface Surgeon extends Doctor{
	public void doSurgery();
}
