package edu.disease.asn3;

import static org.junit.Assert.*;

import java.util.UUID;

import org.junit.Test;

public class DiseaseFIleRepositoryTest {

	@Test
	public void testTheSaveMet() {
	//	fail("Not yet implemented");
		
		

		Patient p1 = new Patient();
		p1.setFirstName("Drake");
		p1.setPatientId(UUID.randomUUID());
		Disease d1 = new InfectiousDisease();
		d1.setName("flu");
		Disease[] diseases = new Disease[1];
		Patient [] patients = new  Patient[1];
		patients[0] = p1;
		diseases[0] = d1;
		DiseaseFIleRepository dp = new DiseaseFIleRepository();
				
		dp.setFolderPath("F:/cat");
		dp.save(diseases, patients);
		System.out.println("init function");
		dp.init("F:/cat");
		System.out.println("initfunction");
		System.out.println(dp);
		System.out.println(dp.init("F:/cat"));
		
		DiseaseAndPatient dpTester = dp.init("F:/cat");
		System.out.println(dpTester);
		System.out.println("Is this drake");
		System.out.println(patients[0]);
		Patient[] pall = dpTester.getPatients();
		Disease[] dall = dpTester.getDiseases();
		System.out.println(pall[0]);
		System.out.println("first patient"+ p1);
		Patient[] p2 = dpTester.getPatients();
		Patient p3 = p2[0];
		System.out.println("madrid");
		System.out.println(p3.getFirstName());
		System.out.println(p1.getFirstName());
		Disease[] d2 = dpTester.getDiseases();
		Disease d3 = d2[0];
		d1.getName();
		
		assertEquals(p1.getFirstName(), p3.getFirstName());
		assertEquals(d3.getName(), d1.getName());

				
	}

}
