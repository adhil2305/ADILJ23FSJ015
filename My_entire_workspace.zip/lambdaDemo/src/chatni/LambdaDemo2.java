package chatni;

public class LambdaDemo2 {
	public static void main(String[] args) {
		Alfred sendsBot1 = MyBusinessClass::new;
		sendsBot1.method();
		Alfred sendBot2 = new MyBusinessClass()::met;
		//sendBot2.method();
		Alfred sendBot3 = MyBusinessClass::met2;
		sendBot3.method();
	}
}
interface Alfred{
	public void method();
}
class MyBusinessClass{
	public MyBusinessClass() {
		System.out.println("Constructor Method Called...");
	}
	public void met(){
		System.out.println("Normal Method Called....");
	}
	public static void met2(){
		System.out.println("Static method called");
	}
}