package Grapes;

public class Thread5Demo {
public static void main(String[] args) {
	Drama melody = new Drama();
	new Thread(()->{
		for(int i = 0;i<5;i++) {
			melody.emotions();
		}
	}).start();
	new Thread(()->{
		for(int i=0;i<5;i++) {
			melody.comedy();
		}
	}).start();
}
}
	 class Drama{
		boolean signal;
		synchronized public void emotions() {
			if(signal){try {wait();}catch(Exception e) {e.printStackTrace();}
			}
			System.out.println("Emotional scene...");
		signal = true;
		notify();
		}
		synchronized public void comedy() {
			while(signal){
				try {wait();}catch (Exception ex) {}
				
			}
			System.out.println("Comedy scene...");
			
		signal = false;
		notify();
	
}
}
