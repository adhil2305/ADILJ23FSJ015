package Calamari;

public class LambdaDemo5 { 
	public static void main(String[] args) {
		//1
		Doctor first=new StanleyMedicalCollege();
		first.doCure();
		
		//2-Non static inner class
		Doctor second=new MGRUniversityCampus().new MGRMedicalCollege();
		second.doCure();
		
		//2b - static inner class
		Doctor third=new MGRUniversityCampus.JanakiMedicalCollege();
		third.doCure();
		
		//3 -Local inner class
		new MGRUniversityCampus().service();
		//5
		Doctor fifth=()->{System.out.println("do cure of lambda impl...");};
		fifth.doCure();
		
		//6
		Doctor sixth=LambdaDemo5::mycure;
		sixth.doCure();
	}
	//static method cure is the method of the main class LambdaDemo5
	// this method should be called statically 
	
	public static void mycure() {
		System.out.println("customized cure logic....");
	}
}
//Functional interfaces - Interfaces with only one method
interface Doctor{
	public void doCure();
}
//how do we provide implementation for this interface
/*
 * Six ways -
 * 1. Through external implementation class
 * 2. Through inner class - Static/Non Static
 * 3. Anonymous inner class
 * 4. Local inner class
 * 5. Lambda
 * 6. Method Referencing
 */
//1
class StanleyMedicalCollege implements Doctor{
	@Override
	public void doCure() {
		System.out.println("docure of stanley called...");
	}
}
//2
class MGRUniversityCampus {
	//2
	class MGRMedicalCollege implements Doctor{
		@Override
		public void doCure() {
			System.out.println("mgr do cure- non static inner...");
		}
	}
	//2
	static class JanakiMedicalCollege implements Doctor{
		@Override
		public void doCure() {
			System.out.println("janaki do cure...static inner...");
		}
	}
	public void service() {
		//3
		class LocalMedicalCollege implements Doctor{
			@Override
			public void doCure() {
				System.out.println("localized medical do cure");
			}
		}
		new LocalMedicalCollege().doCure();
		//4
		new Doctor() {			
			@Override
			public void doCure() {
				System.out.println("do cure of anonymous...");
			}
		}.doCure();
	}
	
}
