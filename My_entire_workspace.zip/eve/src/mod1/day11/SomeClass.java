package mod1.day11;

public class SomeClass {
	JavaDemo1 obj;//complex type
}
