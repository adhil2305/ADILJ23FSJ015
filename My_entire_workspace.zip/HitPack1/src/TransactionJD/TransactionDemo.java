package TransactionJD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class TransactionDemo {
		public static void main(String[] args) throws Exception{
			//Register the Connection
			Class.forName("com.mysql.cj.jdbc.Driver");
			// STEp : 2 Establish the connection
			Connection con = DriverManager.getConnection("jdbc::mysql://localhost/javabatch","root","root");
			con.setAutoCommit(false);
			
			Scanner scan = new Scanner(System.in);
			System.out.println("Please edit the CREDIT name:");
			
			String uname = scan.next();
			System.out.println("Please enter the credit amount:");
			
			int amt = scan.nextInt();
			int currentAmt = 0;
			
			PreparedStatement ps  = con.prepareStatement("select salary from users where username = ?");
			ps.setString(1, uname);		
			ResultSet rs = ps.executeQuery();
		
			if(rs.next()) {
				currentAmt = rs.getInt(1);
				
				
				
				
			}//ending if statment 
			ps = con.prepareStatement("update users set salary = ? where username = ?");
			ps.setInt(1, amt+ currentAmt);
			ps.setString(2, uname);
			ps.executeUpdate();
			
			System.out.println("Please enter Debit name");
			
			uname = scan.next();
			
			ps = con.prepareStatement("select salary from users where uname =? ");
			ps.setString(1, uname);
			
			rs = ps.executeQuery();
			
			if(rs.next()) {
				currentAmt = rs.getInt(1);
			}//close the if statement
			else {
				con.rollback();
			}//closing else statement 
			ps = con.prepareStatement("update users set salary = ? where username = ?");
			ps.setInt(1, currentAmt - amt);
			ps.setString(2,  uname);
			ps.executeUpdate();
			con.commit();
			
			
			
			
		}
}
