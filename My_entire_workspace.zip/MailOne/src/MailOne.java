import javaio.fieldputStream;
import java.util.HashMap;
import java.util.iterator;
import java.util.Map;
import java.util.set;
import java.util.Properties;
public class MailOne {
public static void main(String[] args) throws Exception{
	
}
}
