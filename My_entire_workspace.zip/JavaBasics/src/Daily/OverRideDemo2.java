package Daily;

/*
 * 1. variables cannot be overriden
 * 2. visibility cannot be reduced
 * 3. super keyword can be used to access the immediate super class
 * 4. In abscence of the method or variabe in immediate super class, java will search
 * the remaining heirarchy until it finds out.
 * 5. final methods cannot be overriden (final is a keyword - represents a constant)
 * 6. static methods cannot be overriden
 */
public class OverRideDemo2 {
	public static void main(String[] args) {
		Employee obj=new JuniorEngineer();
		obj.work();
		System.out.println(obj.i);
	}
}
//public - protected - nomod - private
class Employee{
	int i=100;
	void work() {//VISIBILITY CANNNOT BE DECREASED BUT CAN BE INCREASED
		System.out.println("work method of super class called....");
	}
}
class EngineerEmployee extends Employee{
	int i=200;
	 public void work() {
		System.out.println("work method of sub class.....");
		/*
		 * super.work();
		 */	}
}
class JuniorEngineer extends EngineerEmployee{
	int i=300;
	public void work() {
		System.out.println("juniorengineer work called...");
		super.work();
	}
}
