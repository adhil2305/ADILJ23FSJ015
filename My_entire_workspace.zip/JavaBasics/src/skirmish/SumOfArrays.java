package skirmish;

public class SumOfArrays {
	public static void main(String[] args) {
		int[] arr = {11,43,15,2,67,3};
		int sum = 0;
		//Advanced for loop
		for(int num : arr) {
			sum = sum+num;
			
		}
		System.out.println("The sum of array elements is "+sum);
	 }
	

}
