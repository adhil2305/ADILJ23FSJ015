package Garbage;

import java.awt.event.ActionListener;


import java.awt.*;


import java.awt.event.*;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class Niomi extends JFrame implements ActionListener {
		
	JEditorPane ep;
	JTextArea ta;
	JButton btn;
	JScrollPane pane1,pane2;

	public Niomi()
	{
		Container c=getContentPane();
		c.setLayout(new FlowLayout());
		ep=new JEditorPane("text/html","<h1>HTMl Here</h1>");
		ta=new JTextArea("Enter HTML here",10,50);
		pane1=new JScrollPane(ta);
		pane2=new JScrollPane(ep);
		pane2.setPreferredSize(new Dimension(550,180));
		btn=new JButton("Click");
		c.add(pane1);
		c.add(btn);
		c.add(pane2);
		btn.addActionListener(this);
	}
	
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==btn)
		{
			ep.setText(ta.getText());
		}
	}
	public static void main(String[] args) {
		Niomi browser=new Niomi();
		browser.setTitle("browser Example");
		browser.pack();
		browser.setVisible(true);
	}
	
	
}
