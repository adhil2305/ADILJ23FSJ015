import java.util.Locale;
import java.util.ResouceBundle;
import java.util.ResourceBundle;
import java.io.FileOutputStream;

public class ResourceDemo1{
	public static void main(String[] args) throws Exception {
		Locale locale= Locale.getDefault();
		System.out.println(Locale);
		//Locale.setDefault(new Locale("hi"));
		System.out.println(Locale.getDefault());
//ResourceBundle rb=ResourceBundle.getBundle("mydictionary",Locale.getDefault());	}
ResouceBundle rv=ResourceBundle.getBundle("mydictionary",new Locale("ta"));
System.out.println(rb.getStrin("Hello"));
ResourceBundle rb2 = ResourceBundle.getBundle("Dictiionary",new Locale("ta"));
new OutputStream("temp.html").writerb2.getString("hello").getBytes());;
System.out.println(rb2.getString("Hello")
		;
	}