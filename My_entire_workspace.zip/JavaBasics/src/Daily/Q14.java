package Daily;

/**This program tests java documentation nothing else
*
*I tried runing the questions a b and c doesnot work at all
*/

public class Q14{
   public static void main(String[] args){
       System.out.print("Javadoc");

       int arr[][] = {{2,5,1},
    		        {6,3,5}};
   System.out.println(arr.length[]);
   }
}