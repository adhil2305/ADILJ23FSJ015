package eve;

public class HelloWorld2 {
	public static void main(String[] args) {
		//i want to give a text input but in static fashion
		String myname="shoiab";//= (equalto) is a assignment operator
		System.out.println("Welcome To JAVA...:"+myname);//+ is a concatenation operator
		
		int n1=10;
		int n2=20;
		System.out.println("The sum of two values...:"+(n1+n2));
	}
}
