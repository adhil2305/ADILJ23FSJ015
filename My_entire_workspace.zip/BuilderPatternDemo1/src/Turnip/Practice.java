package Turnip;


public class Practice {
	public static void main(String[] args) {
		Computer myComputer = new Computer.BuildComputer().buildCabinet("Zebronics").buildStorage("DDR 4").buildMotherBoard("Intel inside mental outside").build();
		System.out.println(myComputer);
	}
}

class Computer{
	private String str[];
	public Computer(String ...s) {
		this.str =s;
	}

static class BuildComputer{
	String storageWare;
	String cabinet;
	String motherBoard;
	
	public BuildComputer buildMotherBoard(String motherBoard) {
		this.motherBoard = motherBoard;
		return this;
	}
	public BuildComputer buildStorage(String storageWare) {
		this.storageWare = storageWare;
		return this;
	}
	public BuildComputer buildCabinet(String cabinet) {
		this.cabinet = cabinet;
		return this;
	}
	public Computer build() {
		return new Computer(this.cabinet, this.motherBoard, this.storageWare);
	}
}
@Override
public String toString() {
	// TODO Auto-generated method stub
	String computer = "The Computer is ";
	for(String details : str) {
		computer = computer + " : " + details;
	}
	return computer;
}
}