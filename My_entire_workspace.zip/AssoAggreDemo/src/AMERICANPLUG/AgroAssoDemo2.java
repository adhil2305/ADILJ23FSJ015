package AMERICANPLUG;


public class AgroAssoDemo2 {public static void main(String[] args) {
	IndianPlug anand = new IndianPlug();
	IndianSocket sangeetha = new IndianSocket();
	sangeetha.roundPin(anand);
	
	AmericanPlug dell = new AmericanPlug();
	IndianAdapter ia = new IndianAdapter();
	ia.set(dell);
	sangeetha.roundPin(ia);
	
}
}

class IndianPlug{
public void execute() {
System.out.println("Indian plug is working");
}
}

class IndianSocket{
public void roundPin(IndianPlug ip) {
//Indian Plug is a  part of the indian socket
ip.execute();
}
}

class AmericanPlug{
public void execute() {
	System.out.println("American Plug is working");
	}
}
class IndianAdapter extends IndianPlug{ // Indian adapter is a kind of indian product

	// But has the knowledge of the american plug
	AmericanPlug ap; 
	// The Indian plug must have the knowledge of the American plug 
	// to work on it 
	public void set(AmericanPlug ap) { 
	// If the user asks to set the logic to the American adapter
	// The knowledge of the American Adapter is fed into the 
	// method and it is set to the current object
	// Now is set the american plug parameters to the indian adapter so that it could be able to access the indian plug properties
this.ap = ap;
System.out.println(this);

}
@Override
public void execute() {
	ap.execute();

	}
}