package eve;
//this program is for printing hello world - single line comment
/*
 this is a multiple line comment section
 hello
 hai
 author M.H. Shoiab
 Date of program - 12/8/2021
*/


public class HelloWorld {
public static void main(String[] args) {
	System.out.println("Welcome to JAVA....");
}
}
