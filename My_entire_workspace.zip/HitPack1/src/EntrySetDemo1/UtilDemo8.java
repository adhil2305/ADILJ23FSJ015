package EntrySetDemo1;

public class UtilDemo8 {


	
	
	
	import java.util.HashMap;
	import java.util.Iterator;
	import java.util.Map;
	import java.util.Set;
	import java.util.TreeMap;
	public class UtilDemo5 {
		public static void main(String[] args) {
			Map<String, String> mymap=new TreeMap<String, String>((o1,o2)->{return o2.compareTo(o1);});
			
			mymap.put("a2", "akhil");
			mymap.put("a3", "babu");
			mymap.put("a1", "mohan");
			mymap.put("a4", "sohan");
			
			System.out.println(mymap);
			
			System.out.println(mymap.get("a1"));
			
			Set<Map.Entry<String, String>> myset= mymap.entrySet();
			
			Iterator<Map.Entry<String,String>> iter=myset.iterator();
			
			while(iter.hasNext()) {
				Map.Entry<String,String> me=iter.next();
				System.out.println(me.getKey()+":"+me.getValue());
			}
			
		}
	}


	