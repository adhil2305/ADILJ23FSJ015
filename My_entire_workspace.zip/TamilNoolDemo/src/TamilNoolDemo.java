public class TamilNoolDemo {
public static void main(String[] args) {
	System.out.println("First line...");
	System.out.println("second Line..");
	new Thread(()->{new TamilNoolDemo().met();}).start(); 
	
	//new Thread(new MyRunnable()).start();
	
	System.out.println("Fourth line...");
}
public void met() {
	try {Thread.sleep(4000);}catch (Exception e) {e.printStackTrace();}
	System.out.println("Third line...");
}
}
class MyRunnable implements Runnable {
	 @Override
	public void run(){
		new TamilNoolDemo().met();
	
	}
}