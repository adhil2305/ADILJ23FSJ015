package edu.disease.asn3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Objects;

public class DiseaseAndPatient {
	public static void main(String[] args) {
		Patient p1 = new Patient();
		Disease d1 = new InfectiousDisease();
		Disease[] diseases = new Disease[1];
		Patient [] patients = new  Patient[1];
		patients[0] = p1;
		diseases[0] = d1;
		DiseaseAndPatient dp = new DiseaseAndPatient(diseases, patients);
		dp.setFolderPath("F:/cat");
		dp.save(diseases, patients);
		dp.init("F:/cat");
		
	}
	private Disease[] diseases;
	private Patient[] patients;
	private String folderpath;
	
	/*
	 * This method sets the folder to the current object
	 */
	public void setFolderPath(String folderpath) {
		this.folderpath = folderpath;
	}
	public String getFolderPath() {
		return this.folderpath;
	}
	
	/*
	 * Constructor
	 */
	public DiseaseAndPatient(Disease[] diseases, Patient[] patients) {
		// TODO Auto-generated constructor stub
		this.diseases =  diseases;
		this.patients = patients;
	}
	
	public DiseaseAndPatient() {
		
	}
	
	/*
	 * This sets the diseasesto the current diseases you just entered 
	 */
	public Disease[] getDiseases() {
		return this.diseases;
	}
	/*
	 * This the diseases you just entered
	 */
	public void setDiseases(Disease[] diseases) {
		this.diseases = diseases;
	}
	/*
	 * This sets the patient you enter into the current object
	 */
	public void setPatient(Patient[] patients) {
		this.patients=  patients;
	}
	/*
	 * This returns a patient
	 */
	public Patient[] getPatients() {
		return patients;
	}
	/*
	 * save method that has two parameters diseases and patients it accepts diseasaes and patients 
	 */
	
	public void save(Disease[] diseases, Patient[] patients) {
		this.diseases = diseases;
		this.patients = patients;
		String  diseasesPath = folderpath + File.separator + "diseases.dat";
		String patientsPath = folderpath + File.separator + "patients.dat";
		try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(diseasesPath));) {
            // Serialize the object
            oos.writeObject(diseases);
            System.out.println("Serialization successful");
            oos.close();
		 } catch (IOException e) {
	            e.printStackTrace();
	        }
		
		
		try (ObjectOutputStream oos1 = new ObjectOutputStream(new FileOutputStream(patientsPath));) {
            // Serialize the object
            oos1.writeObject(patients);
            System.out.println("Serialization successful");
            oos1.close();
		 } catch (IOException e) {
	            e.printStackTrace();
	        }
		
	
		
	}
	
	public DiseaseAndPatient init(String folderpath){
		this.folderpath = folderpath;
		//Folder path string 
		
		  Disease[] deserializedDiseases1 = null;
		    Patient[] deserializedPatients1 = null;
		    	
			String  diseasesPath = folderpath + File.separator + "diseases.dat";
			String patientsPath = folderpath + File.separator + "patients.dat";
		
		Path path1 = Paths.get(folderpath);
		 if (Files.exists(path1) && Files.isDirectory(path1) && folderpath != null ) {
			
			 
			 try(
			            ObjectInputStream ois1 = new ObjectInputStream(new FileInputStream(diseasesPath));
				     ObjectInputStream ois = new ObjectInputStream(new FileInputStream(patientsPath));
					 ){
				 deserializedDiseases1 =  (Disease[])ois1.readObject();
			     deserializedPatients1 =  (Patient[])ois.readObject();
			          
			          
			        } catch (Exception ex) {
			        	
			            ex.printStackTrace();
			            
			        }
	           DiseaseAndPatient dptester = new DiseaseAndPatient(deserializedDiseases1, deserializedPatients1);
		       System.out.println(dptester);
	            return dptester;
	            		}else {
	        	
	        	throw new IllegalArgumentException("The specified folderpath doesnot exist");
	        	
	        }
	}
	
	
	
}
