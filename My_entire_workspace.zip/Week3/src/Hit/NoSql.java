package Hit;
import java.util.Scanner;

public class NoSql {
	public static void main(String[] args) {
		
	}
}



