package Pack_One;

import java.sql.Connection;
import java.sql.DriverManager;

public class Efforts_learn {
		public static void main(String[] args) {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3307:javabatch","root","root");
			con.setAutoCommit(false);
			try {
				String username = "Somu";
				String drname = "Mohan";
				int amount = 500;
				int amt = 0;
			
			
			
		}
}
