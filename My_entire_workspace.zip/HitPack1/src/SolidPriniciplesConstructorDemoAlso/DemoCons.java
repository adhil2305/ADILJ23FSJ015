package SolidPriniciplesConstructorDemoAlso;

public class DemoCons {

	
	
	
	
	package Natchos;

import Natchos.MySeniorSuper;
import Natchos.MySub;
import Natchos.MySuper;

public class ConsDemonstration {
		public static void main(String[] args) {
			MySeniorSuper sup = new MySub();
			sup.met();
			System.out.println(sup.isuper);
			// s - solid responsibitliy 
			// o - open close principle 
			//liscow substitution principle the child can replace the parent
			//code 
			//compostion 
			//object re usability
			
			
			//
			//dependency inversion priciple 
		
		}
	}

	class MySeniorSuper{
		int isuper = 100;
		public MySeniorSuper(int i) {
			//TODO auto generated constructor 
		}
		protected void met() {
			System.out.println("met of super called ...");
		}
	}

	class MySuper extends MySeniorSuper{
		int isuper= 200;
		public MySuper(String s) {
			super(100);
			System.out.println("Constructor of MySenior called ...");
			//ToDO auto generated constructor
			
		}
		public void met() {
			System.out.println(" Met of the sub senior called... ");
			//super.met();
		}
	}

	class MySub extends MySuper{
		public MySub(String s) {
			super("blabla");
			System.out.println("sub .. :"+s);
		}
		int isuper = 300;
		public void met() {
			System.out.println("met of sub.."+isuper);
			//super.met();
		}
	}


}