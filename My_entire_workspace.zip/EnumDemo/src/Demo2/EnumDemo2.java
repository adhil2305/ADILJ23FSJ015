package Demo2;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

public class EnumDemo2 {
		public static void main(String[] args) {
			Vector<String> mylist=new Vector<String>();
			mylist.add("aaa");
			mylist.add("bbb");
			mylist.add("ccc");
			
			Iterator<String> iter=mylist.iterator();
			
			//mylist.add("ddd");
			
			while(iter.hasNext()) {
				System.out.println(iter.next());
			}
			
			Enumeration<String> en=mylist.elements();
			mylist.add("dddd");
			while(en.hasMoreElements()) {
				System.out.println(en.nextElement());
			}
		}
	}