package Chrome;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.Charset;

public class UrlConnection {
	public static void main(String[] args) throws Exception {
		URL url=new URL("https://www.google.com/index.html");
		
		
		URLConnection urlCon = url.openConnection();
	
		InputStream is = urlCon.getInputStream();
		BufferedReader bi = new BufferedReader(new InputStreamReader(is));
		
		FileOutputStream fos = new FileOutputStream("google.html");
		FileWriter fow = new FileWriter("google2.html", Charset.forName("UTF-8"));
		
		int x = 0;
	//	byte[] b = new byte[256];
		char c[] = new char[256];
		while((x=bi.read(c))!=-1) {
			String s = new String(c,0,x);
			System.out.println(s+"\n");
			fow.write(s);
			
		}
		                          
		/*
		 * This is another way to get the connection and read it
		 *Please read all the file 
		 */
		
		URL url1 = new URL("https://www.google.com/index.html");
		
		URLConnection urlcon1 = url1.openConnection();
		
		InputStream is1 = urlcon1.getInputStream();
		FileOutputStream fos1 = new FileOutputStream("google.html");
		
		int x1 = 0;
		byte b[] = new byte[256];
		while((x = is.read(b)) != -1) {
			String s = new String(b,0,x1);
			System.out.println(s);
			fos1.write(b,0,x1);
			
		}
		
		
		
	}
}
