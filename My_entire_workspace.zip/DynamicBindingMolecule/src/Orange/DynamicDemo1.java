package Orange;

public class DynamicDemo1 {
		public static void main(String[] args) {
			AllopathyMedicalCollege Stanley = new AllopathyMedicalCollege();
			
			Object shoaib = new Human();
			
			AyurvedCollege ayush = new AyurvedCollege();
			
			//Today checking time 3/12/2023 time 1:03 AM
			
			Object doctor1 = (Doctor)shoaib;
			if(shoaib instanceof Doctor) {
				System.out.println("Shoaib is a doctor");
			}
			else {
				System.out.println("Shoaib is not a Doctor");
			}
			//Doctor doctor = Doctor(shoaib);
			System.out.println("Shoaib goes to Medical College");
			//Subjection of behaviorial object into implementation
		//	MoleculeFramework.setinterface(Doctor.class);
			
		}
}

interface Doctor{
	public void sevenYearsProgram();
}
class Object{}
class Human extends Object{}
class AllopathyMedicalCollege implements Doctor {
		Object o;
		public void sevenYearsProgram(Object o) {
			this.o = (Doctor)o;
		}
}
class AyurvedCollege{}