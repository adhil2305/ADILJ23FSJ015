package Chrome;

public class BufferDemo3 {

	
	
	import java.io.BufferedInputStream;
	import java.io.ByteArrayInputStream;
	import java.io.StringBufferInputStream;
	public class BufferDemo {
		public static void main(String[] args)throws Exception {
			String str="jack and jill &copy; went up the &copy hill to fetch water......";
			
			//StringBufferInputStream sbis=new StringBufferInputStream(str);
			
			ByteArrayInputStream bytearray=new ByteArrayInputStream(str.getBytes());
			
			BufferedInputStream bis = new BufferedInputStream(bytearray);
			
			int x=0;boolean marked=false;
			while((x=bis.read())!=-1) {
				char c=(char)x;
				
				switch(c){
				case '&':{
					bis.mark(50);
					marked=true;
					break;
				}
				case ';':{
					if(marked) {
						System.out.print((char)169);
						marked=false;
						System.out.print(" ");
					}
					else {
						System.out.print(c);
					}
					break;
				}
				case ' ':{
					if(marked) {
						bis.reset();
						System.out.print("&");
						marked=false;
					}else {
						System.out.print(c);
					}
					break;
				}
				default:{
					if(!marked) {
						System.out.print(c);
					}
				}
				}
			}
			
		}
	}
	google.comgoogle.com
	Seasonal Holidays 2023
	Happy Holidays! #GoogleDoodle (354 kB)

}