
public class InterfaceDemo5 {
	public static void main(String[] args) {
		//Cola colaMaker = new CampaCola();
		KaliMark kali = new KaliMark();
		//Cola colaMaker = new KaliMark().new CampaCola();
		//Cola colaMaker = kali.new CampaCola();
		
		kali.sellCola(null);
		
		//Pepsi pepsico = new Pepsi();
		//pepsico.sellCola();
		
	}
}
interface Cola{
	public void makeCola();
}

class Pepsi{
	public void sellCola(Cola makerAddress) {
		makerAddress.makeCola();
		System.out.println("fill cola in pepsi bottle and sell cola .....");
		
	}
}
class KaliMark{
//class CampaCola implements Cola{
//@Override
//	public void makeCola() {
//	System.out.println("Campa Cola creates cola...");
//	
//}
//}
	public void sellCola(Cola colaMaker) {
	new Cola() {
			@Override 
			public void makeCola() {
				System.out.println("Anonymous way of selling cola using campa cola ....");
			}
		}.makeCola();
		System.out.println("Fills COla in bottle and sells it .... ");
	}
}