package oreo;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.DriverManager;


public class JdbcDemo2 {
public static void main(String[] args) {
	
	//Step1 - Register or load the driver
	
	Class.forName(com.mysql.cj.jdbc.Driver);
	
	//Establish connection
	
	Connection con = DriverManager.getConnection(null)jdbc:mysql://localhost/eve","root","root");
		
		//Process the result
		
		System.out.println(con);
	
	
}
}
