package Demo1;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
/*
 * delimiter //
 * create procedure myproc()
 * begin
 * insert into users values (300,'somu','secret',4000,0);
 * insert into users values (400,'saravanan','secret',7500,0);
 * update users set flag=1;
 * end;
 * //
 * delimiter ;
 */
public class JDBCDemo4 {
	public static void main(String[] args) throws Exception{
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost/javabatch","root","root");
		
		CallableStatement cs=con.prepareCall("{call myproc()}");
		
		cs.execute();
		
	}
}
package jdbcproj;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
/*
 * mysql> create procedure myproc2(IN myflag INT)
    -> begin
    -> update users set flag=myflag;
    -> end;
    -> //
Query OK, 0 rows affected (0.01 sec)
mysql> delimiter ;
 */
/*
 * mysql> create procedure myproc3(IN uid INT,IN uname varchar(40),IN upass varchar(8),IN sal INT,IN myflag INT)
    -> begin
    -> insert into users values (uid,uname,upass,sal,myflag);
    -> end;
    -> //
Query OK, 0 rows affected (0.02 sec)
mysql> delimiter ;
mysql>
 */
public class JDBCDemo5 {
	public static void main(String[] args) throws Exception{
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost/javabatch","root","root");
		
		CallableStatement cs=con.prepareCall("{call myproc2(?)}");
		
		cs.setInt(1, 0);
		
		cs.execute();
		
		cs=con.prepareCall("{call myproc3(?,?,?,?,?)}");
		cs.setInt(1, 500);
		cs.setString(2, "sami");
		cs.setString(3, "secret");
		cs.setInt(4, 5000);
		cs.setInt(5, 1);
		
		cs.execute();
	}
}
package jdbcproj;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Types;
/*
 * mysql> create procedure myproc4(OUT noofrows INT)
    -> begin
    -> select count(*) from users into noofrows;
    -> end;
    -> //
Query OK, 0 rows affected (0.01 sec)
mysql>
 */
public class JDBCDemo6 {
	public static void main(String[] args) throws Exception{
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost/javabatch","root","root");
		
		CallableStatement cs=con.prepareCall("{call myproc4(?)}");
		
		cs.registerOutParameter(1, Types.INTEGER);
		
		cs.execute();
		
		int rowcount=cs.getInt(1);
		System.out.println("No of rows in users table is...:"+rowcount);
		
	}
}


//________________________________________________________________________________________________________________________

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;
public class JDBCDemo3 {
	public static void main(String[] args) throws Exception{
		//STEP 1 - registering the driver
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		//STEP 2 - Establish the connection
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost/javabatch","root","root");
		String sql="select * from users where userid=?";//dynamic query
		PreparedStatement stmt=con.prepareStatement(sql);
		
		while(true) {
			Scanner scan=new Scanner(System.in);
			System.out.println("\nPlease enter userid..:");
			int uid=scan.nextInt();
			
			//String sql="select * from users where userid="+userid;//this concatenation is bad
			//this will create sql injection problem - not recommended...its a security problem
			
			//Statement stmt=con.createStatement();
			stmt.setInt(1, uid);
			ResultSet rs=stmt.executeQuery();
			while(rs.next()) {
				System.out.printf("The salary of %s is %d",rs.getString("username"),rs.getInt("salary"));
			}
		}
		
	}
}





