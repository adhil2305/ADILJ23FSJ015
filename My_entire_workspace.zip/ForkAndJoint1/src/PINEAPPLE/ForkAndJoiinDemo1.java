package PINEAPPLE;

import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;

import java.util.concurrent.ForkJoinPool.ForkJoinWorkerThreadFactory;
import java.util.concurrent.ForkJoinTask;
import java.util.concurrent.RecursiveTask;

public class ForkAndJoiinDemo1 {
		public static void main(String[] args) {
			String str[] = {"Chennai", "Chennai", "chennai", "Chennai", "Chennai", "Chennai", "Chennai"};
			double l1 = System.currentTimeMillis();
			int count = 0;
			for(int i=0;i<str.length;i++) {
				if(str[i].equals("Chennai")) {
					++count;
				}
			}
			double l2 = System.currentTimeMillis();
			System.out.println((l2-l1));
			System.out.println("Chennai come "+count+" times");
		
		ForkJoinPool forkjoin = ForkJoinPool.commonPool();
		
		double t1  = System.currentTimeMillis();
		
		int c1 = forkjoin.invoke(new MyTask(str,0,3));
		int c2 = forkjoin.invoke(new MyTask(str,3, 5));
		int c3 = forkjoin.invoke(new MyTask(str,5,7));
		int total = c1+c2+c3;
		
		double t2 = System.currentTimeMillis();
		System.out.println((t2-t1));
		
		System.out.println("Using fork and join Chennai comes "+total+ " times");
		
		}
}


class MyTask extends RecursiveTask<Integer> {
	String arr[]; int start, end;
	public MyTask(String s[], int start, int end) {
		this.arr =s;this.start=start;this.end = end;
		
	}
	@Override
	protected Integer compute() {
		int count=0;
		for(int i=start;i<end;i++) {
			if(arr[i].equals("Chennai")) {
				++count;
			}
		}
	return count;
	}
}