package ReversingStringOfWords;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import com.sun.org.apache.bcel.internal.generic.L2D;

import LargestNumberCandy.Solution;

public class Solution1 {
	public static void main(String[] args) {
		//List<String> l2 = new Solution1().reverseString("Hello    World");
		//System.out.println(l2);
		Solution1 sol = new Solution1();
		System.out.print(sol.solution2("      never say   we lose"));
		//System.out.println(l2.get(3).isEmpty());
		int a = 113%6; // Modulus returns the remainder
		System.out.println(a);
		System.out.println();
	 

	
	}
	public String reverseString(String s) {
		char arr1[]=  new char[s.length()];
		StringBuilder str1 = new StringBuilder(s);
		for(int i = 0;i<s.length();i++) {
			arr1[i] = s.charAt(i);
		}
		System.out.println("The array");
		System.out.println(arr1);

		return  Arrays.asList(s.split(" ")).stream().filter(e -> !e.equals("")).collect(Collectors.joining(" "));
		   	
	}
	public String solution2(String s) {
		//TRIM - in is the command that trims off the 
		//spaces at the front and the back
		
		//The split command splits the Stringg
		// according to the char we give
		
		// \\s splits the spaces and returns an array
		// \\s+ splits the white apace or a sequesnce of white spaces
		
		String s12[] = s.trim().split("\\s+");
		String sally[] = s.split("\\s+");
		System.out.println(sally);
		String out = "";
		// Traverse the through the string in the reverse order
		
		
		for(int i= s12.length-1 ; i>=0;--i) {
			out += s12[i] + " ";
		}
		//The final answer is printed here	
		return out ;
	}
}
