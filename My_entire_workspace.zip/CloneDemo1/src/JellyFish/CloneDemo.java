package JellyFish;

public class CloneDemo {
  public static void main(String[] args) {

			//Scenario 1 - multiton - properties are unique resource is also unique
			//every person has separate resource and separate properties  
			Sheep mothersheep=new Sheep();
			
			Sheep dolly=new Sheep();
			
			mothersheep.name="iam the mother sheep..";
			dolly.name="I am the clone dolly..";
			
			System.out.println(mothersheep.name);
			System.out.println(dolly.name);
			
			//Scenario 2 - singleton - Properties are shared and resources also shared..
			
			System.out.println();
			System.out.println("Scenario 2");
					Sheep mothersheep2=new Sheep();
					
					Sheep dolly2=mothersheep2;
					
					mothersheep2.name="iam the mother sheep..";
					dolly2.name="I am the clone dolly..";
					
					System.out.println(mothersheep2.name);
					System.out.println(dolly2.name);
					
				//Scenario 3 - cloning - Properties are unique and resources are shared..
				
				Sheep mothersheep3=new Sheep();
				
				Sheep dolly3=mothersheep3.createClone();
				
				mothersheep3.name="iam the mother sheep..";
				dolly3.name="I am the clone dolly..";
				
				System.out.println(mothersheep3.name);
				System.out.println(dolly3.name);
		}
	}
	class Sheep implements Cloneable{
		String name = "dolly";//property
		
		public Sheep() {
			System.out.println("sheep object created...");
		}
		
		public Sheep createClone() {
			try {
				return (Sheep)clone();
			}catch(Exception e) {
				e.printStackTrace();
				return null;
			}
		}
		}
	
	
	
	
	
	

