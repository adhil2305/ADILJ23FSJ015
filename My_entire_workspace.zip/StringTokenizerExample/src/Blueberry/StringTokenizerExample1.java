package Blueberry;
import java.util.StringTokenizer;
public class StringTokenizerExample1 {
public static void main(String[] args) {
	StringTokenizer st = new StringTokenizer("My name is Adil" );
	while(st.hasMoreTokens()) {
		System.out.println(st.nextToken(" "));
		
	}
	st = new StringTokenizer("My,name,is,Adil");
	System.out.println("Next token is "+st.nextToken(","));
	String ar[] =new String[4];
	ar[1]= st.nextToken(",");
	System.out.println(ar[1]);
}
}
