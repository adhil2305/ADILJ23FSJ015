package Apple;


SHOIAB-GOLDEN TOUCH - HAARISINFOTECH
  2:34 AM
package basics;
public class FunctionalInterDemo {
	public static void main(String[] args) {
		//CampaCola cc=new Bovonto().new CampaColaImpl();//access inner class
		//CampaCola cc=new Bovonto.CampaColaImpl();//access static inner class
		Bovonto bovonto=new Bovonto();
		PepsiCo pepsi=new PepsiCo();
		
		bovonto.sellCola(null);
		pepsi.sellCola(null);
	}
}
interface CampaCola{
	public void makeCola();
}
class Bovonto {
	public void sellCola(CampaCola cc) {
		//anonymous inner class
		new CampaCola() {			
			@Override
			public void makeCola() {
				System.out.println("cola made as per campa cola logic.using anonymous..");		
			}
		}.makeCola();
		
		//Lambda
		CampaCola ccc=()->{System.out.println("cola made as per campa cola logic.using lambda..");};
		ccc.makeCola();
		//Method Referencing
		CampaCola cm=Bovonto::makeColaLogicCopies;
		cm.makeCola();
		System.out.println("fill in bovonto bottle and sell cola...");
	}
	public static void makeColaLogicCopies() {
		System.out.println("cola logic copied and made cola...method referencing");
	}
//	static class CampaColaImpl implements CampaCola{//acquisition
//		@Override
//		public void makeCola() {
//			System.out.println("campa cola creates cola....");
//		}
//	}
}
class PepsiCo{
	public void sellCola(CampaCola cc) {
		cc.makeCola();
		System.out.println("fill in pepsi bottle and sell cola..");
	}
	
	
-----------------------------------------------------------------------------------------------
--------------------------------------------------


package basics;
public class InterDemo1 {
	public static void main(String[] args) {
		System.out.println(Doctor.value);
		Doctor.meeeeee();
	}
}
//Interface objects cannot be created...
interface Doctor{
	final static String value="curing....";
	public void met();
	//jdk8 and above
	private void meet() {
		
	}
	default void meeeet() {
		
	}
	public static void meeeeee() {
		System.out.println("static method called.....");
	}
}
interface Surgeon extends Doctor{
	
}


________________________________________________________________________________________________
________________________________________________________________________________________________



1:44
package realinterfaceimplpack3;
import java.lang.reflect.Proxy;
interface A{}
public class Demo {
	//private static Class c[]={Doctor.class,Pilot.class,Steward.class};
	public static void main(String[] args) {
		AlopathyMedicalCollege stanelyMC=new AlopathyMedicalCollege();	//1953
		
		Object shoiab=new Human(); //1974
		
		AyurvedCollege ayush=new AyurvedCollege();//2018
		
		//today checking - 03/12/2023 Time: 1:09 AM
		if(shoiab instanceof Doctor){
			System.out.println("shoiab is a doctor...");
		}else{
			System.out.println("shoiab is not a doctor");
		}
//		Doctor doctor=(Doctor)shoiab;
		System.out.println("shoiab goes to medical college.....");
//		//subjection of behavioural object into implemenation
		
		MoleculeFramework.setInterface(Doctor.class);
		shoiab=MoleculeFramework.getObject(new Object[]{shoiab,stanelyMC});//dynamic binding
		
		if(shoiab instanceof Doctor){
			System.out.println("shoiab is now a doctor after mixing");
		}
		Doctor doctorshoiab=(Doctor)shoiab;
		doctorshoiab.doCure();
		
				JetAirAcademy ja=new JetAirAcademy();
		
		MoleculeFramework.setInterface(Pilot.class);
		MoleculeFramework.setInterface(Steward.class);
	shoiab=MoleculeFramework.getObject
		(new Object[]{shoiab,ja});//dynamic binding with pilot
		
		Pilot pilot=(Pilot)shoiab;
		pilot.doFly();
		doctorshoiab=(Doctor)shoiab;
		doctorshoiab.doCure();
		
	}
}


------------------------------------------------------------
------------------------------------------------------------


1:44
package realinterfaceimplpack3;
import java.lang.reflect.Proxy;
interface A{}
public class Demo {
	//private static Class c[]={Doctor.class,Pilot.class,Steward.class};
	public static void main(String[] args) {
		AlopathyMedicalCollege stanelyMC=new AlopathyMedicalCollege();	//1953
		
		Object shoiab=new Human(); //1974
		
		AyurvedCollege ayush=new AyurvedCollege();//2018
		
		//today checking - 03/12/2023 Time: 1:09 AM
		if(shoiab instanceof Doctor){
			System.out.println("shoiab is a doctor...");
		}else{
			System.out.println("shoiab is not a doctor");
		}
//		Doctor doctor=(Doctor)shoiab;
		System.out.println("shoiab goes to medical college.....");
//		//subjection of behavioural object into implemenation
		
		MoleculeFramework.setInterface(Doctor.class);
		shoiab=MoleculeFramework.getObject(new Object[]{shoiab,stanelyMC});//dynamic binding
		
		if(shoiab instanceof Doctor){
			System.out.println("shoiab is now a doctor after mixing");
		}
		Doctor doctorshoiab=(Doctor)shoiab;
		doctorshoiab.doCure();
		
				JetAirAcademy ja=new JetAirAcademy();
		
		MoleculeFramework.setInterface(Pilot.class);
		MoleculeFramework.setInterface(Steward.class);
	shoiab=MoleculeFramework.getObject
		(new Object[]{shoiab,ja});//dynamic binding with pilot
		
		Pilot pilot=(Pilot)shoiab;
		pilot.doFly();
		doctorshoiab=(Doctor)shoiab;
		doctorshoiab.doCure();
		
	}
}


____________________________________________________________
____________________________________________________________



public class AbstractDemo2 {
	public static void main(String[] args) {
		FriedChicken chicken=new KFC();
		
		chicken.doKFCBusiness();
	}
}
//IIT is creating
interface FriedChicken{
	private void engineeredChicken() {
		System.out.println("chicked is breeded as per the research...");
	}
	private void engineeredMasala() {
		System.out.println("masala is created as per the research");
	}
	private void cookChicken() {
		System.out.println("chicken is cooked as per the research...");
	}
	private void makingProcess() {//template method
		engineeredChicken();
		cookChicken();
		engineeredMasala();
	}
	
	private void shopDesign() {
		System.out.println("shop design as per research...");
	}
	private void sellStrategy() {
		System.out.println("sell chicken as per research...");
	}
	default public void doKFCBusiness() {//template method
		shopDesign();
		makingProcess();
		sellStrategy();
		collectMoney();
		deliverItems();
	}
	public void collectMoney();
	public void deliverItems();
	
}
class KFC implements FriedChicken{
@Override
	public void collectMoney() {
		System.out.println("collect money as KFC standards...");
	}
@Override
	public void deliverItems() {
		System.out.println("deliver chicken as per franchisee standards....");		
	}
}