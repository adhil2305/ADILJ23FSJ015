
public class ThreadDemo2 {
	public static void main(String[] args) {
		Thread t = new Thread(new job());
		t.start();
	
	}

}
class job implements Runnable {
	
	@Override
	public void run {
	System.out.println("Thread logic...");
	try {
	
		
	}catch(exception e)
	}
}
