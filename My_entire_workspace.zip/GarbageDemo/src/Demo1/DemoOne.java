package Demo1;
import java.lang.ref.SoftReference;
import java.lang.ref.WeakReference;

public class DemoOne {

	
		public static void main(String[] args) {
			Runtime runtime=Runtime.getRuntime();
			
			System.out.println("Before Tathas birth..:"+runtime.freeMemory());
			GrandFather tatha=new GrandFather();
			System.out.println("After tathas birth....:"+runtime.freeMemory());
			
			//SoftReference<GrandFather> soft=new SoftReference<GrandFather>(tatha);
			WeakReference<GrandFather> weak=new WeakReference<GrandFather>(tatha);
			
			System.out.println("now tatha goes for pilgrimage.....");
			tatha=null;
			
			System.out.println("After tathas death.....:"+runtime.freeMemory());
			
			runtime.gc();
			
			System.out.println("After tathas death ceremony...:"+runtime.freeMemory());
			
			tatha=weak.get();
			System.out.println(tatha.getGold());
			
		}
	}
	class GrandFather{
		String life="";
		private String gold="under the tree....";
		public GrandFather() {
			for(int i=0;i<10000;i++) {
				life=new String("life is beautifull....:"+i);
			}
		}	
		protected String getGold() {
			return gold;
		}
		@Override
		protected void finalize() throws Throwable {
			System.out.println("finalize method called....");
			System.out.println("The gold is...:"+gold);
		}
	}


	