package DAO;

import java.util.List;

public interface UserDao{
public boolean checkUser(String uname ,String upass);
public void insertUser(String uname ,String upass, int flag );
public void updateUser(int uid);
public void deleteUser(User user);
public void deleteUser(int uid);
public User getUser(int uid);
public List<User> getAllUser();

}

