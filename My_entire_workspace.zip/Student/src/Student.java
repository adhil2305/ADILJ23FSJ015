
public class Student {
String name ,city;
int age ;
int m;
void Printdata() {
	System.out.println("Student Name :" +name);
	System.out.println("Student City :"+ city);
	System.out.println("Student Age :"+age);
}


class Stest{
	public static void main (String[] args) {
		Student s1= new Student();
		Student s2 = new Student();
		s1.name = "Nikith";
		s1.city = "Raja mundry";
		s1.age = 22;
		s2.name = "Meghana";
		s2.city = "mumbai";
		s2.age = 23;
		
		System.out.println("s1.m ="+s1.m);
		System.out.println("s2.m ="+s2.m);
		System.out.println("Student.m = "+s1.age);
		
		}
	}
