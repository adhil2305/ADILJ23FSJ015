package Daily;

public class StaticDemo3 {
	
	/**
	 * Static variable creates a class level variable
	 */
	
	public static void main(String[] args) {
		/*
		 * // SDemo obj = new SDemo(); // obj1.s = 20; // System.out.println(obj1.s); //
		 * SDemo.ss = 200; // System.out.println(SDemo.ss); //
		 *
		 */
		
		
		SDemo obj2 = new SDemo();
		SDemoSub obj3 = new SDemoSub();
		System.out.println();
		SDemo.met();
		System.out.println(obj2.s);
		SDemo.ss = 200;
		System.out.println(SDemo.ss);
		SDemo.met();
	}
}
	class SDemo {
		static int s = 10;//instance variable
		static int ss = 100;//class variable
		
	
	public static void met() {
		System.out.println("static Method called");
	}
	
	}	
	class SDemoSub extends SDemo{
		public static void met() {
			super.met();
			System.out.println("Static method of sub class called...");
		}
	}

