package One;

public class Single2 {
public static void main(String[] args) {
	Shogan shogan  = new Shogan();
	
}
}
public static class Shogan{
	if(obj==null) {
		obj = new obj
	}
}