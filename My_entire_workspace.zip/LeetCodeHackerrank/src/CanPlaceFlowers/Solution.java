package CanPlaceFlowers;

public class Solution {
	public static void main(String[] args) {
		int arr[] = {0, 0,0, 1, 0 , 0, 0,1};
		int n = 2;
		boolean b1 = new Solution().met(arr, n);
		
		System.out.println(b1);
		
		
	}
		public boolean met(int[] flowerbed , int n) {
        if(flowerbed.length==1&&flowerbed[0]==0)//check for first flower can put in flowerbed
       {
           n--;
       }
        if(flowerbed.length>=2&&flowerbed[0]==0&&flowerbed[1]==0)
        {
            n--;
            flowerbed[0]=1;
        }
        for(int i=1;i<flowerbed.length-1;i++)
        {
            if(flowerbed[i]==0&&flowerbed[i-1]!=1&&flowerbed[i+1]!=1)//check for rest flowerbed except last one
            {
            flowerbed[i]=1;
                 n--; 
            }
            if(n==0)
            {
                break;
            }
        }
       if(flowerbed.length>2&&flowerbed[flowerbed.length-1]==0&&flowerbed[flowerbed.length-2]==0)//check last one
        {
            n--;
        }
        if(n<=0)
        {
            return true;
        }
        return false;



    }
}