package edu.disease.asn2;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class InfectiousDiseaseTest {

	@Test
	void test() {
		String[] nonInfectiousDisease = { "Flu", "TB", "Malaria", "COVID-19 " };
		assertArrayEquals(nonInfectiousDisease, new InfectiousDisease().getExamples());
	}

}
