package Hit;

public class CompositionTrial {
public static void main(String[] args) {
	Water w1 = new Water();
	int b = w1.doIt(4);
	System.out.println(b);
	System.out.println(2*5-1);
	/*
	 * IceCream ibaco = new Vanilla(new Fruit(new Nuts())); ibaco.cost();
	 */
}
}
class Water{
	public int doIt(int n) {
		if(n==1) {
			return 1;
		}
		if(n<=0) {
			return 0;
		}
		return 2*n-1 + doIt(n-1);
	}
}
/*
 * class IceCream{
 * 
 * }
 * 
 * class Toppings extends IceCream{} class Nuts{} class fruits extends Toppings{
 * public void cost() { IceCream iceCream; if (iceCream ==null) { return 10; }
 * else { return 10+iceCream.cost(); }
 * 
 * } }
 */