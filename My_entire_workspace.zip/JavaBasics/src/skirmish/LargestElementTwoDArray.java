package skirmish;

public class LargestElementTwoDArray {
	public static void main(String[] args) {
		
	

		
				
			int[][] inTwoDArray = {{12,54,65},
							       {45,77,86},
							       {58,12,51},
							       {56,45,77},
							       {54,76,78}};
		

			int largest = 0;
			       for (int i = 0; i < inTwoDArray.length; i++)
			       {	int left = 0;
			       		int right = inTwoDArray[0].length - 1;
			    	   
			       			while(left<=right) {
			       				
			       				if(inTwoDArray[i][left]>inTwoDArray[i][right]){
			       				largest = inTwoDArray[i][left];
			       				}
			       				else if(inTwoDArray[i][left]<inTwoDArray[i][right]) {
			       					largest = inTwoDArray[i][right];
			       				}
			       				//int temp = inTwoDArray[i][left];
			       				//inTwoDArray[i][left] = inTwoDArray[i][right];
			       				//inTwoDArray[i][right] = temp;
			       				left++;
			       				right--;
			       			}
			       			System.out.println(largest);

			       }
			       System.out.println();
		        for (int k = 0; k < inTwoDArray.length; k++) {
		        		
		            for (int l = 0; l < inTwoDArray[0].length; l++) {
		            	
		                System.out.print(inTwoDArray[k][l] + " ");
		    }
	    System.out.println();
	    }
			    }
			}
