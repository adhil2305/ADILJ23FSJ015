package Daily;


public class ConsDemo2 {
	public static void main(String[] args) {
		new Cons2Sub();
	}
}
class Cons2{
	public Cons2() {
		System.out.println("default cons called...");
	}
	public Cons2(String s) {
		System.out.println("cons2 cons called...");
	}
}
class Cons2Sub extends Cons2{
	public Cons2Sub() {
		//super("aa");
		System.out.println("cons2 sub cons called...................");
	}
}