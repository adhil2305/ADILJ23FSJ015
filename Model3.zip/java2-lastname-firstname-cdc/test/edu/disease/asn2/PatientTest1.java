package edu.disease.asn2;

import static org.junit.Assert.assertEquals;

import static org.junit.Assert.*;
import java.util.Arrays;
import java.util.UUID;

import org.junit.Test;

public class PatientTest1 {
	
	
	@Test
	public void testGetPatientId() {
		UUID id = UUID.randomUUID();
		Patient p = new Patient();
		p.setPatientId(id);
		UUID out = p.getPatientId();
		assertEquals(id, out);
	}

	@Test
	public void testGetFirstName() {
		String firstName = "Syed";
		Patient p = new Patient();
		p.setFirstName(firstName);
		String out = p.getFirstName();
		assertEquals(firstName, out);
	}

	@Test
	public void testGetLastName() {
		String lastName = "Syed";
		Patient p = new Patient();
		p.setLastName(lastName);
		assertEquals(lastName, p.getLastName());
	}

	@Test
	public void testEqualsObject() {
		Patient p1 = new Patient();
		p1.setPatientId(UUID.randomUUID());
		Patient p2 = new Patient(2, 2);
		p2.setPatientId(UUID.randomUUID());
		assertEquals(false, p1.equals(p2));
	}
	
	@Test
	public void testEqualsObject2() {
		UUID id=UUID.randomUUID();
		Patient p1 = new Patient();
		p1.setPatientId(id);
		Patient p2 = new Patient(2, 2);
		p2.setPatientId(id);
		assertEquals(true, p1.equals(p2));
	}

	@Test
	public void testEqualsObject3() {
		UUID id=UUID.randomUUID();
		Patient p1 = new Patient();
		p1.setPatientId(id);
		Patient p2 = new Patient(2, 2);
		assertEquals(false, p1.equals(p2));
	}
	
	@Test
	public void testEqualsObject4() {
		UUID id=UUID.randomUUID();
		Patient p1 = new Patient();
		Patient p2 = new Patient();
		p2.setPatientId(id);
		assertEquals(false, p1.equals(p2));
	}
	
	@Test
	public void testToString() {
		UUID patientId=UUID.randomUUID(),diseaseIds[]=new UUID[1];
		String firstName="Christiano",lastName="Ronaldo";
		Exposure[] exposures=new Exposure[1];
		String toStringMsg="patientId " + patientId + "diseaseIds" + Arrays.toString(diseaseIds) + ", firstName="+ firstName + "lastName" + lastName + "exposures" + Arrays.toString(exposures);
		
		Patient patient=new Patient();
		patient.setFirstName(firstName);
		patient.setLastName(lastName);
		patient.setPatientId(patientId);
		
		assertEquals(toStringMsg,patient.toString());
	}
	
	
		 @Test
		 public void testSortMet() {
		        // Create an array of unsorted patients
		        Patient[] unsortedPatients = {
		            new Patient("John", "Doe"),
		            new Patient("Alice", "Smith"),
		            new Patient("David", "Johnson"),
		            new Patient("bob", "Barker")
		        };
		        Patient[] sortedPatients = Patient.sort(unsortedPatients);
		        
		        
		        Patient[] expectedSortedPatients = {
		                new Patient("bob", "Barker"),
		                new Patient("John", "Doe"),
		                new Patient("David", "Johnson"),
		                new Patient("Alice", "Smith")
		            };

		            // Assert that the sortedPatients array matches the expectedSortedPatients array
		            assertArrayEquals(expectedSortedPatients,  sortedPatients);
		        }
		        
		        
		
	}
	
	

