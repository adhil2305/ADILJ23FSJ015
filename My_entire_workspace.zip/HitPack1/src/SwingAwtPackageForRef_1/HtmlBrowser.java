package SwingAwtPackageForRef_1;

public class HtmlBrowser {


	import java.awt.*;
	

	import java.awt.event.*;
	import javax.swing.JButton;
	import javax.swing.JEditorPane;
	import javax.swing.JFrame;
	import javax.swing.JScrollPane;
	import javax.swing.JTextArea;
	public class HtmlBrowser extends JFrame implements ActionListener
	{
		JEditorPane ep;
		JTextArea ta;
		JButton btn;
		JScrollPane pane1,pane2;
	public HtmlBrowser()
	{
		Container c=getContentPane();
		c.setLayout(new FlowLayout());
		ep=new JEditorPane("text/html","<h1>HTMl Here</h1>");
		ta=new JTextArea("Enter HTML here",10,50);
		pane1=new JScrollPane(ta);
		pane2=new JScrollPane(ep);
		pane2.setPreferredSize(new Dimension(550,180));
		btn=new JButton("Click");
		c.add(pane1);
		c.add(btn);
		c.add(pane2);
		btn.addActionListener(this);
	}
	public void actionPerformed(ActionEvent e)
		{
			if(e.getSource()==btn)
			{
				ep.setText(ta.getText());
			}
		}
	public static void main(String[] args) {
		HtmlBrowser browser=new HtmlBrowser();
		browser.setTitle("browser Example");
		browser.pack();
		browser.setVisible(true);
	}
	}


	SHOIAB-GOLDEN TOUCH - HAARISINFOTECH
	  7:41 PM
	package junitproj;
	public class Calculator {
		public int add(int i,int j) {
			return i+j;
		}
		public int mul(int i,int j) {
			return i*j;
		}
	}
	package junitproj;
	import static org.junit.Assert.assertEquals;
	import org.junit.Test;
	public class CalculatorTest {
		
		@Test
		public void testAdd() {
			Calculator calc=new Calculator();
			int result=calc.add(10,10);
			
			assertEquals(20, result);//the first param is expected and second is actual
		}
		@Test
		public void testMul() {
			Calculator calc=new Calculator();
			int result=calc.mul(4, 10);
			assertEquals(40, result);
		}
	}


	SHOIAB-GOLDEN TOUCH - HAARISINFOTECH
	  8:22 PM
	package junitproj;
	import java.time.LocalDate;
	import java.util.Collections;
	import java.util.Comparator;
	import java.util.List;
	public class Calculator {
		public int add(int i,int j) {
			return i+j;
		}
		public int mul(int i,int j) {
			return i*j;
		}
		
		public int calculateDateDif(LocalDate sd, LocalDate ed) {
			return (int)sd.until(ed).getDays();
		}
		
		public int[] reverseArray(int a[]) {
			int length=a.length;
			int revarray[]=new int[length];
			for(int i=0;i<length;i++) {
				revarray[i]=a[length-1 -i];
			}
			return revarray;
		}
		
		public List<Employee> sortColBySal(List<Employee> emplist){
			Collections.sort(emplist,(e1,e2)->{return e1.compareTo(e2);});
			return emplist;
		}
	}
	class Employee implements Comparable<Employee>{
		String name;
		Integer salary;
		public Employee(String name,Integer salary) {
			this.name=name;
			this.salary=salary;
		}
		
		@Override
		public int compareTo(Employee o) {
			// TODO Auto-generated method stub
			return this.salary.compareTo(o.salary);
		}
	}
	package junitproj;
	import static org.junit.Assert.assertArrayEquals;
	import static org.junit.Assert.assertEquals;
	import java.time.LocalDate;
	import java.util.Arrays;
	import java.util.List;
	import org.junit.Test;
	public class CalculatorTest {
		
		@Test
		public void testAdd() {
			Calculator calc=new Calculator();
			int result=calc.add(10,10);
			
			assertEquals(20, result);//the first param is expected and second is actual
		}
		@Test
		public void testMul() {
			Calculator calc=new Calculator();
			int result=calc.mul(4, 10);
			assertEquals(40, result);
		}
		@Test
		public void testDateDiffMethod() {
			Calculator calc=new Calculator();
			
			LocalDate date1=LocalDate.of(2023, 1, 20);
			LocalDate date2=LocalDate.of(2023, 1, 21);
			
			int result=calc.calculateDateDif(date1, date2);
			assertEquals(1, result);
		}
		
		@Test
		public void testRevArray() {
			int a[]= {1,2,3,4,5};
			int rv[]= {5,4,3,2,1};
			
			Calculator calc=new Calculator();
			int result[]=calc.reverseArray(a);
			assertArrayEquals(rv, result);//this method is capable of comparing two arrays
		}
		
		@Test
		public void testSortCol() {
			Employee e1=new Employee("rahim",40000);
			Employee e2=new Employee("ram",50000);
			Employee e3=new Employee("john",60000);
			
			List<Employee> mylist=Arrays.asList(e1,e2,e3);
			Calculator calc=new Calculator();
			List<Employee> result=calc.sortColBySal(mylist);
			
			assertEquals(mylist, result);
		}
	}


	SHOIAB-GOLDEN TOUCH - HAARISINFOTECH
	  3:45 PM
	Binary
	 

	mysq
	
	
	
	import java.sql.Connection;
	import java.sql.DriverManager;
	public class JDBCDemo1 {
		public static void main(String[] args)throws Exception {
			//STEP 1 - registering the driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//STEP 2 - Establish the connection
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/javabatch","root","root");
			
			System.out.println(con);
			
		}
	}
	package jdbcproj;
	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.Statement;
	public class JDBCDemo2 {
		public static void main(String[] args) throws Exception{
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/javabatch","root","root");
			
			String sql="update users set flag=0";
			
			Statement stmt=con.createStatement();
			
			int n=stmt.executeUpdate(sql);//this returns the number of rows affected
			
			
			System.out.println(n);
			
		}
	}


	SHOIAB-GOLDEN TOUCH - HAARISINFOTECH
	  8:54 PM
	package jdbcproj;
	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.ResultSet;
	import java.sql.Statement;
	public class JDBCDemo2 {
		public static void main(String[] args) throws Exception{
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/javabatch","root","root");
			
			String sql="update users set flag=0";
			
			//Statement stmt=con.createStatement();//be defualt single navigable
			
			//The below statment is for multi-navigable
			Statement stmt=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);//multi navigable
			
			int n=stmt.executeUpdate(sql);
			//this returns the number of rows affected
					
			System.out.println(n);
			
			sql="select * from users";
			
			boolean boo=stmt.execute(sql);
			
			System.out.println(boo);//true
			
			ResultSet rs= stmt.executeQuery(sql);
			while(rs.next()) {
				System.out.println(rs.getInt("userid"));
				System.out.println(rs.getString("username"));
			}
			
			//rs= stmt.executeQuery(sql);
			while(rs.previous()) {
				System.out.println("............"+rs.getInt(1));
				System.out.println("............"+rs.getString(2));
			}
			
			
			
		}
	}


	
	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.Statement;
	import java.util.Scanner;
	public class JDBCDemo3 {
		public static void main(String[] args) throws Exception{
			//STEP 1 - registering the driver
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			//STEP 2 - Establish the connection
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/javabatch","root","root");
			String sql="select * from users where userid=?";//dynamic query
			PreparedStatement stmt=con.prepareStatement(sql);
			
			while(true) {
				Scanner scan=new Scanner(System.in);
				System.out.println("\nPlease enter userid..:");
				int uid=scan.nextInt();
				
				//String sql="select * from users where userid="+userid;//this concatenation is bad
				//this will create sql injection problem - not recommended...its a security problem
				
				//This statement is not advisable 
				//Statement stmt=con.createStatement();
				stmt.setInt(1, uid);
				ResultSet rs=stmt.executeQuery();
				while(rs.next()) {
					System.out.printf("The salary of %s is %d",rs.getString("username"),rs.getInt("salary"));
				}
			}
			
		}
	}


	
	import java.sql.CallableStatement;
	import java.sql.Connection;
	import java.sql.DriverManager;
	/*
	 * delimiter //
	 * create procedure myproc()
	 * begin
	 * insert into users values (300,'somu','secret',4000,0);
	 * insert into users values (400,'saravanan','secret',7500,0);
	 * update users set flag=1;
	 * end;
	 * //
	 * delimiter ;
	 */
	public class JDBCDemo4 {
		public static void main(String[] args) throws Exception{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/javabatch","root","root");
			
			CallableStatement cs=con.prepareCall("{call myproc()}");
			
			cs.execute();
			
		}
	}
	package jdbcproj;
	import java.sql.CallableStatement;
	import java.sql.Connection;
	import java.sql.DriverManager;
	/*
	 * mysql> create procedure myproc2(IN myflag INT)
	    -> begin
	    -> update users set flag=myflag;
	    -> end;
	    -> //
	Query OK, 0 rows affected (0.01 sec)
	mysql> delimiter ;
	 */
	/*
	 * mysql> create procedure myproc3(IN uid INT,IN uname varchar(40),IN upass varchar(8),IN sal INT,IN myflag INT)
	    -> begin
	    -> insert into users values (uid,uname,upass,sal,myflag);
	    -> end;
	    -> //
	Query OK, 0 rows affected (0.02 sec)
	mysql> delimiter ;
	mysql>
	 */
	public class JDBCDemo5 {
		public static void main(String[] args) throws Exception{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/javabatch","root","root");
			
			CallableStatement cs=con.prepareCall("{call myproc2(?)}");
			
			cs.setInt(1, 0);
			
			cs.execute();
			
			cs=con.prepareCall("{call myproc3(?,?,?,?,?)}");
			cs.setInt(1, 500);
			cs.setString(2, "sami");
			cs.setString(3, "secret");
			cs.setInt(4, 5000);
			cs.setInt(5, 1);
			
			cs.execute();
		}
	}
	package jdbcproj;
	import java.sql.CallableStatement;
	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.Types;
	/*
	 * mysql> create procedure myproc4(OUT noofrows INT)
	    -> begin
	    -> select count(*) from users into noofrows;
	    -> end;
	    -> //
	Query OK, 0 rows affected (0.01 sec)
	mysql>
	 */
	public class JDBCDemo6 {
		public static void main(String[] args) throws Exception{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/javabatch","root","root");
			
			CallableStatement cs=con.prepareCall("{call myproc4(?)}");
			
			cs.registerOutParameter(1, Types.INTEGER);
			
			cs.execute();
			
			int rowcount=cs.getInt(1);
			System.out.println("No of rows in users table is...:"+rowcount);
			
		}
	}


	SHOIAB-GOLDEN TOUCH - HAARISINFOTECH
	  9:16 PM
	Binary
	 

	mysql-connector-java-8.0.20.jar
	Binary


	SHOIAB-GOLDEN TOUCH - HAARISINFOTECH
	  8:46 PM
	package dao;
	import java.util.Collection;
	public abstract class UserDAO {//Data Access Object
		public abstract UserDTO findByPrimaryKey(int uid);
		public abstract Collection<UserDTO> findAll();
		public abstract UserDTO findByName(String uname);
		public abstract void insertUser(UserDTO user);
		public abstract void updateUser(UserDTO user);
		public abstract void deleteUser(int userid);
		public abstract void deleteUserByName(String uname);
		
	}
	package dao;
	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.Statement;
	import java.util.ArrayList;
	import java.util.Collection;
	import java.util.List;
	public class UserDAOImpl extends UserDAO{
		Connection con;
		public UserDAOImpl()throws Exception {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost/javabatch","root","root");
		}
		@Override
		public UserDTO findByPrimaryKey(int uid) {
			try {
			PreparedStatement stmt=con.prepareStatement("select * from users where userid=?");
			stmt.setInt(1, uid);
			ResultSet rs=stmt.executeQuery();
			if(rs.next()) {
				UserDTO userObj=new UserDTO();
				userObj.setUid(rs.getInt(1));
				userObj.setUname(rs.getString(2));
				userObj.setUpass(rs.getString(3));
				userObj.setSalary(rs.getInt(4));
				userObj.setFlag(rs.getInt(5));
				return userObj;
			}
			else {
				return null;
			}
			}catch(Exception e) {
				e.printStackTrace();			
				return null;
			}finally {
				try{con.close();}catch(Exception e1) {e1.printStackTrace();}
			}
		}
		@Override
		public Collection<UserDTO> findAll() {
			try {
				Statement st=con.createStatement();
				ResultSet rs=st.executeQuery("select * from users");
				List<UserDTO> users=new ArrayList<UserDTO>();
				while(rs.next()) {
					UserDTO userObj=new UserDTO();
					userObj.setUid(rs.getInt(1));
					userObj.setUname(rs.getString(2));
					userObj.setUpass(rs.getString(3));
					userObj.setSalary(rs.getInt(4));
					userObj.setFlag(rs.getInt(5));
					users.add(userObj);
				}
				return users;
			}catch(Exception e) {
				e.printStackTrace();
				return null;
			}finally {
				try {con.close();}catch(Exception ee) {ee.printStackTrace();}
			}
		}
		@Override
		public UserDTO findByName(String uname) {
			// TODO Auto-generated method stub
			return null;
		}
		@Override
		public void insertUser(UserDTO user) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void updateUser(UserDTO user) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void deleteUser(int userid) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void deleteUserByName(String uname) {
			// TODO Auto-generated method stub
			
		}
	}
	package dao;
	public class UserDTO {//DTO - Data Transfer Object
		private int uid;
		private String uname,upass;
		private int salary,flag;
		public UserDTO() {
			// TODO Auto-generated constructor stub
		}
		public UserDTO(int uid, String uname, String upass, int salary, int flag) {		
			this.uid = uid;
			this.uname = uname;
			this.upass = upass;
			this.salary = salary;
			this.flag = flag;
		}
		/**
		 * @return the uid
		 */
		public int getUid() {
			return uid;
		}
		/**
		 * @param uid the uid to set
		 */
		public void setUid(int uid) {
			this.uid = uid;
		}
		/**
		 * @return the uname
		 */
		public String getUname() {
			return uname;
		}
		/**
		 * @param uname the uname to set
		 */
		public void setUname(String uname) {
			this.uname = uname;
		}
		/**
		 * @return the upass
		 */
		public String getUpass() {
			return upass;
		}
		/**
		 * @param upass the upass to set
		 */
		public void setUpass(String upass) {
			this.upass = upass;
		}
		/**
		 * @return the salary
		 */
		public int getSalary() {
			return salary;
		}
		/**
		 * @param salary the salary to set
		 */
		public void setSalary(int salary) {
			this.salary = salary;
		}
		/**
		 * @return the flag
		 */
		public int getFlag() {
			return flag;
		}
		/**
		 * @param flag the flag to set
		 */
		public void setFlag(int flag) {
			this.flag = flag;
		}
		@Override
		public String toString() {
			return "UserDTO [uid=" + uid + ", uname=" + uname + ", upass=" + upass + ", salary=" + salary + ", flag=" + flag
					+ "]";
		}
		
		
		
	}
	8:46
	package dao;
	import java.util.List;
	public class Demo {
		public static void main(String[] args)throws Exception {
			UserDAO dao=new UserDAOImpl();
			
			List<UserDTO> users=(List<UserDTO>)dao.findAll();
			
			System.out.println(users);
		}
	}
	8:50
	PDF
	 

	JAVA Security-By Shoiab.pdf
	PDF




	SHOIAB-GOLDEN TOUCH - HAARISINFOTECH
	  8:44 PM
	package dao;
	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.util.Scanner;
	public class TransactionDemo {
		public static void main(String[] args)throws Exception {
			Class.forName("com.mysql.cj.jdbc.Driver");		
			//STEP 2 - Establish the connection
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/javabatch","root","root");
			con.setAutoCommit(false);
			
			Scanner scan=new Scanner(System.in);
			System.out.println("Please enter CREDIT name..:");
			String uname=scan.next();
			System.out.println("Please enter amount..to credit.:");
			int amt=scan.nextInt();
			int currentamt=0;
			
			PreparedStatement ps=con.prepareStatement("select salary from users where username=?");
			ps.setString(1, uname);
			ResultSet rs=ps.executeQuery();
			
			if(rs.next()) {
				currentamt=rs.getInt(1);
			}
			
			ps=con.prepareStatement("update users set salary=? where username=?");
			ps.setInt(1, amt+currentamt);
			ps.setString(2, uname);
			ps.executeUpdate();
			
			System.out.println("Please enter DEBIT name..:");
			uname=scan.next();
			ps=con.prepareStatement("select salary from users where username=?");
			ps.setString(1, uname);
			rs=ps.executeQuery();
			if(rs.next()) {
				currentamt=rs.getInt(1);
			}
			else {
				con.rollback();
			}
			
			ps=con.prepareStatement("update users set salary=? where username=?");
			ps.setInt(1, currentamt-amt);
			ps.setString(2, uname);
			ps.executeUpdate();
			con.commit();
		}
	}
	8:45
	PDF
	 

	Servlet study material.pdf
	PDF




	SHOIAB-GOLDEN TOUCH - HAARISINFOTECH
	  8:25 PM
	image.png
	 
	image.png




	SHOIAB-GOLDEN TOUCH - HAARISINFOTECH
	  8:45 PM
	Zip
	 

	apache-tomcat-9.0.41.zip
	Zip


	SHOIAB-GOLDEN TOUCH - HAARISINFOTECH
	  9:06 PM
	package com;
	import java.io.IOException;
	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import javax.servlet.ServletException;
	import javax.servlet.ServletOutputStream;
	import javax.servlet.annotation.WebServlet;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;
	/**
	 * Servlet implementation class HelloServlet
	 */
	@WebServlet("/HelloServlet")
	public class HelloServlet extends HttpServlet {
		
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			// TODO Auto-generated method stub
			
			System.out.println("do get of servlet called....");
			String n=request.getParameter("num");
			response.setContentType("text/html");
			ServletOutputStream browser_output=response.getOutputStream();
			
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con=DriverManager.getConnection
						("jdbc:mysql://localhost/javabatch","root","root");
				
				PreparedStatement ps=con.prepareStatement("select * from users where userid=?");
				ps.setInt(1, Integer.parseInt(n));
				ResultSet rs=ps.executeQuery();
				if(rs.next()) {
					System.out.println(rs.getString("username"));
					browser_output.println("<h1>"+rs.getString("username")+"</h1>");
				}
				
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
	}
	9:07
	package com;
	import java.net.URL;
	import java.net.URLConnection;
	public class Client {
		public static void main(String[] args) throws Exception{
			URL url=new URL("http://localhost:2020/myweb/HelloServlet");
			
			URLConnection urlcon=url.openConnection();
			
			urlcon.getInputStream();
		}
	}
	9:07
	<!DOCTYPE html>
	<html>
	<head>
	<meta charset="ISO-8859-1">
	<title>Insert title here</title>
	</head>
	<body>
		<form action="http://localhost:2020/myweb/login.gold" method="POST">
			Please enter Username:<input type="text" name="uname">
			Please enter your coach name:<input type="text" name="coach">
			<input type="submit" value="Click Me...">
		</form>
	</body>
	</html>
	9:07
	package com;
	import java.io.IOException;
	import javax.servlet.ServletException;
	import javax.servlet.ServletOutputStream;
	import javax.servlet.annotation.WebServlet;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;
	@WebServlet("*.gold")
	public class MyServlet extends HttpServlet {
		
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			System.out.println("do get called...");
			String name=request.getParameter("uname");
			String teacher=request.getParameter("coach");
			
			response.setContentType("text/html");
			ServletOutputStream out=response.getOutputStream();
			out.println("<h1>Welcome to Servlets..."+name+":"+teacher+"</h1>");
		}
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			// TODO Auto-generated method stub
			System.out.println("do post called....");
			doGet(request, response);
		}
	}
	9:07
	<!DOCTYPE html>
	<html>
	<head>
	<meta charset="ISO-8859-1">
	<title>Insert title here</title>
	</head>
	<body>
		<form action="http://localhost:2020/myweb/MyServlet" >
			
			<input type="submit" value="Click Me...">
		</form>
	</body>
	</html>


	SHOIAB-GOLDEN TOUCH - HAARISINFOTECH
	  8:46 PM
	package com;
	import java.io.IOException;
	import javax.servlet.ServletException;
	import javax.servlet.ServletOutputStream;
	import javax.servlet.annotation.WebServlet;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;
	import javax.servlet.http.HttpSession;
	@WebServlet("/SessionDemo")
	public class SessionDemo extends HttpServlet {
		
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			ServletOutputStream out=response.getOutputStream();
			HttpSession session=request.getSession(true);
			
			if(session.isNew()) {
				out.println("<h1>Welcome...you are visiting for first time...</h1>");
			}
			else {
				out.println("<h1>this is not your first time.....</h1>");
			}		
		}
	}


	SHOIAB-GOLDEN TOUCH - HAARISINFOTECH
	  8:52 PM
	package com;
	import java.io.IOException;
	import javax.servlet.ServletException;
	import javax.servlet.ServletOutputStream;
	import javax.servlet.annotation.WebServlet;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;
	import javax.servlet.http.HttpSession;
	/**
	 * Servlet implementation class SessionDemo2
	 */
	@WebServlet("/SessionDemo2")
	public class SessionDemo2 extends HttpServlet {
		
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			ServletOutputStream out=response.getOutputStream();
			HttpSession session=request.getSession();
			if(session.isNew()) {
				out.println("<h1>You are visiting for the first time...</h1>");
				session.setAttribute("count", 2);
			}
			else {
				String c=session.getAttribute("count").toString();
				out.println("<h1>You are visiting for the ..."+c+ "times...</h1>");
				int nc=Integer.parseInt(c);
				session.setAttribute("count", ++nc);
			}
		}
	}


	Abdul Hakeem
	  8:57 PM
	Windows application
	 

	Postman-win64-Setup.exe
	Windows application


	SHOIAB-GOLDEN TOUCH - HAARISINFOTECH
	  8:58 PM
	package com;
	import java.io.FileInputStream;
	import java.io.IOException;
	import java.util.Properties;
	import javax.servlet.ServletContext;
	import javax.servlet.ServletException;
	import javax.servlet.annotation.WebServlet;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;
	/**
	 * Servlet implementation class FirstServlet
	 */
	@WebServlet("/FirstServlet")
	public class FirstServlet extends HttpServlet {
		
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			ServletContext app=request.getServletContext();
			app.setAttribute("globalkey", "this is global value....");
			System.out.println("global key is set......");
			String path=app.getRealPath("/WEB-INF/abc.properties");
			Properties prop=new Properties();
			prop.load(new FileInputStream(path));
			System.out.println(prop.get("hello"));
		}
		/**
		 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
		 */
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			// TODO Auto-generated method stub
			doGet(request, response);
		}
	}
	8:59
	package com;
	import java.io.IOException;
	import javax.servlet.ServletContext;
	import javax.servlet.ServletException;
	import javax.servlet.annotation.WebServlet;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;
	/**
	 * Servlet implementation class SecondServlet
	 */
	@WebServlet("/SecondServlet")
	public class SecondServlet extends HttpServlet {
		
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			ServletContext app=request.getServletContext();
			String str=app.getAttribute("globalkey").toString();
			System.out.println(str);
		}
		/**
		 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
		 */
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			// TODO Auto-generated method stub
			doGet(request, response);
		}
	}


	SHOIAB-GOLDEN TOUCH - HAARISINFOTECH
	  9:12 PM
	package com;
	import java.io.FileInputStream;
	import java.io.IOException;
	import java.util.Properties;
	import javax.servlet.ServletConfig;
	import javax.servlet.ServletContext;
	import javax.servlet.ServletException;
	import javax.servlet.annotation.WebInitParam;
	import javax.servlet.annotation.WebServlet;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;
	/**
	 * Servlet implementation class FirstServlet
	 */
	@WebServlet(
			urlPatterns = {"/FirstServlet","*.doo","*.gold","/blabla"},
			initParams = {
				@WebInitParam(name = "key1", value="bla bla bla"),
				@WebInitParam(name = "key2", value="bla2 bla2 bla2")
			}
			)
	public class FirstServlet extends HttpServlet {
		@Override
			public void init(ServletConfig config) throws ServletException {
				System.out.println("init called....");
				String k=config.getInitParameter("key1");
				System.out.println(k);
				System.out.println(config.getInitParameter("key2"));
			}
		
		@Override
			public void destroy() {
				System.out.println("destroyed called...");
			}
		
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			ServletContext app=request.getServletContext();
			app.setAttribute("globalkey", "this is global value....");
			System.out.println("global key is set......");
			String path=app.getRealPath("/WEB-INF/abc.properties");
			Properties prop=new Properties();
			prop.load(new FileInputStream(path));
			System.out.println(prop.get("hello"));
		}
		/**
		 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
		 */
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			// TODO Auto-generated method stub
			doGet(request, response);
		}
	}


	SHOIAB-GOLDEN TOUCH - HAARISINFOTECH
	  8:44 PM
	<dependencies>
	  <!-- https://mvnrepository.com/artifact/mysql/mysql-connector-java -->
	<dependency>
	    <groupId>mysql</groupId>
	    <artifactId>mysql-connector-java</artifactId>
	    <version>8.0.33</version>
	</dependency>
	<dependency>
	      <groupId>org.jboss.resteasy</groupId>
	      <artifactId>resteasy-jaxrs</artifactId>
	      <version>3.1.4.Final</version>
	</dependency>
	<dependency>
	      <groupId>org.jboss.resteasy</groupId>
	      <artifactId>resteasy-jaxb-provider</artifactId>
	      <version>3.1.4.Final</version>
	</dependency>
	<dependency>
	      <groupId>org.jboss.resteasy</groupId>
	      <artifactId>resteasy-servlet-initializer</artifactId>
	      <version>3.1.4.Final</version>
	</dependency>
	<!-- https://mvnrepository.com/artifact/org.jboss.resteasy/resteasy-jackson2-provider -->
	<dependency>
	    <groupId>org.codehaus.jackson</groupId>
	    <artifactId>jackson-jaxrs</artifactId>
	    <version>1.9.13</version>
	</dependency>
	<!-- https://mvnrepository.com/artifact/org.codehaus.jackson/jackson-xc -->
	<dependency>
	    <groupId>org.codehaus.jackson</groupId>
	    <artifactId>jackson-xc</artifactId>
	    <version>1.9.13</version>
	</dependency>
	  </dependencies>


	SHOIAB-GOLDEN TOUCH - HAARISINFOTECH
	  9:06 PM
	package goldrest;
	import java.util.HashSet;
	import java.util.Set;
	import javax.ws.rs.ApplicationPath;
	import javax.ws.rs.core.Application;
	@ApplicationPath("rest")
	public class HelloWorldApplication extends Application {
	   public HelloWorldApplication() {
	   }
	   @Override
	   public Set<Object> getSingletons() {
	       HashSet<Object> set = new HashSet<Object>();
	       return set;
	   }
	}
	9:07
	package goldrest;
	import javax.ws.rs.GET;
	import javax.ws.rs.Path;
	@Path("/myservice")
	public class HelloService {
		
		@GET
		public void sayHello() {
			System.out.println("say hello method called...");
		}
	}


	SHOIAB-GOLDEN TOUCH - HAARISINFOTECH
	  8:41 PM
	package goldrest;
	import javax.ws.rs.GET;
	import javax.ws.rs.Path;
	import javax.ws.rs.PathParam;
	@Path("/goglobal")//http://localhost:2020/goldrest/resteasy/goglobal
	public class MyService {
		@GET
		public void met() {
			System.out.println("met method called....");
		}
		
		@Path("/met2")
		@GET
		public void met2() {
			System.out.println("met 2 method called....");
		}
		
		@Path("/met3/{myparam}")
		@GET
		public void met3(@PathParam("myparam") String p) {
			System.out.println("met 3 called....:"+p);
		}
		
		@Path("/met3/{myparam}/{param2}")
		@GET
		public void met4(@PathParam("myparam") String p,@PathParam("param2")String p2) {
			System.out.println("met 3 called....:"+p+":"+p2);
		}
		
		
	}
	8:46
	package goldrest;
	import java.util.HashSet;
	import java.util.Set;
	import javax.ws.rs.ApplicationPath;
	import javax.ws.rs.core.Application;
	@ApplicationPath("/resteasy")
	public class StartRestEasyFramework extends Application{
	public StartRestEasyFramework() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public Set<Object> getSingletons() {
			HashSet<Object> set = new HashSet<Object>();
			return set;
		}
	}


	SHOIAB-GOLDEN TOUCH - HAARISINFOTECH
	  9:03 PM
	package goldrest;
	import javax.servlet.ServletOutputStream;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;
	import javax.servlet.http.HttpSession;
	import javax.ws.rs.GET;
	import javax.ws.rs.Path;
	import javax.ws.rs.PathParam;
	import javax.ws.rs.core.Context;
	import javax.ws.rs.core.Response;
	@Path("/service")
	public class MyService2 {
		@Context
		HttpServletRequest request;
		@Context
		HttpServletResponse response;
		
		@Path("/setName/{name}")
		@GET
		public void setName(@PathParam("name") String name) {
			HttpSession session=request.getSession();
			session.setAttribute("name",name);
			System.out.println("name set....");
		}
		
		@Path("/getName")
		@GET
		public Response displayName() {
			HttpSession session=request.getSession();
			String name=session.getAttribute("name").toString();
			System.out.println(name);
			try {
				return Response.status(200).entity(name).build();
			}catch(Exception e) {
				e.printStackTrace();
				return null;
			}
		}
		
	}


	SHOIAB-GOLDEN TOUCH - HAARISINFOTECH
	  12:50 PM
	package basic;
	public class ATM {
		public static void main(String[] args) {
			ATM sbiAtm=new ATM();
			sbiAtm.withdrawCash(300);
		}
		public int withdrawCash(int amt) {
			int highest=0;
			int tray[]= {20,100,200,2000,500};
			for(int i=0;i<tray.length;i++) {
				//highest=tray[i];
				if(i<tray.length-1) {
					if(highest<tray[i+1]) {
						highest=tray[i+1];
						System.out.println(highest);
					}
				}
				else {				
					if(highest<tray[i]) {					
						highest=tray[i];
					}
				}
			}
			System.out.println("The highest value is...:"+highest);
			return highest;
		}
	}


	SHOIAB-GOLDEN TOUCH - HAARISINFOTECH
	  8:44 PM
	package goldrest;
	import java.util.ArrayList;
	import java.util.List;
	import javax.ws.rs.Consumes;
	import javax.ws.rs.GET;
	import javax.ws.rs.PUT;
	import javax.ws.rs.Path;
	import javax.ws.rs.Produces;
	import javax.ws.rs.core.MediaType;
	@Path("/service3")
	public class MyService3 {
		@GET
		@Path("/getUser")
		@Produces(MediaType.APPLICATION_JSON)
		public User getUser() {
			User user=new User(100,"ramu","secret",2000);
			return user;
		}
		
		@GET
		@Path("/getUsers")
		@Produces(MediaType.APPLICATION_JSON)
		public List<User> getUsers() {
			User user1=new User(100,"ramu","secret",2000);
			User user2=new User(100,"ramu","secret",2000);
			User user3=new User(100,"ramu","secret",2000);
			List<User> list=new ArrayList<User>();
			list.add(user1);list.add(user2);list.add(user3);
			return list;
		}
		
		@PUT//put is used when resources are used - since user is a resource PUT is used
		@Path("/setUser")
		@Consumes(MediaType.APPLICATION_JSON)
		public void setUser(User user) {
			System.out.println("user set...:"+user);
		}
		
		@PUT//put is used when resources are used - since user is a resource PUT is used
		@Path("/setUsers")
		@Consumes(MediaType.APPLICATION_JSON)
		public void setUser(List users) {
			System.out.println("user set...:"+users);
		}
		
	}


	SHOIAB-GOLDEN TOUCH - HAARISINFOTECH
	  9:07 PM
	package goldrest;
	import javax.ws.rs.FormParam;
	import javax.ws.rs.GET;
	import javax.ws.rs.POST;
	import javax.ws.rs.Path;
	import javax.ws.rs.QueryParam;
	@Path("/service4")
	public class MyService4 {
		//http://localhost:2020/goldrest/resteasy/service4/setUserQuery?uid=100&uname='sho'&upass='secret'&salary=2000
		@GET
		@Path("/setUserQuery")
		public void setUser(
				@QueryParam("uid") int uid,
				@QueryParam("uname") String uname,
				@QueryParam("upass") String upass,
				@QueryParam("salary") int sal
				) {
			User user=new User(uid,uname,upass,sal);
			System.out.println(user);
		}
		
		@POST
		@Path("/setUserForm")
		public void setUserForm(
				@FormParam("uid") int uid,
				@FormParam("uname") String uname,
				@FormParam("upass") String upass,
				@FormParam("salary") int sal
				) {
			User user=new User(uid,uname,upass,sal);
			System.out.println(user);
		}
	}


	SHOIAB-GOLDEN TOUCH - HAARISINFOTECH
	  9:25 PM
	package com.example.demo;
	public abstract class ShoeFactory {
		public abstract void makeShoe();
	}
	package com.example.demo;
	import org.springframework.stereotype.Component;
	@Component("bsf")
	public class BataShoeFactory extends ShoeFactory{
	@Override
	public void makeShoe() {
		System.out.println("shoe made by batashoefactory...");
	}
	}
	package com.example.demo;
	public abstract class ShoeShop {
		public abstract void sellShoe();
	}
	package com.example.demo;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Component;
	@Component("gss")
	public class GokulShoeShop extends ShoeShop{
		@Autowired//dependency injection
		private ShoeFactory factory;
		public void setFactory(ShoeFactory factory) {
			this.factory=factory;
		}
		public ShoeFactory getFactory() {
			return this.factory;
		}
	@Override
	public void sellShoe() {
		// TODO Auto-generated method stub
		factory.makeShoe();
	}
	}
	package com.example.demo;
	import org.springframework.boot.SpringApplication;
	import org.springframework.boot.autoconfigure.SpringBootApplication;
	import org.springframework.context.ConfigurableApplicationContext;
	@SpringBootApplication
	public class Jul15Application {
		public static void main(String[] args) {
			ConfigurableApplicationContext ctx= SpringApplication.run(Jul15Application.class, args);
			
			ShoeShop gss_shop=ctx.getBean("gss",ShoeShop.class);
			
			gss_shop.sellShoe();
		}
	}


	SHOIAB-GOLDEN TOUCH - HAARISINFOTECH
	  8:53 PM
	package nonspring;
	import java.io.FileInputStream;
	import java.lang.reflect.Field;
	import java.util.Properties;
	public class WithoutSpringDemo {
		public static void main(String[] args) {
			ShoeShop myshop=MySpringContainer.getShop();
			System.out.println(myshop.sellShoe());
		}
	}
	class MySpringContainer{
		public static ShoeShop getShop() {
			//creating objects-1
			try {
			Properties prop=new Properties();
			prop.load(new FileInputStream("config.properties"));
			String factoryname=prop.getProperty("factory");
			ShoeFactory factory=(ShoeFactory)Class.forName(factoryname).getConstructor().newInstance();
			String shopname=prop.getProperty("shop");
			ShoeShop shop=(ShoeShop)Class.forName(shopname).getConstructor().newInstance();
			//dependency injection-2
			Class c=shop.getClass().getSuperclass();
			Field f=c.getDeclaredField("factory");
			f.setAccessible(true);
			In in=f.getAnnotation(In.class);
					if(in!=null) {
						shop.setFactory(factory);
					}
			return shop;
			}catch(Exception e) {
				e.printStackTrace();
				return null;
			}
		}
	}
	class Shoe{}
	abstract class ShoeFactory{
		public abstract Shoe makeShoe();
	}
	class BataShoeFactory extends ShoeFactory{
		public BataShoeFactory() {
			// TODO Auto-generated constructor stub
		}
		@Override
		public Shoe makeShoe() {
			return new Shoe();
		}
	}
	abstract class ShoeShop{
		//@In
		private ShoeFactory factory;
		public void setFactory(ShoeFactory factory) {
			this.factory=factory;
		}
		public ShoeFactory getFactory() {
			return this.factory;
		}
		public abstract Shoe sellShoe();
	}
	class BalaShoeShop extends ShoeShop{
		public BalaShoeShop() {
			// TODO Auto-generated constructor stub
		}
		@Override
		public Shoe sellShoe() {
			return getFactory().makeShoe();
		}
	}
	8:58
	package nonspring;
	import java.lang.annotation.Retention;
	import java.lang.annotation.RetentionPolicy;
	@Retention(RetentionPolicy.RUNTIME)
	public @interface In {
	}


	SHOIAB-GOLDEN TOUCH - HAARISINFOTECH
	  8:35 PM
	package com.example.demo;
	import org.springframework.context.annotation.Lazy;
	import org.springframework.stereotype.Component;
	@Component("bsf")
	@Lazy
	public class BataShoeFactory extends ShoeFactory{
		public BataShoeFactory() {
			System.out.println("bata shoe factory object created...");
		}
	@Override
	public Shoe makeShoe() {
		return new SportsShoe();
	}
	}
	8:35
	package com.example.demo;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.beans.factory.annotation.Qualifier;
	import org.springframework.context.annotation.Lazy;
	import org.springframework.stereotype.Component;
	import org.springframework.stereotype.Service;
	@Component("gss")
	@Lazy
	public class GokulShoeShop extends ShoeShop{
		public GokulShoeShop() {
			System.out.println("gokul shoe shop object created...");
		}
		@Autowired//dependency injection
		@Qualifier("lsf")
		private ShoeFactory factory;
		public void setFactory(ShoeFactory factory) {
			this.factory=factory;
		}
		public ShoeFactory getFactory() {
			return this.factory;
		}
	@Override
	public Shoe sellShoe() {
		// TODO Auto-generated method stub
		return factory.makeShoe();
	}
	}
	8:35
	package com.example.demo;
	import org.springframework.boot.SpringApplication;
	import org.springframework.boot.autoconfigure.SpringBootApplication;
	import org.springframework.context.ConfigurableApplicationContext;
	@SpringBootApplication
	public class Jul15Application {
		public static void main(String[] args) {
			ConfigurableApplicationContext ctx= SpringApplication.run(Jul15Application.class, args);
			
			ShoeShop gss_shop=ctx.getBean("gss",ShoeShop.class);
			
			//System.out.println(gss_shop.sellShoe());
		}
	}
	8:35
	package com.example.demo;
	import org.springframework.context.annotation.Lazy;
	import org.springframework.stereotype.Component;
	@Component("lsf")
	@Lazy
	public class LakhaniShoeFactory extends ShoeFactory{
		public LakhaniShoeFactory() {
			System.out.println("lakhani shoe factory object created....");
		}
	@Override
	public Shoe makeShoe() {
		return new LeatherShoe();
		
	}
	}
	8:35
	package com.example.demo;
	public class LeatherShoe extends Shoe{
	}
	8:35
	package com.example.demo;
	public abstract class Shoe {
		
	}
	8:35
	package com.example.demo;
	public abstract class ShoeFactory {
		public abstract Shoe makeShoe();
	}
	8:35
	package com.example.demo;
	public abstract class ShoeShop {
		public abstract Shoe sellShoe();
	}
	8:36
	package com.example.demo;
	public class SportsShoe extends Shoe{
	}


	SHOIAB-GOLDEN TOUCH - HAARISINFOTECH
	  9:13 PM
	package com.example.demo;
	import org.springframework.context.annotation.Bean;
	import org.springframework.context.annotation.Configuration;
	@Configuration
	public class MyBean {
		
		@Bean
		public Emp getEmp() {
			return new Emp();
		}
	}
	class Emp{
		
	}
	9:14
	package com.example.demo;
	import org.springframework.boot.SpringApplication;
	import org.springframework.boot.autoconfigure.SpringBootApplication;
	import org.springframework.context.ConfigurableApplicationContext;
	import org.springframework.context.annotation.AnnotationConfigApplicationContext;
	@SpringBootApplication
	public class Jul15Application {
		public static void main(String[] args) {
			ConfigurableApplicationContext ctx= SpringApplication.run(Jul15Application.class, args);
			
			ShoeShop gss_shop=ctx.getBean("gss",ShoeShop.class);
			
			System.out.println(gss_shop.sellShoe());
			
			ctx.close();
			
			AaXVQMNw2GjHbCMVbG86p22Pur8zYwS4K9 actx=new AaXVQMNw2GjHbCMVbG86p22Pur8zYwS4K9(MyBean.class);
			
			Emp myemp=actx.getBean(Emp.class);
			
			System.out.println(myemp);
		}
	}


	SHOIAB-GOLDEN TOUCH - HAARISINFOTECH
	  8:44 PM
	image.png
	 
	image.png


	SHOIAB-GOLDEN TOUCH - HAARISINFOTECH
	  9:35 PM
	spring.datasource.url=jdbc:mysql://localhost/javabatch
	spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver
	spring.datasource.username=root
	spring.datasource.password=root
	spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.MySQL8Dialect
	spring.jpa.show-sql=true
	spring.jpa.hibernate.ddl-auto=update
	9:35
	package com.example.demo;
	import jakarta.persistence.Column;
	import jakarta.persistence.Entity;
	import jakarta.persistence.Id;
	import jakarta.persistence.Table;
	@Entity
	@Table(name="users")
	public class User {
		@Id
		//@Column(name="userid")
		private int userid;
		private String username,password;
		private int salary,flag;
		public int getUserid() {
			return userid;
		}
		public void setUserid(int userid) {
			this.userid = userid;
		}
		public String getUsername() {
			return username;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public int getSalary() {
			return salary;
		}
		public void setSalary(int salary) {
			this.salary = salary;
		}
		public int getFlag() {
			return flag;
		}
		public void setFlag(int flag) {
			this.flag = flag;
		}
		
	}
	9:35
	package com.example.demo;
	import org.springframework.data.jpa.repository.JpaRepository;
	import org.springframework.stereotype.Repository;
	@Repository
	public interface UserDAO extends JpaRepository<User, Integer>{
	}
	9:35
	package com.example.demo;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Repository;
	import org.springframework.stereotype.Service;
	import jakarta.transaction.Transactional;
	@Service("us")
	public class UserService {
		
		@Autowired
		private UserDAO udao;
		
		public void addUser() {
			User userobj=new User();
			userobj.setUserid(100);
			userobj.setUsername("rajesh");
			userobj.setPassword("secret");
			userobj.setSalary(10000);
			userobj.setFlag(0);
			
			udao.save(userobj);
			
		}
	}
	9:36
	package com.example.demo;
	import org.springframework.boot.SpringApplication;
	import org.springframework.boot.autoconfigure.SpringBootApplication;
	import org.springframework.context.ConfigurableApplicationContext;
	@SpringBootApplication
	public class Jul15DbApplication {
		public static void main(String[] args) {
			ConfigurableApplicationContext ctx= SpringApplication.run(Jul15DbApplication.class, args);
			
			UserService us=(UserService)ctx.getBean("us");
			
			us.addUser();
			
		}
	}


	SHOIAB-GOLDEN TOUCH - HAARISINFOTECH
	  9:16 PM
	package com.example.demo;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Component;
	@Component("login")
	public class LoginBean {
		@Autowired
		private UserService userservice;
		
		public String login(String username,String password) {
			if(userservice.checkUser(username, password)) {
				if(userservice.checkFlag(username)) {
					userservice.updateFlag(username, 1);
					return "welcome";
				}
				else {
					return "alreadylogedin";
				}
			}
			else {
				return "wrong credentials";
			}
		}
	}
	9:16
	package com.example.demo;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Component;
	@Component("logout")
	public class LogoutBean {
		@Autowired
		private UserService userservice;
		
		public String logout(String uname) {
			int i=userservice.updateFlag(uname, 0);
			if(i==1) {
				return "success";
			}
			else {
				return "failure";
			}
		}
	}
	9:16
	package com.example.demo;
	import org.springframework.data.jpa.repository.JpaRepository;
	import org.springframework.stereotype.Repository;
	@Repository
	//@Transactional
	public interface UserDAO extends JpaRepository<UserDTO, Integer>{
		public UserDTO findByUsername(String username);
	}
	9:17
	package com.example.demo;
	import java.io.Serializable;
	import jakarta.persistence.Entity;
	import jakarta.persistence.Id;
	import jakarta.persistence.Table;
	@Entity
	@Table(name="users")
	public class UserDTO implements Serializable,Comparable<UserDTO>{
		@Id
		private int userid;
		private String username;
		private String password;
		private int salary;
		private int flag;
		@Override
		public int compareTo(UserDTO o) {
			return this.username.compareTo(o.username);
		}
		public int getUserid() {
			return userid;
		}
		public void setUserid(int userid) {
			this.userid = userid;
		}
		public String getUsername() {
			return username;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public int getSalary() {
			return salary;
		}
		public void setSalary(int salary) {
			this.salary = salary;
		}
		public int getFlag() {
			return flag;
		}
		public void setFlag(int flag) {
			this.flag = flag;
		}
		public UserDTO() {
			// TODO Auto-generated constructor stub
		}
		public UserDTO(int userid, String username, String password, int salary, int flag) {
			this.userid = userid;
			this.username = username;
			this.password = password;
			this.salary = salary;
			this.flag = flag;
		}
		@Override
		public String toString() {
			return "UserDTO [userid=" + userid + ", username=" + username + ", password=" + password + ", salary=" + salary
					+ ", flag=" + flag + "]";
		}
		
		
	}
	9:17
	package com.example.demo;
	import org.springframework.stereotype.Service;
	public interface UserService {
		public boolean checkUser(String username,String password);
		public boolean checkFlag(String username);
		public int updateFlag(String username,int flag);
	}
	9:17
	package com.example.demo;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Service;
	@Service("userservice")
	public class UserServiceImpl implements UserService{
		
		@Autowired
		private UserDAO ud;
		@Override
		public boolean checkUser(String username, String password) {
			UserDTO user=ud.findByUsername(username);
			if(user!=null) {
				String pass=user.getPassword();
				if(pass.equals(password)) {
					return true;
				}
				else {
					return false;
				}
			}
			else {
				return false;
			}
		}
		@Override
		public boolean checkFlag(String username) {
			UserDTO user=ud.findByUsername(username);
			if(user!=null) {
				int flag=user.getFlag();
				if(flag==0) {
					return true;
				}
				else {
					return false;
				}
			}
			else {
				return false;
			}
		}
		@Override
		public int updateFlag(String username, int flag) {
			UserDTO user=ud.findByUsername(username);
			if(user!=null) {
				user.setFlag(flag);
				ud.save(user);
				return 1;
			}
			else {
				return 0;
			}
		}
	}
	9:17
	package com.example.demo;
	import org.springframework.boot.SpringApplication;
	import org.springframework.boot.autoconfigure.AutoConfigurationPackage;
	import org.springframework.boot.autoconfigure.SpringBootApplication;
	import org.springframework.context.ConfigurableApplicationContext;
	import org.springframework.context.annotation.ComponentScan;
	@SpringBootApplication
	@ComponentScan({"com"})
	public class SampleAppApplication {
		public static void main(String[] args) {
			ConfigurableApplicationContext ctx= SpringApplication.run(SampleAppApplication.class, args);
			
			LoginBean loginBean=ctx.getBean("login",LoginBean.class);
			
			System.out.println("For Rahim..:"+loginBean.login("rahim", "secret"));
			
			System.out.println("For Sami..:"+loginBean.login("sami", "secret"));
			
			System.out.println("For No user..:"+loginBean.login("aaa", "secret"));
		}
	}


	SHOIAB-GOLDEN TOUCH - HAARISINFOTECH
	  9:05 PM
	package com.example.demo;
	import org.springframework.stereotype.Controller;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RequestMethod;
	//http://localhost:8080/myservice/hellomet - REST URL
	@Controller
	@RequestMapping("/myservice")
	public class MyRestService {
		@RequestMapping(method = RequestMethod.GET, value = "/hellomet")
		public void met() {
			System.out.println("met method called.....");
		}
	}


	SHOIAB-GOLDEN TOUCH - HAARISINFOTECH
	  3:31 PM
	package com.example.serviceaspects;
	import java.util.Date;
	import org.aspectj.lang.JoinPoint;
	import org.aspectj.lang.annotation.After;
	import org.aspectj.lang.annotation.Aspect;
	import org.aspectj.lang.annotation.Before;
	import org.springframework.stereotype.Component;
	@Aspect
	@Component
	public class LogingAspectService {
	    @Before("execution(* com.example.component.LogoutBean.*(..))")
	    public void logBefore(JoinPoint joinPoint) {
	        System.out.println("Logged...:Entering method: " + joinPoint.getSignature().getName()+":"+new Date());
	    }
	    @After("execution(* com.example.component.LogoutBean.*(..))")
	    public void logAfter(JoinPoint joinPoint) {
	        System.out.println("Logged..:Exiting method: " + joinPoint.getSignature().getName()+":"+new Date());
	    }
	}
	3:32
	<dependency>
				<groupId>org.springframework</groupId>
				<artifactId>spring-aop</artifactId>
				</dependency>
			<dependency>
				<groupId>org.aspectj</groupId>
				<artifactId>aspectjrt</artifactId>
				</dependency>
			
			<dependency>
				<groupId>org.aspectj</groupId>
				<artifactId>aspectjweaver</artifactId>
			</dependency>
	3:32
	above dependencies to be added in the pom.xml


	SHOIAB-GOLDEN TOUCH - HAARISINFOTECH
	  4:07 PM
	package com;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Component;
	import org.springframework.transaction.annotation.Propagation;
	import org.springframework.transaction.annotation.Transactional;
	import com.service.BankingService;
	@Component("bank")
	@Transactional
	public class Bank {
		@Autowired
		BankingService bs;
		
		@Transactional(propagation = Propagation.REQUIRED)
		public void doBanking(int crid,int drid,int amt)throws Exception {
			bs.moneyTransfer(crid,drid,amt);
		}
	}
	package com.dao;
	import jakarta.persistence.Entity;
	import jakarta.persistence.Id;
	@Entity
	public class Student {
		@Id
		private int sid;
		private String sname;
		private int amt;
		public int getSid() {
			return sid;
		}
		public void setSid(int sid) {
			this.sid = sid;
		}
		public String getSname() {
			return sname;
		}
		public void setSname(String sname) {
			this.sname = sname;
		}
		public int getAmt() {
			return amt;
		}
		public void setAmt(int amt) {
			this.amt = amt;
		}
		
	}
	package com.dao;
	import org.springframework.data.jpa.repository.JpaRepository;
	import org.springframework.stereotype.Repository;
	@Repository
	public interface StudentDAO extends JpaRepository<Student, Integer>{
		
	}
	4:08
	package com.service;
	public interface BankingService {
		public void moneyTransfer(int crid,int drid,int amt)throws Exception;
	}
	package com.service;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Service;
	import org.springframework.transaction.annotation.Propagation;
	import org.springframework.transaction.annotation.Transactional;
	@Service("bs")
	@Transactional
	public class BankingServiceImpl implements BankingService{
		@Autowired
		UtilityServices usi;
		@Transactional(propagation = Propagation.REQUIRED)
		@Override
		public void moneyTransfer(int crid, int drid, int amt)throws Exception {
			// TODO Auto-generated method stub
			usi.credit(crid, amt);
			usi.debit(drid, amt);
		}
	}
	package com.service;
	public class InsufficientBalance extends Exception {
		String msg;
		public InsufficientBalance(String msg) {
			this.msg=msg;
		}
		@Override
		public String toString() {
			return "Exception is...:"+msg;
		}
	}
	package com.service;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Service;
	import org.springframework.transaction.annotation.Propagation;
	import org.springframework.transaction.annotation.Transactional;
	import com.dao.Student;
	import com.dao.StudentDAO;
	@Service("us")
	@Transactional
	public class UtilityServiceImpl implements UtilityServices{
		
		@Autowired
		StudentDAO dao;
		
		@Override
		@Transactional(propagation = Propagation.REQUIRED)
		public void credit(int crid, int amt) {
			// TODO Auto-generated method stub
			Student student=dao.findById(crid).get();
			if(student!=null) {
				int old_amt=student.getAmt();
				int new_amt=amt+old_amt;
				student.setAmt(new_amt);
				dao.save(student);
			}
		}
		@Override
		@Transactional(propagation = Propagation.REQUIRED,rollbackFor = {InsufficientBalance.class})
		public void debit(int drid, int amt)throws Exception {
			// TODO Auto-generated method stub
			Student student=dao.findById(drid).get();
			if(student!=null) {
				int old_amt=student.getAmt();
				if(old_amt<amt) {
					throw new InsufficientBalance("The account balance is less,,, pls topup for transfer...");
				}
				else {
					int new_amt=old_amt-amt;
					student.setAmt(new_amt);	
				}			
				dao.save(student);
			}
		}
	}
	package com.service;
	public interface UtilityServices {
		public void credit(int crid,int amt);
		public void debit(int drid,int amt)throws Exception;
	}











	Message training









