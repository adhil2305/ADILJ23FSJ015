package edu.disease.asn3;

import java.util.UUID;
public interface DiseaseControlManager {

	Disease addDisease(String name, boolean infectious);

	Disease[] getDiseases(UUID diseaseId);

	Patient addPatient(String firstName, String lastName, int maxDiseases, int maxExposures);

	Patient getPatient(UUID patientId);
	
	Disease getDisease(UUID diseaseId);
	
	void addPatientInArray(Patient patient);
	
	Patient[] getPatients();
	
	void addDiseaseToPatient(UUID patientId, UUID diseaseId);

	void addExposureToPatient(UUID patientId, Exposure exposure);
}
