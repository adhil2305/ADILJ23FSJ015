package skirmish;

public class CastingDemo2 {
	public static void main(String[] args) {
		int i = 23;
		byte b = 12;
		
		// b = (byte)i;
		i = (int)b;
		
		System.out.println(b);
		
		
		
	}

}
