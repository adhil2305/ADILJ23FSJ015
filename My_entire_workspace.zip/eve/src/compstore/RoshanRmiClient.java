package compstore;

public class RoshanRmiClient {
	public static void main(String[] args) {
		
	}
}
