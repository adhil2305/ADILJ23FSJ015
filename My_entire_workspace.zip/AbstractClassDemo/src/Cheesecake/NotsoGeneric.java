package Cheesecake;

public class NotsoGeneric {
		public static void main(String[] args) {
			Alexa<AlexaEntertainment> entertainmentDevice1  = new Alexa<AlexaEntertainment>();
			entertainmentDevice1.setObj(new AlexaEntertainment());
			entertainmentDevice1.getObj();
		}
}
// Not good revise the object creation everyday 
abstract class Device{
	abstract void sound();
}

class Alexa<T> {
	T obj;
	void sound() {
		System.out.println("alexa called the sound method of the abstract device");
	}
	public void setObj(T obj) {
		System.out.println("The frequency of the device is selected");
		this.obj = obj;
	}
	public T getObj() {
		return obj;
		
	}
}

class AlexaEntertainment extends Alexa{
	public AlexaEntertainment() {
		System.out.println("The alexa entertainment device is created ");
	}
	
}