package chatni;

public class LambdaDemo3 {
		public static void main(String[] args) {
			//Mahatma Gandhi way - External/Internal class implementation 
			Inter23 in1 = new InterImpl23();
			in1.met("mahatma gandhi",0);
			System.out.println(in1.met("Mahatma Gandhi way ...",150));
				
			// Indhra Gandhi way - Anonymous Inner class
			String result = new Inter23(){
				@Override
				public String met(String name,int age) {
					return name+"way... " +age;
				}
			}.met("IndhraGandhi",100);
			System.out.println(result);
			//RahulGandhi Way - Lambda
			Inter23 in2 = (String name, int age)->{return name+"gandhi way..."+age;};
			System.out.println(in2.met("rahulgandhi way",50));
			
			//PriyankaGandhi Way - MetMethod Referencing
			Inter23 in3=new LambdaDemo3()::myOwnMetMethodCreatedByVadodra;			System.out.println(in3.met("priyanka gandhi",45));
			}
			public String myOwnMetMethodCreatedByVadodra(String name,int age) {
				return "my ownmetmethod implementation ..." +name+":"+age;
			}
		}
		interface Inter23{
			public String met(String name,int age);
		}
		//MahatmaGandhi way
class InterImpl23 implements Inter23{
	@Override
	public String met(String name, int age) {
		int sum = 0;
		for(int i=0;i<4;i++) {
			for(int j=i;j<5;j++) {
				sum = sum+j;
			}
		}
		System.out.println("my question"+sum);
		return (name+"way......."+age);
	}
}